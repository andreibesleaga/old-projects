Acest director nu este accesibil prin legaturi din paginile de pe server.
Pentru accesare trebuie sa va conectati la adresa: http://server/wwwadmin/
Acest director este disponibil doar utilizatorilor din grupul administrators
si contine pagini de administrare (legaturi la serverul de administrare la distanta).