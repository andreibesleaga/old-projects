Acest director contine documentatia disponibila utilizatorilor.
(Indiferent daca sunt autentificati sau nu).