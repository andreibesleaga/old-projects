Acesta este directorul radacina pentru serverul de web Remote Panels (admin la distanta).
Nu ar trebui sa existe fisiere aici in afara de index.htm si index.html (fara continut),
dar se poate extinde functionalitatea programului ulterior prin includerea altor pagini.