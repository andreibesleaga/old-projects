Acesta este directorul radacina pentru G Web Server.
Aici se afla paginile web si VI-urile CGI.