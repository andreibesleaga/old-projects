//---------------------------------------------------------------------------
//
// <copyright file="TaxiListPage.xaml.cs" company="Microsoft">
//    Copyright (C) 2015 by Microsoft Corporation.  All rights reserved.
// </copyright>
//
// <createdOn>11/7/2015 11:42:00 AM</createdOn>
//
//---------------------------------------------------------------------------

using Windows.UI.Xaml.Controls;
using Windows.UI.Xaml.Navigation;
using AppStudio.DataProviders.LocalStorage;
using Bucharest.Sections;
using Bucharest.ViewModels;

namespace Bucharest.Views
{
    public sealed partial class TaxiListPage : Page
    {
        public TaxiListPage()
        {
            this.ViewModel = new ListViewModel<LocalStorageDataConfig, Taxi1Schema>(new TaxiConfig());
            this.InitializeComponent();
        }

        public ListViewModel<LocalStorageDataConfig, Taxi1Schema> ViewModel { get; set; }


        protected override async void OnNavigatedTo(NavigationEventArgs e)
        {
            await this.ViewModel.LoadDataAsync();

            base.OnNavigatedTo(e);
        }

    }
}
