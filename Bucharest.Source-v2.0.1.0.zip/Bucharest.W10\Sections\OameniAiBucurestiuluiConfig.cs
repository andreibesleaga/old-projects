using System;
using System.Collections.Generic;
using AppStudio.DataProviders;
using AppStudio.DataProviders.Core;
using AppStudio.DataProviders.Facebook;
using AppStudio.Uwp.Actions;
using AppStudio.Uwp.Commands;
using AppStudio.Uwp.Navigation;
using Bucharest.Config;
using Bucharest.ViewModels;

namespace Bucharest.Sections
{
    public class OameniAiBucurestiuluiConfig : SectionConfigBase<FacebookDataConfig, FacebookSchema>
    {
        public override DataProviderBase<FacebookDataConfig, FacebookSchema> DataProvider
        {
            get
            {
                return new FacebookDataProvider(new FacebookOAuthTokens
                {
                    AppId = "554714964666761",
                    AppSecret = "19de2fd0597a7010ba2c5cd6e65163af"
                });
            }
        }

        public override FacebookDataConfig Config
        {
            get
            {
                return new FacebookDataConfig
                {
                    UserId = "550628441711475"
                };
            }
        }

        public override NavigationInfo ListNavigationInfo
        {
            get 
            {
                return NavigationInfo.FromPage("OameniAiBucurestiuluiListPage");
            }
        }

        public override ListPageConfig<FacebookSchema> ListPage
        {
            get 
            {
                return new ListPageConfig<FacebookSchema>
                {
                    Title = "OameniAiBucurestiului",

                    LayoutBindings = (viewModel, item) =>
                    {
                        viewModel.Title = item.Title.ToSafeString();
                        viewModel.SubTitle = item.Summary.ToSafeString();
                        viewModel.Description = null;
                        viewModel.Image = item.ImageUrl.ToSafeString();
                    },
                    NavigationInfo = (item) =>
                    {
                        return NavigationInfo.FromPage("OameniAiBucurestiuluiDetailPage", true);
                    }
                };
            }
        }

        public override DetailPageConfig<FacebookSchema> DetailPage
        {
            get
            {
                var bindings = new List<Action<ItemViewModel, FacebookSchema>>();
                bindings.Add((viewModel, item) =>
                {
                    viewModel.PageTitle = item.Title.ToSafeString();
                    viewModel.Title = item.Title.ToSafeString();
                    viewModel.Description = item.Content.ToSafeString();
                    viewModel.Image = item.ImageUrl.ToSafeString();
                    viewModel.Content = null;
                });

                var actions = new List<ActionConfig<FacebookSchema>>
                {
                    ActionConfig<FacebookSchema>.Link("Go To Source", (item) => item.FeedUrl.ToSafeString()),
                };

                return new DetailPageConfig<FacebookSchema>
                {
                    Title = "OameniAiBucurestiului",
                    LayoutBindings = bindings,
                    Actions = actions
                };
            }
        }

        public override string PageTitle
        {
            get { return "OameniAiBucurestiului"; }
        }
    }
}
