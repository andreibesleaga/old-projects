using System;
using AppStudio.DataProviders;

namespace Bucharest.Sections
{
    /// <summary>
    /// Implementation of the Taxi1Schema class.
    /// </summary>
    public class Taxi1Schema : SchemaBase
    {

        public string Company { get; set; }

        public string telephone { get; set; }
    }
}
