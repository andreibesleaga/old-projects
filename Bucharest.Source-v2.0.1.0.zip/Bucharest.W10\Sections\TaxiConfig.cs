using System;
using System.Collections.Generic;
using AppStudio.DataProviders;
using AppStudio.DataProviders.Core;
using AppStudio.DataProviders.LocalStorage;
using AppStudio.Uwp.Navigation;
using Bucharest.Config;
using Bucharest.ViewModels;

namespace Bucharest.Sections
{
    public class TaxiConfig : SectionConfigBase<LocalStorageDataConfig, Taxi1Schema>
    {
        public override DataProviderBase<LocalStorageDataConfig, Taxi1Schema> DataProvider
        {
            get
            {
                return new LocalStorageDataProvider<Taxi1Schema>();
            }
        }

        public override LocalStorageDataConfig Config
        {
            get
            {
                return new LocalStorageDataConfig
                {
                    FilePath = "/Assets/Data/Taxi.json"
                };
            }
        }

        public override NavigationInfo ListNavigationInfo
        {
            get 
            {
                return NavigationInfo.FromPage("TaxiListPage");
            }
        }

        public override ListPageConfig<Taxi1Schema> ListPage
        {
            get 
            {
                return new ListPageConfig<Taxi1Schema>
                {
                    Title = "Taxi",

                    LayoutBindings = (viewModel, item) =>
                    {
                        viewModel.Title = item.Company.ToSafeString();
                        viewModel.SubTitle = item.telephone.ToSafeString();
                        viewModel.Description = "";
                        viewModel.Image = "";
                    },
                    NavigationInfo = (item) =>
                    {
                        return NavigationInfo.FromPage("TaxiDetailPage", true);
                    }
                };
            }
        }

        public override DetailPageConfig<Taxi1Schema> DetailPage
        {
            get
            {
                var bindings = new List<Action<ItemViewModel, Taxi1Schema>>();
                bindings.Add((viewModel, item) =>
                {
                    viewModel.PageTitle = "Taxi";
                    viewModel.Title = item.Company.ToSafeString();
                    viewModel.Description = item.telephone.ToSafeString();
                    viewModel.Image = "";
                    viewModel.Content = null;
                });

                var actions = new List<ActionConfig<Taxi1Schema>>
                {
                    ActionConfig<Taxi1Schema>.Phone("telephone", (item) => item.telephone.ToSafeString()),
                };

                return new DetailPageConfig<Taxi1Schema>
                {
                    Title = "Taxi",
                    LayoutBindings = bindings,
                    Actions = actions
                };
            }
        }

        public override string PageTitle
        {
            get { return "Taxi"; }
        }
    }
}
