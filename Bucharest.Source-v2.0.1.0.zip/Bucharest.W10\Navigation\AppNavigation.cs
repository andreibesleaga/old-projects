using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using AppStudio.Uwp.Navigation;
using Windows.ApplicationModel.Resources;
using Windows.UI.Xaml;

namespace Bucharest.Navigation
{
    public class AppNavigation
    {
        private NavigationNode _active;

        static AppNavigation()
        {

        }

        public NavigationNode Active
        {
            get
            {
                return _active;
            }
            set
            {
                if (_active != null)
                {
                    _active.IsSelected = false;
                }
                _active = value;
                if (_active != null)
                {
                    _active.IsSelected = true;
                }
            }
        }


        public ObservableCollection<NavigationNode> Nodes { get; private set; }

        public void LoadNavigation()
        {
            Nodes = new ObservableCollection<NavigationNode>();
		    var resourceLoader = new ResourceLoader();
            Nodes.Add(new ItemNavigationNode
            {
                Title = @"Bucharest",
                Label = "Home",
                FontIcon = "\ue10f",
                IsSelected = true,
                NavigationInfo = NavigationInfo.FromPage("HomePage")
            });

            Nodes.Add(new GroupNavigationNode
            {
                Label = "News and Weather",
                Visibility = Visibility.Visible,
                FontIcon = "\ue10c",
                Nodes = new ObservableCollection<NavigationNode>()
                {
                    new ItemNavigationNode
                    {
                        Label = "Google News",
                        FontIcon = "\ue12a",
                        NavigationInfo = NavigationInfo.FromPage("GoogleNewsListPage")
                    },
                    new ItemNavigationNode
                    {
                        Label = "HotNews.ro",
                        FontIcon = "\ue12a",
                        NavigationInfo = NavigationInfo.FromPage("HotNewsRoListPage")
                    },
                    new ItemNavigationNode
                    {
                        Label = "Nineoclock",
                        FontIcon = "\ue12a",
                        NavigationInfo = NavigationInfo.FromPage("NineoclockListPage")
                    },
                    new ItemNavigationNode
                    {
                        Label = "Romania Insider",
                        FontIcon = "\ue12a",
                        NavigationInfo = NavigationInfo.FromPage("RomaniaInsiderListPage")
                    },
                    new ItemNavigationNode
                    {
                        Label = "Topix",
                        FontIcon = "\ue12a",
                        NavigationInfo = NavigationInfo.FromPage("TopixListPage")
                    },
                    new ItemNavigationNode
                    {
                        Label = "BBC Weather",
                        FontIcon = "\ue12a",
                        NavigationInfo = NavigationInfo.FromPage("BBCWeatherListPage")
                    },
                    new ItemNavigationNode
                    {
                        Label = "Weather",
                        FontIcon = "\ue12a",
                        NavigationInfo = NavigationInfo.FromPage("WeatherListPage")
                    },
                }
            });
            Nodes.Add(new GroupNavigationNode
            {
                Label = "Photos and Videos",
                Visibility = Visibility.Visible,
                FontIcon = "\ue10c",
                Nodes = new ObservableCollection<NavigationNode>()
                {
                    new ItemNavigationNode
                    {
                        Label = "Flickr",
                        FontIcon = "\ue114",
                        NavigationInfo = NavigationInfo.FromPage("FlickrListPage")
                    },
                    new ItemNavigationNode
                    {
                        Label = "Instagram",
                        FontIcon = "\ue12d",
                        NavigationInfo = NavigationInfo.FromPage("InstagramListPage")
                    },
                    new ItemNavigationNode
                    {
                        Label = "YouTube",
                        FontIcon = "\ue173",
                        NavigationInfo = NavigationInfo.FromPage("YouTubeListPage")
                    },
                }
            });
            Nodes.Add(new GroupNavigationNode
            {
                Label = "Facebook Pages",
                Visibility = Visibility.Visible,
                FontIcon = "\ue10c",
                Nodes = new ObservableCollection<NavigationNode>()
                {
                    new ItemNavigationNode
                    {
                        Label = "Bucharest Airports",
                        FontIcon = "\ue19f",
                        NavigationInfo = NavigationInfo.FromPage("BucharestAirportsListPage")
                    },
                    new ItemNavigationNode
                    {
                        Label = "Bucharestly",
                        FontIcon = "\ue19f",
                        NavigationInfo = NavigationInfo.FromPage("BucharestlyListPage")
                    },
                    new ItemNavigationNode
                    {
                        Label = "Bucharest Now",
                        FontIcon = "\ue19f",
                        NavigationInfo = NavigationInfo.FromPage("BucharestNowListPage")
                    },
                    new ItemNavigationNode
                    {
                        Label = "Bucharest Cultural",
                        FontIcon = "\ue19f",
                        NavigationInfo = NavigationInfo.FromPage("BucharestCulturalListPage")
                    },
                    new ItemNavigationNode
                    {
                        Label = "Travelers Bucharest",
                        FontIcon = "\ue19f",
                        NavigationInfo = NavigationInfo.FromPage("TravelersBucharestListPage")
                    },
                    new ItemNavigationNode
                    {
                        Label = "Bucharest Tips",
                        FontIcon = "\ue19f",
                        NavigationInfo = NavigationInfo.FromPage("BucharestTipsListPage")
                    },
                    new ItemNavigationNode
                    {
                        Label = "Bucharest Expat",
                        FontIcon = "\ue19f",
                        NavigationInfo = NavigationInfo.FromPage("BucharestExpatListPage")
                    },
                    new ItemNavigationNode
                    {
                        Label = "Bucharest Greeters",
                        FontIcon = "\ue19f",
                        NavigationInfo = NavigationInfo.FromPage("BucharestGreetersListPage")
                    },
                    new ItemNavigationNode
                    {
                        Label = "Meanwhile in Bucharest",
                        FontIcon = "\ue19f",
                        NavigationInfo = NavigationInfo.FromPage("MeanwhileInBucharestListPage")
                    },
                    new ItemNavigationNode
                    {
                        Label = "Living in Bucharest",
                        FontIcon = "\ue19f",
                        NavigationInfo = NavigationInfo.FromPage("LivingInBucharestListPage")
                    },
                    new ItemNavigationNode
                    {
                        Label = "Bucuresti Optimist",
                        FontIcon = "\ue19f",
                        NavigationInfo = NavigationInfo.FromPage("BucurestiOptimistListPage")
                    },
                    new ItemNavigationNode
                    {
                        Label = "Bucuresti Realist",
                        FontIcon = "\ue19f",
                        NavigationInfo = NavigationInfo.FromPage("BucurestiRealistListPage")
                    },
                    new ItemNavigationNode
                    {
                        Label = "Metropotam",
                        FontIcon = "\ue19f",
                        NavigationInfo = NavigationInfo.FromPage("MetropotamListPage")
                    },
                    new ItemNavigationNode
                    {
                        Label = "OameniAiBucurestiului",
                        FontIcon = "\ue19f",
                        NavigationInfo = NavigationInfo.FromPage("OameniAiBucurestiuluiListPage")
                    },
                    new ItemNavigationNode
                    {
                        Label = "Bucuresti Tu",
                        FontIcon = "\ue19f",
                        NavigationInfo = NavigationInfo.FromPage("BucurestiTuListPage")
                    },
                    new ItemNavigationNode
                    {
                        Label = "Bucuresti",
                        FontIcon = "\ue19f",
                        NavigationInfo = NavigationInfo.FromPage("BucurestiListPage")
                    },
                    new ItemNavigationNode
                    {
                        Label = "Bucuresti.ro",
                        FontIcon = "\ue19f",
                        NavigationInfo = NavigationInfo.FromPage("BucurestiRoListPage")
                    },
                    new ItemNavigationNode
                    {
                        Label = "Bucurestiul Secret",
                        FontIcon = "\ue19f",
                        NavigationInfo = NavigationInfo.FromPage("BucurestiulSecretListPage")
                    },
                    new ItemNavigationNode
                    {
                        Label = "Piete din Bucuresti",
                        FontIcon = "\ue19f",
                        NavigationInfo = NavigationInfo.FromPage("PieteDinBucurestiListPage")
                    },
                    new ItemNavigationNode
                    {
                        Label = "B365.ro",
                        FontIcon = "\ue19f",
                        NavigationInfo = NavigationInfo.FromPage("B365RoListPage")
                    },
                    new ItemNavigationNode
                    {
                        Label = "Via Bucuresti",
                        FontIcon = "\ue19f",
                        NavigationInfo = NavigationInfo.FromPage("ViaBucurestiListPage")
                    },
                }
            });
            Nodes.Add(new ItemNavigationNode
            {
                Label = "Taxi",
                FontIcon = "\ue1d3",
                NavigationInfo = NavigationInfo.FromPage("TaxiListPage")
            });
            Nodes.Add(new GroupNavigationNode
            {
                Label = "Other",
                Visibility = Visibility.Visible,
                FontIcon = "\ue10c",
                Nodes = new ObservableCollection<NavigationNode>()
                {
                    new ItemNavigationNode
                    {
                        Label = "Twitter",
                        FontIcon = "\ue134",
                        NavigationInfo = NavigationInfo.FromPage("TwitterListPage")
                    },
                    new ItemNavigationNode
                    {
                        Label = "Search Events",
                        FontIcon = "\ue155",
                        NavigationInfo = NavigationInfo.FromPage("SearchEventsListPage")
                    },
                    new ItemNavigationNode
                    {
                        Label = "Search Hotels",
                        FontIcon = "\ue155",
                        NavigationInfo = NavigationInfo.FromPage("SearchHotelsListPage")
                    },
                    new ItemNavigationNode
                    {
                        Label = "Search News",
                        FontIcon = "\ue155",
                        NavigationInfo = NavigationInfo.FromPage("SearchNewsListPage")
                    },
                }
            });
            Nodes.Add(new ItemNavigationNode
            {
                Label = resourceLoader.GetString("NavigationPanePrivacy"),
                FontIcon = "\ue1f7",
                NavigationInfo = new NavigationInfo()
                {
                    NavigationType = NavigationType.DeepLink,
                    TargetUri = new Uri("http://appstudio.windows.com/home/appprivacyterms", UriKind.Absolute)
                }
            });
        }

        public NavigationNode FindPage(Type pageType)
        {
            return GetAllItemNodes(Nodes).FirstOrDefault(n => n.NavigationInfo.NavigationType == NavigationType.Page && n.NavigationInfo.TargetPage == pageType.Name);
        }

        private IEnumerable<ItemNavigationNode> GetAllItemNodes(IEnumerable<NavigationNode> nodes)
        {
            foreach (var node in nodes)
            {
                if (node is ItemNavigationNode)
                {
                    yield return node as ItemNavigationNode;
                }
                else if(node is GroupNavigationNode)
                {
                    var gNode = node as GroupNavigationNode;

                    foreach (var innerNode in GetAllItemNodes(gNode.Nodes))
                    {
                        yield return innerNode;
                    }
                }
            }
        }
    }
}
