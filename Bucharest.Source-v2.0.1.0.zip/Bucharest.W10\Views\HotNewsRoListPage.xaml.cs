//---------------------------------------------------------------------------
//
// <copyright file="HotNewsRoListPage.xaml.cs" company="Microsoft">
//    Copyright (C) 2015 by Microsoft Corporation.  All rights reserved.
// </copyright>
//
// <createdOn>11/7/2015 11:42:00 AM</createdOn>
//
//---------------------------------------------------------------------------

using Windows.UI.Xaml.Controls;
using Windows.UI.Xaml.Navigation;
using AppStudio.DataProviders.Rss;
using Bucharest.Sections;
using Bucharest.ViewModels;

namespace Bucharest.Views
{
    public sealed partial class HotNewsRoListPage : Page
    {
        public HotNewsRoListPage()
        {
            this.ViewModel = new ListViewModel<RssDataConfig, RssSchema>(new HotNewsRoConfig());
            this.InitializeComponent();
        }

        public ListViewModel<RssDataConfig, RssSchema> ViewModel { get; set; }


        protected override async void OnNavigatedTo(NavigationEventArgs e)
        {
            await this.ViewModel.LoadDataAsync();

            base.OnNavigatedTo(e);
        }

    }
}
