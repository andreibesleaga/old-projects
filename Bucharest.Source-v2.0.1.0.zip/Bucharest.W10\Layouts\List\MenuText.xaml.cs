namespace Bucharest.Layouts.List
{
    public sealed partial class MenuText : ListLayoutBase
    {
        public MenuText() : base()
        {
            this.InitializeComponent();
        }
    }
}
