namespace Bucharest.Layouts.List
{
    public sealed partial class ListTouchDevelop : ListLayoutBase
    {
        public ListTouchDevelop() : base()
        {
            this.InitializeComponent();
        }
    }
}
