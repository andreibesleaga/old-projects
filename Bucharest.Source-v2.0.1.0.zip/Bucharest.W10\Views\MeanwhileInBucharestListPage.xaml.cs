//---------------------------------------------------------------------------
//
// <copyright file="MeanwhileInBucharestListPage.xaml.cs" company="Microsoft">
//    Copyright (C) 2015 by Microsoft Corporation.  All rights reserved.
// </copyright>
//
// <createdOn>11/7/2015 11:42:00 AM</createdOn>
//
//---------------------------------------------------------------------------

using Windows.UI.Xaml.Controls;
using Windows.UI.Xaml.Navigation;
using AppStudio.DataProviders.Facebook;
using Bucharest.Sections;
using Bucharest.ViewModels;

namespace Bucharest.Views
{
    public sealed partial class MeanwhileInBucharestListPage : Page
    {
        public MeanwhileInBucharestListPage()
        {
            this.ViewModel = new ListViewModel<FacebookDataConfig, FacebookSchema>(new MeanwhileInBucharestConfig());
            this.InitializeComponent();
        }

        public ListViewModel<FacebookDataConfig, FacebookSchema> ViewModel { get; set; }


        protected override async void OnNavigatedTo(NavigationEventArgs e)
        {
            await this.ViewModel.LoadDataAsync();

            base.OnNavigatedTo(e);
        }

    }
}
