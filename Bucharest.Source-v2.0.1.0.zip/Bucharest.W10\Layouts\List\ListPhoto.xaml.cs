namespace Bucharest.Layouts.List
{
    public sealed partial class ListPhoto : ListLayoutBase
    {
        public ListPhoto() : base()
        {
            this.InitializeComponent();
        }
    }
}
