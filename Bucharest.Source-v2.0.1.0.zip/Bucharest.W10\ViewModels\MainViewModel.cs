using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using AppStudio.Uwp;
using AppStudio.Uwp.Actions;
using AppStudio.Uwp.Commands;
using AppStudio.Uwp.Navigation;
using AppStudio.DataProviders;
using Windows.UI.Xaml;
using Windows.UI.Xaml.Controls;
using AppStudio.DataProviders.Menu;
using AppStudio.DataProviders.LocalStorage;
using Bucharest.Sections;


namespace Bucharest.ViewModels
{
    public class MainViewModel : PageViewModel
    {
        public MainViewModel(int visibleItems) : base()
        {
            PageTitle = "Bucharest";
            UsefulLinks = new ListViewModel<LocalStorageDataConfig, MenuSchema>(new UsefulLinksConfig());
            NewsAndWeather = new ListViewModel<LocalStorageDataConfig, MenuSchema>(new NewsAndWeatherConfig());
            PhotosAndVideos = new ListViewModel<LocalStorageDataConfig, MenuSchema>(new PhotosAndVideosConfig());
            FacebookPages = new ListViewModel<LocalStorageDataConfig, MenuSchema>(new FacebookPagesConfig());
            Taxi = new ListViewModel<LocalStorageDataConfig, Taxi1Schema>(new TaxiConfig(), visibleItems);
            Other = new ListViewModel<LocalStorageDataConfig, MenuSchema>(new OtherConfig());
            Actions = new List<ActionInfo>();

            if (GetViewModels().Any(vm => !vm.HasLocalData))
            {
                Actions.Add(new ActionInfo
                {
                    Command = new RelayCommand(Refresh),
                    Style = ActionKnownStyles.Refresh,
                    Name = "RefreshButton",
                    ActionType = ActionType.Primary
                });
            }
        }

        public string PageTitle { get; set; }
        public ListViewModel<LocalStorageDataConfig, MenuSchema> UsefulLinks { get; private set; }
        public ListViewModel<LocalStorageDataConfig, MenuSchema> NewsAndWeather { get; private set; }
        public ListViewModel<LocalStorageDataConfig, MenuSchema> PhotosAndVideos { get; private set; }
        public ListViewModel<LocalStorageDataConfig, MenuSchema> FacebookPages { get; private set; }
        public ListViewModel<LocalStorageDataConfig, Taxi1Schema> Taxi { get; private set; }
        public ListViewModel<LocalStorageDataConfig, MenuSchema> Other { get; private set; }

        public RelayCommand<INavigable> SectionHeaderClickCommand
        {
            get
            {
                return new RelayCommand<INavigable>(item =>
                    {
                        NavigationService.NavigateTo(item);
                    });
            }
        }

        public DateTime? LastUpdated
        {
            get
            {
                return GetViewModels().Select(vm => vm.LastUpdated)
                            .OrderByDescending(d => d).FirstOrDefault();
            }
        }

        public List<ActionInfo> Actions { get; private set; }

        public bool HasActions
        {
            get
            {
                return Actions != null && Actions.Count > 0;
            }
        }

        public async Task LoadDataAsync()
        {
            var loadDataTasks = GetViewModels().Select(vm => vm.LoadDataAsync());

            await Task.WhenAll(loadDataTasks);

            OnPropertyChanged("LastUpdated");
        }

		public override void UpdateCommonProperties(SplitViewDisplayMode splitViewDisplayMode)
        {
            base.UpdateCommonProperties(splitViewDisplayMode);
            if (splitViewDisplayMode == SplitViewDisplayMode.Overlay)
            {
                AppBarRow = 3;
                AppBarColumn = 0;
                AppBarColumnSpan = 2;
            }
        }

        private async void Refresh()
        {
            var refreshDataTasks = GetViewModels()
                                        .Where(vm => !vm.HasLocalData)
                                        .Select(vm => vm.LoadDataAsync(true));

            await Task.WhenAll(refreshDataTasks);

            OnPropertyChanged("LastUpdated");
        }

        private IEnumerable<DataViewModelBase> GetViewModels()
        {
            yield return UsefulLinks;
            yield return NewsAndWeather;
            yield return PhotosAndVideos;
            yield return FacebookPages;
            yield return Taxi;
            yield return Other;
        }
    }
}
