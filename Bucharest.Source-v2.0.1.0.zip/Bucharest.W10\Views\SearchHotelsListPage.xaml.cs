//---------------------------------------------------------------------------
//
// <copyright file="SearchHotelsListPage.xaml.cs" company="Microsoft">
//    Copyright (C) 2015 by Microsoft Corporation.  All rights reserved.
// </copyright>
//
// <createdOn>11/7/2015 11:42:00 AM</createdOn>
//
//---------------------------------------------------------------------------

using Windows.UI.Xaml.Controls;
using Windows.UI.Xaml.Navigation;
using AppStudio.DataProviders.Bing;
using Bucharest.Sections;
using Bucharest.ViewModels;

namespace Bucharest.Views
{
    public sealed partial class SearchHotelsListPage : Page
    {
        public SearchHotelsListPage()
        {
            this.ViewModel = new ListViewModel<BingDataConfig, BingSchema>(new SearchHotelsConfig());
            this.InitializeComponent();
        }

        public ListViewModel<BingDataConfig, BingSchema> ViewModel { get; set; }


        protected override async void OnNavigatedTo(NavigationEventArgs e)
        {
            await this.ViewModel.LoadDataAsync();

            base.OnNavigatedTo(e);
        }

    }
}
