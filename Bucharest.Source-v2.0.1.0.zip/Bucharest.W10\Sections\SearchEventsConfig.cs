using System;
using System.Collections.Generic;
using AppStudio.DataProviders;
using AppStudio.DataProviders.Core;
using AppStudio.DataProviders.Bing;
using AppStudio.Uwp.Actions;
using AppStudio.Uwp.Commands;
using AppStudio.Uwp.Navigation;
using Bucharest.Config;
using Bucharest.ViewModels;

namespace Bucharest.Sections
{
    public class SearchEventsConfig : SectionConfigBase<BingDataConfig, BingSchema>
    {
        public override DataProviderBase<BingDataConfig, BingSchema> DataProvider
        {
            get
            {
                return new BingDataProvider();
            }
        }

        public override BingDataConfig Config
        {
            get
            {
                return new BingDataConfig
                {
                    Country = BingCountry.Romania,
                    Query = @"bucharest events"
                };
            }
        }

        public override NavigationInfo ListNavigationInfo
        {
            get 
            {
                return NavigationInfo.FromPage("SearchEventsListPage");
            }
        }

        public override ListPageConfig<BingSchema> ListPage
        {
            get 
            {
                return new ListPageConfig<BingSchema>
                {
                    Title = "Search Events",

                    LayoutBindings = (viewModel, item) =>
                    {
                        viewModel.Title = item.Title.ToSafeString();
                        viewModel.SubTitle = item.Summary.ToSafeString();
                        viewModel.Description = null;
                        viewModel.Image = null;
                    },
                    NavigationInfo = (item) =>
                    {
                        return new NavigationInfo
                        {
                            NavigationType = NavigationType.DeepLink,
                            TargetUri = new Uri(item.Link)
                        };
                    }
                };
            }
        }

        public override DetailPageConfig<BingSchema> DetailPage
        {
            get { return null; }
        }

        public override string PageTitle
        {
            get { return "Search Events"; }
        }
    }
}
