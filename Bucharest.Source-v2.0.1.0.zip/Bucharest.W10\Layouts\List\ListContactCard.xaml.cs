namespace Bucharest.Layouts.List
{
    public sealed partial class ListContactCard : ListLayoutBase
    {
        public ListContactCard()
        {
            this.InitializeComponent();
        }
    }
}
