namespace Bucharest.Layouts.List
{
    public sealed partial class MenuBig : ListLayoutBase
    {
        public MenuBig()
        {
            this.InitializeComponent();
        }
    }
}
