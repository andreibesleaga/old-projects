<?php

// zShaped 1.2 - copyright (c) 2003 Andrei Besleaga

// sample configuration file
// use this if you cannot install with the installer
// modify the values below with the right ones
// do not touch ADMINUSER and ADMINPASS - they are empty so that you can login free to admin panel and change them from there
// the ones empty are optional and you can leave them empty

// general configuration options

define("SITEURL","http://localhost"); // the URL (address) of your website (http://www.yourdomain.com)
define("ZURL","http://localhost/news/");	// full URL to zShaped script
define("ZPATH","/var/www/test/news/"); // path to zShaped script
define("READER_PAGE","http://localhost/index.php"); // url to page where readnews.php is included
define("NEWSFILE","news.php"); // you can change this value if you rename your 'news.php' file
define("ADMINUSER",""); // admin username
define("ADMINPASS","d41d8cd98f00b204e9800998ecf8427e"); // crypted empty admin password
define("LOGLOGIN","yes"); // if 'yes' then all admin logins are logged
define("LOGFILE","log.php"); // log file name
define("BLOGAPI_ENABLED","yes"); // if 'yes' then blogger API is enabled and you can edit/add/delete news with a remote client



// news reader options

define("PERPAGE",3); // change to how many news you want displayed on a page - 0=none
define("ZNTEMPLATE","templates/readnews/default"); // the template used for showing news (subdirectory of zShaped where template html files are located)
define("DATEFORMAT","D, d M Y H:m:s"); // date format (PHP date function compatible)
define("SENDTOFRIEND","enabled"); // if 'enabled' then send_to_friend news emailing system is enabled
define("COPYRIGHT","yes"); // if 'no' then only the news system name is displayed
define("TRACKBACK_ENABLED","yes"); // if 'yes' then trackbacking is enabled
define("TRACKBACKSDIR","trackbacks/"); // directory where trackbacks are stored



// news syndication options

define("RSS_NR",10);	// how many latest news to syndicate; 0 - RSS syndication disabled
define("RSS_XML_ENCODING","");	// the RSS XML charset
define("RSS_CHANNEL","a zShaped channel"); // the RSS Channel (feed) name
define("RSS_DESC","powered by zShaped"); // the RSS channel description
define("RSS_LANG","en"); // the RSS language
define("RSS_WEBMASTER",""); //the webmaster's email address
define("RSS_EDITOR",""); // the news managing editor email address
define("RSS_COPYRIGHT",""); // copyright notice for news in the channel
define("RSS_DOMAIN",""); // category domain (ex.: Syndic8)
define("RSS_CATEGORY",""); // category id (ex.: 1756)
define("RSS_TTL",""); // feed time to live (nr. of minutes for which aggregators can cache content)
define("RSS_IMAGE_TITLE","a zShaped channel"); // channel logo title
define("RSS_IMAGE_URL","http://zvonnews.sourceforge.net/images/rsslogo.gif"); // channel logo url
define("RSS_IMAGE_LINK","http://zvonnews.sourceforge.net"); // channel logo link
define("RSS_IMAGE_DESC","zShaped - PHP scripts for news management and RSS syndication"); // channel logo description
define("RSS_IMAGE_WIDTH",""); // channel logo width
define("RSS_IMAGE_HEIGHT",""); // channel logo height
define("RSS_DISABLED_TITLE","News is disabled !"); // when RSS is disabled then feed will generate this title
define("RSS_DISABLED_DESC","News on this channel has been disabled by webmaster"); // when RSS is disabled then feed will generate this description
define("RSS_DESC_LENGTH",0); // RSS items description length (news content length) -1 no description, 0 full description
define("RSS_ITEM_PUBDATE","no"); // if date format is RFC 822 compatible then if this is yes pubdate will be generated for each item



//////END OF CONFIGURATION///////////////////////////////////////////////////

define("ZNVER","1.2"); // current zShaped version - do not modify
?>