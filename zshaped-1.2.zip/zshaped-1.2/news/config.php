<?php
// zShaped 1.2 - copyright (c) 2003 Andrei Besleaga
// configuration file
?>