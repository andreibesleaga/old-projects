<?

// zShaped 1.2 - copyright (c) 2003 Andrei Besleaga
// http://zvonnews.sourceforge.net

// This program is free software; you can redistribute it and/or
// modify it under the terms of the GNU General Public License
// as published by the Free Software Foundation; either version 2
// of the License, or (at your option) any later version.

// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with this program; if not, write to the Free Software
// Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.


require('config.php');
if(SENDTOFRIEND!='enabled') { echo "<html><head><meta http-equiv=\"refresh\" content=\"4;URL=".SITEURL."\"><title>news emailing system disabled</title></head><body><center>news emailing system has been disabled by webmaster ...<br>you will be taken shortly to our <a href=\"".SITEURL."\">site</a> ...</center></body></html>"; exit;}
$x=file(ZPATH.NEWSFILE);
$x=array_reverse($x);
if( $_GET['msg']>=0 && $_GET['msg']<=count($x)-1 && is_numeric($_GET['msg']) )
{
?>
<html>
<head>
<title>zShaped send to friend</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<style type="text/css">
	a:link {color: blue}
	a:visited {color: #5F5FB8}
	a:hover {color: #EE7A06}
	a:active {color: blue}
</style>
</head>

<body>
<table width="222" border="0" align="center">
  <tr align="left" valign="middle"> 
    <td width="15%" valign="middle"><strong><font color="#006699" size="2" face="Verdana, Arial, Helvetica, sans-serif"><img src="images/zslogo.gif" width="80" height="15"> 
      </font></strong></td>
    <td width="85%" align="center" valign="middle"><strong><font color="#006699" size="2" face="Verdana, Arial, Helvetica, sans-serif"> 
      zShaped<br>
      send news to friend</font></strong></td>
  </tr>
</table>
<form name="form1" action="<? echo $_SERVER['PHP_SELF'].'?id=send&mesg='.$_GET['msg'];?>" method="post">
  <table width="435" border="0" align="center" bordercolor="#CCCCCC">
    <tr align="center" valign="middle" bgcolor="#D0ECFD"> 
      <td height="15" colspan="2" align="center" valign="middle">&nbsp; </td>
    </tr>
    <tr align="center" valign="middle" bgcolor="#F4F4F4"> 
      <td width="209" height="21" align="right" valign="middle"><font color="#000066" size="2" face="Verdana, Arial, Helvetica, sans-serif">your 
        name:</font></td>
      <td width="216" align="left" valign="middle"> <input type="text" name="name" style="border-style:groove"></input> 
      </td>
    </tr>
    <tr align="center" valign="middle" bgcolor="#F4F4F4"> 
      <td height="21" align="right" valign="middle"><font color="#000066" size="2" face="Verdana, Arial, Helvetica, sans-serif">your 
        email:</font></td>
      <td height="21" align="left" valign="middle"> <input type="text" name="email1" style="border-style:groove"></input> 
      </td>
    </tr>
    <tr align="center" valign="middle" bgcolor="#F4F4F4"> 
      <td height="21" colspan="2" align="right" valign="middle"><font color="#000066" size="2" face="Verdana, Arial, Helvetica, sans-serif">&nbsp;</font></td>
    </tr>
    <tr align="center" valign="middle" bgcolor="#F4F4F4"> 
      <td height="21" align="right" valign="middle"><font color="#000066" size="2" face="Verdana, Arial, Helvetica, sans-serif">friend's 
        email:</font></td>
      <td height="21" align="left" valign="middle"> <input type="text" name="email2" style="border-style:groove"></input> 
      </td>
    </tr>
    <tr align="center" valign="middle" bgcolor="#F4F4F4"> 
      <td height="21" align="right" valign="middle"><font color="#000066" size="2" face="Verdana, Arial, Helvetica, sans-serif">subject 
        :</font></td>
      <td height="21" align="left" valign="middle"> <input type="text" name="subject" style="border-style:groove"></input> 
      </td>
    </tr>
    <tr align="center" valign="bottom" bgcolor="#F4F4F4"> 
      <td height="18" colspan="2">&nbsp;</td>
    </tr>
    <tr align="left" valign="middle" bgcolor="#F4F4F4"> 
      <td height="9" align="right" valign="middle"><font color="#000066" size="2" face="Verdana, Arial, Helvetica, sans-serif">email 
        template :</font></td>
      <td height="9" valign="middle"><font color="#000066" size="2" face="Verdana, Arial, Helvetica, sans-serif"> 
        <select name="emailtemplate" style="border-style:groove">
		<?		$handle = opendir(ZPATH."templates/sendtofriend"); 
				while($dirfile = readdir($handle))
				{ 
					if( is_dir(ZPATH.'templates/sendtofriend/'.$dirfile) && $dirfile!='.' && $dirfile!='..' && file_exists(ZPATH.'templates/sendtofriend/'.$dirfile.'/email.html') )
					{ echo "<option value=\"$dirfile\">$dirfile</option>"; 	}
				} 
				closedir($handle); 
		 ?>
        </select>
        </font></td>
    </tr>
    <tr align="left" valign="middle" bgcolor="#F4F4F4"> 
      <td height="9" colspan="2" align="right" valign="middle">&nbsp;</td>
    </tr>
    <tr align="left" valign="middle" bgcolor="#F4F4F4"> 
      <td height="9" align="right" valign="middle"><font color="#000066" size="2" face="Verdana, Arial, Helvetica, sans-serif">news 
        :</font></td>
      <td height="9" align="left" valign="middle"><font color="#000066" size="2" face="Verdana, Arial, Helvetica, sans-serif">
	  <?	$newsdata=explode("%~#",$x[$_GET['msg']]);
			echo $newsdata[0].'<br>'.$newsdata[1];
	  ?></font></td>
    </tr>
    <tr align="left" valign="middle" bgcolor="#F4F4F4"> 
      <td height="9" colspan="2" align="right" valign="middle">&nbsp;</td>
    </tr>
    <tr align="center" valign="middle" bgcolor="#F4F4F4"> 
      <td height="77" align="center" valign="middle"><font size="2" face="Verdana, Arial, Helvetica, sans-serif"> 
        <a href="<? echo $_SERVER['PHP_SELF'].'?id=send&mesg='.$_GET['msg'];?>"> 
        <input name="imageField" type="image" src="images/email.gif" alt="send" width="40" height="40" border="0">
        <br>
        send</a> </td>
      <td height="77" align="center" valign="middle"><a href="JavaScript:history.back()"><img src="images/back.gif" alt="go back" width="40" height="40" border="0"><br>
        <font size="2" face="Verdana, Arial, Helvetica, sans-serif">go back</font></a></td>
    </tr>
    <tr align="center" valign="middle" bgcolor="#D0ECFD"> 
      <td height="15" colspan="2">&nbsp;</td>
    </tr>
    <tr align="center" valign="middle"> 
      <td height="15" colspan="2"><font size="2" face="Verdana, Arial, Helvetica, sans-serif"> 
        powered by <a href="http://zvonnews.sourceforge.net"> zShaped <? echo ZNVER;?></a> 
        - copyright (c)2003 Andrei Besleaga</font></td>
    </tr>
  </table>
</form>
</body>
</html>

<? } elseif($_GET['id']=='send' && $_GET['mesg']>=0 && $_GET['mesg']<=count($x)-1 && is_numeric($_GET['mesg']) )
{ ?>

	<html>
	<head>
	<title>zShaped send to friend</title>
	<style type="text/css">
		a:link {color: blue}
		a:visited {color: #5F5FB8}
		a:hover {color: #EE7A06}
		a:active {color: blue}
	</style>
	</head>
	
	<body>
	<table width="222" border="0" align="center">
	  <tr align="left" valign="middle"> 
		<td width="15%" valign="middle"><strong><font color="#006699" size="2" face="Verdana, Arial, Helvetica, sans-serif"><img src="images/logo.gif" /> 
		  </font></strong></td>
		<td width="85%" align="center" valign="middle"><strong><font color="#006699" size="2" face="Verdana, Arial, Helvetica, sans-serif"> 
		  zShaped <br>
		  send news to friend</font></strong></td>
	  </tr>
	</table>
	<table width="435" border="0" align="center" bordercolor="#CCCCCC">
	  <tr align="center" valign="middle" bgcolor="#D0ECFD"> 
		<td height="15" colspan="2" align="center" valign="middle">&nbsp; </td>
	  </tr>
	  <tr align="center" valign="middle" bgcolor="#F4F4F4"> 
		<td height="21" colspan="2" align="center" valign="middle"><font color="#000066" size="2" face="Verdana, Arial, Helvetica, sans-serif">
		<? 	
			function template_exists($templatedir, $echoexit=false)
			{
				if(!file_exists($templatedir."/email.html")) {$x=false;}
				else {$x=true;}
				if($echoexit==true && $x==false) 
				{	
					echo "<font color=\"red\"><b>Error: one or more template files ( $templatedir ) doesn't exist.<br>Make sure templates exists and are readable and define it in the script ...</b></font>";
					exit;
				}
				return $x;
			}
			
			function load($file)
			{	
				$temp=file($file);
				foreach($temp as $i=>$htmldata) {$html.=$htmldata;}
				return $html;
			}
			function parse_template($html)
			{	global $tmpdate, $tmptitle, $tmpnews, $sface;
				$html=str_replace("{pubdate}",$tmpdate,$html);
				$html=str_replace("{newstitle}",$tmptitle,$html);
				$html=str_replace("{newscontent}",$tmpnews,$html);
				$html=str_replace("{websiteurl}",SITEURL,$html);
				$html=str_replace("{visitorname}",$_POST['name'],$html);
				$html=str_replace("{visitoremail}",$_POST['email1'],$html);
				foreach($sface as $sfname => $sffile)
					{ $html=str_replace($sfname,"<img src=\"".ZURL."smilies/".$sffile."\"></img>",$html); }
				return $html."<br>news powered by <a href=\"http://zvonnews.sourceforge.net\">zShaped ".ZNVER."</a>";
			}
			
			function eco($towrite,$color)
			{
				echo "<font color=\"$color\">$towrite</font>";
			}
			function valid_email($email) 
			{
				 $pattern = "^[-_.[:alnum:]]+@((([[:alnum:]]|[[:alnum:]][[:alnum:]-]*[[:alnum:]])\.)+(ad|ae|aero|af|ag|ai|al|am|an|ao|aq|ar|arpa|as|at|au|aw|az|ba|bb|bd|be|bf|bg|bh|bi|biz|bj|bm|bn|bo|br|bs|bt|bv|bw|by|bz|ca|cc|cd|cf|cg|ch|ci|ck|cl|cm|cn|co|com|coop|cr|cs|cu|cv|cx|cy|cz|de|dj|dk|dm|do|dz|ec|edu|ee|eg|eh|er|es|et|eu|fi|fj|fk|fm|fo|fr|ga|gb|gd|ge|gf|gh|gi|gl|gm|gn|gov|gp|gq|gr|gs|gt|gu|gw|gy|hk|hm|hn|hr|ht|hu|id|ie|il|in|info|int|io|iq|ir|is|it|jm|jo|jp|ke|kg|kh|ki|km|kn|kp|kr|kw|ky|kz|la|lb|lc|li|lk|lr|ls|lt|lu|lv|ly|ma|mc|md|mg|mh|mil|mk|ml|mm|mn|mo|mp|mq|mr|ms|mt|mu|museum|mv|mw|mx|my|mz|na|name|nc|ne|net|nf|ng|ni|nl|no|np|nr|nt|nu|nz|om|org|pa|pe|pf|pg|ph|pk|pl|pm|pn|pr|pro|ps|pt|pw|py|qa|re|ro|ru|rw|sa|sb|sc|sd|se|sg|sh|si|sj|sk|sl|sm|sn|so|sr|st|su|sv|sy|sz|tc|td|tf|tg|th|tj|tk|tm|tn|to|tp|tr|tt|tv|tw|tz|ua|ug|uk|um|us|uy|uz|va|vc|ve|vg|vi|vn|vu|wf|ws|ye|yt|yu|za|zm|zw)|(([0-9][0-9]?|[0-1][0-9][0-9]|[2][0-4][0-9]|[2][5][0-5])\.){3}([0-9][0-9]?|[0-1][0-9][0-9]|[2][0-4][0-9]|[2][5][0-5]))$";
				 if(eregi($pattern, $email)) return true;  else  return false;
			}
			$allok=true;
			if($_POST['name']=='') {eco('<hr><br>No name given.<br>Please go back and try again ...<hr>','red');$allok=false;}
			if($_POST['subject']=='') {eco('<hr><br>No subject.<br>Please go back and try again ...<hr>','red');$allok=false;}
			if(!valid_email($_POST['email1'])) {eco('<hr><br>Wrong email.<br>Please go back and try again ...<hr>','red');$allok=false;}
			if(!valid_email($_POST['email2'])) {eco('<hr><br>Wrong friend email.<br>Please go back and try again ...<hr>','red');$allok=false;}
			if( $_POST['emailtemplate']=='' || !template_exists(ZPATH.'templates/sendtofriend/'.$_POST['emailtemplate']) )  {eco('<hr><br>Template error ...<br><hr>','red');$allok=false;}
			if($allok==true)
			{
				include(ZPATH.'smileys.php');
				$crt=explode("%~#",$x[$_GET['mesg']]);
				$tmpdate=$crt[0];
				$tmptitle=$crt[1];
				$tmpnews=$crt[2];
				$message=load(ZPATH.'templates/sendtofriend/'.$_POST['emailtemplate'].'/email.html');
				$message=parse_template($message);
				$headers  = "MIME-Version: 1.0\r\n";
				$headers .= "Content-type: text/html; charset=iso-8859-1\r\n";
				$headers .= "From: ".$_POST['email1']."\r\n";
				@$issent=mail($_POST['email2'],$_POST['subject'],$message,$headers);
				if($issent) eco('Mail sent succesfully.<br>','green');
				else eco('Mail could not be sent.<br>Check with the site admin or webhost if the mail function is available.<br>','red');
			} 
			echo "<table width=\"200\" border=\"0\"><tr align=\"center\" valign=\"middle\">";
			echo "<td><a href=\"JavaScript:history.back()\"><img src=\"".ZURL."images/back.gif\" alt=\"go back\" width=\"40\" height=\"40\" border=\"0\"><br><font size=\"2\" face=\"Verdana, Arial, Helvetica, sans-serif\">go back</font></a></td>";
			echo "<td><a href=\"".SITEURL."\"><img src=\"".ZURL."images/www.gif\" width=\"40\" alt=\"go to website\" height=\"40\" border=\"0\"><br><font size=\"2\" face=\"Verdana, Arial, Helvetica, sans-serif\">go to site</font></a></td>";			
			echo "</tr></table>";
		?></font></td>
	  <tr align="center" valign="middle" bgcolor="#D0ECFD"> 
		<td height="15" colspan="2">&nbsp;</td>
	  </tr>
	  <tr align="center" valign="middle"> 
		<td height="15" colspan="2"><font size="2" face="Verdana, Arial, Helvetica, sans-serif"> 
		  powered by <a href="http://zvonnews.sourceforge.net"> zShaped <? echo ZNVER;?></a> - &copy;2003 Andrei Besleaga</font></td>
	  </tr>
	</table>
<?
}
?>

