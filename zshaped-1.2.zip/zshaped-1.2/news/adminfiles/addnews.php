<?

// zShaped 1.2 - copyright (c) 2003 Andrei Besleaga
// http://zvonnews.sourceforge.net

// This program is free software; you can redistribute it and/or
// modify it under the terms of the GNU General Public License
// as published by the Free Software Foundation; either version 2
// of the License, or (at your option) any later version.

// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with this program; if not, write to the Free Software
// Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.



if($_SESSION['loggedin']!='true') exit;

	if($_POST['addnew']=='Add News') 
	{

		function pingWeblog($host, $rpcpath, $name, $url)
		{
			if(!defined(RSS_CHANNEL)||RSS_CHANNEL=='') $name = "a zShaped blog";
			$fp = fsockopen($host, 80, &$errnum, &$errstr);
			if(!$fp)
			{ 
			  echo "$errstr ($errnum)<br>\n";
			  $output = "ERROR!";
			} 
			else
			{
			  $len = strlen($name) + strlen($url) + strlen("<?xml version=\"1.0\"?><methodCall><methodName>weblogUpdates.ping</methodName><params><param><value></value></param><param><value></value></param></params></methodCall>");
			  fputs($fp,"POST ".$rpcpath." HTTP/1.0\r\n");
			  fputs($fp,"User-Agent: zShaped ".ZNVER."\r\n");
			  fputs($fp,"Content-Type: text/xml\r\n");
			  fputs($fp,"Content-length: $len\r\n\r\n");
			  fputs($fp,"<?xml version=\"1.0\"?><methodCall><methodName>weblogUpdates.ping</methodName><params><param><value>$name</value></param><param><value>$url</value></param></params></methodCall>");		 
			  $output="";
			  while(!feof($fp)) $output.=fgets($fp,4096);
			  fclose($fp);		 
			}
			$output = preg_replace("/.*<\/boolean>/si","",$output);
			$output = preg_replace("/.*<value>/si","",$output);
			$output = preg_replace("/<\/value>.*/si","",$output);	 	 
			return $output;
		}
		function pingTrackBack($host, $title, $excerpt, $url, $blog_name)
		{
			if(!defined(RSS_CHANNEL)||RSS_CHANNEL=='') $name = "a zShaped blog";
			$addr=parse_url($host);
			$connectto=$addr['host'];
			@$fp = fsockopen($connectto, 80, &$errnum, &$errstr);
			if(!$fp)
			{ 
			  echo "$errstr ($errnum)<br>\n";
			  $output = "ERROR!";
			} 
			else
			{
				$postcontent="title=".urlencode($title)."&url=".urlencode($url)."&excerpt=".urlencode($excerpt)."&blog_name=".urlencode($blog_name)."\n";
				$contlength=strlen($postcontent);
				$postdata="POST $host HTTP/1.0\n";
				$postdata.="Content-Type: application/x-www-form-urlencoded\n";
				$postdata.="Content-Length: $contlength\n\n";
				$postdata.=$postcontent;
				fputs($fp,$postdata);
				$output="";
				while(!feof($fp)) $output.=fgets($fp,4096);
				fclose($fp);		 
			}
			return $output;
		}
	
		$title=$_POST['title'];
		$news=$_POST['news'];
		$date=$_POST['date'];
		$fp=fopen(ZPATH.NEWSFILE,"a");
		$formatted=str_replace("\r\n","<br />",$news);
		$formatted=str_replace("\n","<br />",$formatted);
		$newsto=$date."%~#".$title."%~#".$formatted;
		$rasp=fwrite($fp,StripSlashes($newsto)."\n");
		if($rasp)
		{	fclose($fp);
			echo "<b><center><font color=\"red\"> News added successfully... </font></center></b>";
			if($_POST['weblogscom']=='yes') echo "response from weblogs.com update service: ".pingWeblog("rpc.weblogs.com","/RPC2",RSS_CHANNEL,SITEURL);
			if($_POST['trackbackurl']!='')
			{	
				$toping=split(",",$_POST['trackbackurl']);
				foreach($toping as $i=>$pingurl)
					{ if($pingurl!='') echo "<br />response from the trackback URL: ".pingTrackBack($pingurl,$title,$news,READER_PAGE."?znshowitem=".md5($date.$title),RSS_CHANNEL)."<br />"; }
			}
		}
		else
		{	fclose($fp); echo "<b><center><font color=\"red\"> Error adding news... check if ".ZPATH.NEWSFILE. " exists and it has write permisions</font></center></b>"; }

	}

	function initval($value)
	{
		if($_POST['preview']=='Preview News') echo $value;
	}
	function initdate($value)
	{
		if($_POST['preview']=='Preview News') {echo $value;}
		else {echo date(DATEFORMAT);}
	}
	?>
    <script language="JavaScript">
	function smiley(text) {
		if (document.form1.news.createTextRange && document.form1.news.caretPos) {
			var caretPos = document.form1.news.caretPos;
			caretPos.text = caretPos.text.charAt(caretPos.text.length - 1) == ' ' ?
			text + ' ' : text;
		}
		else document.form1.news.value += text;
		document.form1.news.focus(caretPos)
	}
	</script>
      
<table width="600" align="center">
  <tr>
    <td height="443"> 
	<form name="form1" method="POST" action="<? echo $_SERVER['PHP_SELF'].'?znaction=addnews'; ?>">
	<p align="center"><font size="2" face="Verdana, Arial, Helvetica, sans-serif"><br>
	  Date : 
	      <input name="date" type="text" style="border-style:groove;" value="<? initdate($_POST['date']);?>" size="40">
          </input>
	  </font></p>

	    <p align="center"><font size="2" face="Verdana, Arial, Helvetica, sans-serif">Title 
          : 
          <input name="title" type="text" style="border-style:groove;" value="<? initval($_POST['title']); ?>" size="40"></input> 
          <br>
          <?php
		include(ZPATH.'smileys.php');
		foreach($sface as $sfname=>$sffile)
		{ 
			echo "<a href=\"Javascript:smiley(' ".$sfname." ');\"><img src=\"smilies/$sffile\" border=\"0\"></a> ";
		} 
		?>
          <br>
          <br>
          <a href="Javascript:smiley('<b>text</b>');"><img src="<? echo ZURL;?>images/editor/bold.gif" width="23" height="22" border="0" alt="bold"></a> 
          <a href="Javascript:smiley('<i>text</i>');"><img src="<? echo ZURL;?>images/editor/italic.gif" width="23" height="22" border="0" alt="italic"></a> 
          <a href="Javascript:smiley('<u>text</u>');"><img src="<? echo ZURL;?>images/editor/underline.gif" width="23" height="22" border="0" alt="underline"></a> 
          <a href="Javascript:smiley('<s>text</s>');"><img src="<? echo ZURL;?>images/editor/strike.gif" width="23" height="22" border="0" alt="strike"></a> 
          <a href="Javascript:smiley('<font face=&quot;verdana&quot;>text</font>');"><img src="<? echo ZURL;?>images/editor/fontface.gif" width="23" height="22" border="0" alt="fontface"></a> 
          <a href="Javascript:smiley('<font size=&quot;2&quot;>text</font>');"><img src="<? echo ZURL;?>images/editor/fontsize.gif" width="23" height="22" border="0" alt="fontsize"></a> 
          <a href="Javascript:smiley('<font color=&quot;blue&quot;>text</font>');"><img src="<? echo ZURL;?>images/editor/color.gif" width="23" height="22" border="0" alt="fontcolor"></a> 
          <a href="Javascript:smiley('<font style=&quot;Filter: Glow(color=green, Strength=2); Width=1px;&quot;>TEXT</font>');"><img src="<? echo ZURL;?>images/editor/glow.gif" width="23" height="22" border="0" alt="glow"></a> 
          <a href="Javascript:smiley('<font style=&quot;Filter: Shadow(color=blue, Direction=left); Width=1px;&quot;>TEXT</font>');"><img src="<? echo ZURL;?>images/editor/shadow.gif" width="23" height="22" border="0" alt="shadow"></a> 
          <a href="Javascript:smiley('<sub>text</sub>');"><img src="<? echo ZURL;?>images/editor/sub.gif" width="23" height="22" border="0" alt="subscript"></a> 
          <a href="Javascript:smiley('<sup>text</sup>');"><img src="<? echo ZURL;?>images/editor/sup.gif" width="23" height="22" border="0" alt="superscript"></a> 
          <a href="Javascript:smiley('<p align=&quot;left&quot;>text</p>');"><img src="<? echo ZURL;?>images/editor/fontleft.gif" width="23" height="22" border="0" alt="align"></a> 
          <a href="Javascript:smiley('<marquee>scrolling text</marquee>');"><img src="<? echo ZURL;?>images/editor/move.gif" width="23" height="22" border="0" alt="scroll"></a> 
          <a href="Javascript:smiley('<hr>');"><img src="<? echo ZURL;?>images/editor/hr.gif" width="23" height="22" border="0" alt="hr"></a> 
          <a href="Javascript:smiley('<ul><li>item1<li>item2<li>item3</ul>');"><img src="<? echo ZURL;?>images/editor/list.gif" width="23" height="22" border="0" alt="list"></a> 
          <a href="Javascript:smiley('<blockquote><span class=&quot;12px&quot;>quote:</span><hr>_quotted_text_<hr></blockquote>');"><img src="<? echo ZURL;?>images/editor/quote.gif" width="23" height="22" border="0" alt="quote"></a> 
          <a href="Javascript:smiley('<img src=&quot;URL&quot;>');"><img src="<? echo ZURL;?>images/editor/img.gif" width="23" height="22" border="0" alt="image"></a> 
          <a href="Javascript:smiley('<a href=&quot;mailto:username@site.com&quot;>mail me</a>');"><img src="<? echo ZURL;?>images/editor/email.gif" width="23" height="22" border="0" alt="mailto"></a> 
          <a href="Javascript:smiley('<a href=&quot;http://www.url.com&quot;>address</a>');"><img src="<? echo ZURL;?>images/editor/url.gif" width="23" height="22" border="0" alt="url"></a> 
          </font> <font size="2" face="Verdana, Arial, Helvetica, sans-serif"> 
          <textarea name="news" rows="13" cols="60" style="border-style:groove;"><? initval($_POST['news']); ?></textarea>
          <br>
          note: HTML code is permitted <br>
          <br>
          Notify (ping) <a href="http://www.weblogs.com">weblogs.com</a> : 
          <select name="weblogscom" id="weblogscom">
            <option value="yes">yes</option>
            <option value="no" selected>no</option>
          </select>
          <br>
          <br>
          Notify (ping) TrackBack URL : 
          <input name="trackbackurl" type="text" id="trackbackurl" size="30" style="border-style:groove" />
          <br>
          <br>
          <br>
          </font></p>
	  <p align="center"><font size="2" face="Verdana, Arial, Helvetica, sans-serif"> 
		<input type="submit" name="addnew" value="Add News" style="border-style:groove"></input> 
		&nbsp;
		<input type="submit" name="preview" value="Preview News" style="border-style:groove"></input>
		</font></p>
	  <font size="2" face="Verdana, Arial, Helvetica, sans-serif"> 
	  <input type="hidden" name="do" value="addnew">
		<?php
		if($_POST['preview']=='Preview News') 
		{
			function template_exists($templatedir, $echoexit=false)
			{
				if(!file_exists($templatedir."/news.html")) {$x=false;}
				elseif(!file_exists($templatedir."/header.html")) {$x=false;}
				elseif(!file_exists($templatedir."/footer.html")) {$x=false;}
				else {$x=true;}
				if($echoexit==true && $x==false) 
				{	
					echo "<font color=\"red\"><b>Error: one or more template files ( $templatedir ) doesn't exist.<br>Make sure templates exists and are readable and define it in the script ...</b></font>";
					exit;
				}
				return $x;
			}
			
			function load($file)
			{	global $crttemplate;
				$temp=file($crttemplate.'/'.$file);
				foreach($temp as $i=>$htmldata) {$html.=$htmldata;}
				return $html;
			}

			function parse_template($html)
			{	global $tmpdate, $tmptitle, $tmpnews, $tmpmsg, $sface;
				$html=str_replace("{pubdate}",$tmpdate,$html);
				$html=str_replace("{newstitle}",$tmptitle,$html);
				$html=str_replace("{newscontent}",$tmpnews,$html);
				$html=str_replace("{tofriendurl}",ZURL.'tofriend.php?msg='.$tmpmsg,$html);
				$html=str_replace("{zvonurl}",ZURL,$html);
				$html=str_replace("{trackback}",'',$html);
				//$html=str_replace("{pagetab}",pagetab($startpage,$ubound-1),$html);
				foreach($sface as $sfname => $sffile)
					{ $html=str_replace($sfname,"<img src=\"".ZURL."smilies/".$sffile."\"></img>",$html); }
				return $html;
			}

			include(ZPATH.'smileys.php');
			set_magic_quotes_runtime(0);

			if(template_exists(ZPATH.ZNTEMPLATE,true)) 
			{	
				$crttemplate=ZPATH.ZNTEMPLATE;
				$htmlnews=load('news.html');
			}
					
			$tmpdate=$_POST['date'];
			$tmptitle=$_POST['title'];
			$tmpnews=str_replace("\r\n","<br>",$_POST['news']);
			$tmpnews=str_replace("\n","<br>",$tmpnews);
			echo(parse_template($htmlnews));				
		}
	  ?>
	</form>
	</td></tr></table>