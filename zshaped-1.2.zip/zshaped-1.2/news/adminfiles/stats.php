<? 

// zShaped 1.2 - copyright (c) 2003 Andrei Besleaga
// http://zvonnews.sourceforge.net

// This program is free software; you can redistribute it and/or
// modify it under the terms of the GNU General Public License
// as published by the Free Software Foundation; either version 2
// of the License, or (at your option) any later version.

// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with this program; if not, write to the Free Software
// Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.

if($_SESSION['loggedin']!='true') exit;
?>


		
      
<table width="500" border="0" align="center" >
  <tr align="left" valign="top" bgcolor="#E1E3E8"> 
    <td height="20" colspan="2" align="center"><font color="#000066" size="2" face="Verdana, Arial, Helvetica, sans-serif">live&nbsp;statistics</font></td>
  </tr>
  <tr align="left" valign="top" bgcolor="#EFEFEF"> 
    <td height="20" align="right" bgcolor="#EFEFEF"><font color="#000066" size="2" face="Verdana, Arial, Helvetica, sans-serif">newsfile 
      exists:</font></td>
    <td height="20" align="left" valign="top" bgcolor="#EFEFEF"><font size="2" face="Verdana, Arial, Helvetica, sans-serif">&nbsp; 
      <? if(file_exists(ZPATH.NEWSFILE)){eco('yes','green');} else {eco('no','red');} ?>
      </font></td>
  </tr>
  <tr align="left" valign="top" bgcolor="#EFEFEF"> 
    <td height="20" align="right" bgcolor="#EFEFEF"><font color="#000066" size="2" face="Verdana, Arial, Helvetica, sans-serif">news 
      found: </font></td>
    <td height="20" align="left" valign="top" bgcolor="#EFEFEF"><font color="#000066" size="2" face="Verdana, Arial, Helvetica, sans-serif">&nbsp; 
      <? @$x=file(ZPATH.NEWSFILE); eco((count($x)-1),'green'); ?>
      </font></td>
  </tr>
  <tr align="left" valign="top" bgcolor="#EFEFEF"> 
    <td height="21" align="right" bgcolor="#EFEFEF"><font color="#000066" size="2" face="Verdana, Arial, Helvetica, sans-serif">newsfile 
      size:</font></td>
    <td height="21" align="left" valign="top" bgcolor="#EFEFEF"><font color="#000066" size="2" face="Verdana, Arial, Helvetica, sans-serif">&nbsp; 
      <? @$x=filesize(ZPATH.NEWSFILE); eco((number_format(($x/1024),2)).' KB','green'); ?>
      </font></td>
  </tr>
  <tr align="left" valign="top" bgcolor="#EFEFEF"> 
    <td height="20" align="right" bgcolor="#EFEFEF"><font color="#000066" size="2" face="Verdana, Arial, Helvetica, sans-serif">newsfile 
      is writable:</font></td>
    <td height="20" align="left" valign="top" bgcolor="#EFEFEF"><font color="#000066" size="2" face="Verdana, Arial, Helvetica, sans-serif">&nbsp; 
      <? if(is_writable(ZPATH.NEWSFILE)) {eco('yes','green');} else {eco('no','red');} ;?>
      </font></td>
  </tr>
  <tr align="left" valign="top" bgcolor="#EFEFEF"> 
    <td height="20" align="right" bgcolor="#EFEFEF"><font color="#000066" size="2" face="Verdana, Arial, Helvetica, sans-serif">last 
      modified on:</font></td>
    <td height="20" align="left" valign="top" bgcolor="#EFEFEF"><font color="#000066" size="2" face="Verdana, Arial, Helvetica, sans-serif">&nbsp; 
      <? eco(date(DATEFORMAT,filemtime(ZPATH.NEWSFILE)),'green');?>
      </font></td>
  </tr>
  <tr align="left" valign="top" bgcolor="#EFEFEF"> 
    <td height="18" colspan="2" align="right" bgcolor="#EFEFEF"><font size="2" face="Verdana, Arial, Helvetica, sans-serif">&nbsp;</font></td>
  </tr>
  <tr align="left" valign="top" bgcolor="#EFEFEF"> 
    <td height="20" align="right" bgcolor="#EFEFEF"><font color="#000066" size="2" face="Verdana, Arial, Helvetica, sans-serif">logfile 
      exists: </font></td>
    <td height="20" align="left" valign="top" bgcolor="#EFEFEF"><font color="#000066" size="2" face="Verdana, Arial, Helvetica, sans-serif">&nbsp; 
      <? if(file_exists(ZPATH.LOGFILE)){eco('yes','green');} else {eco('no','red');} ?>
      </font></td>
  </tr>
  <tr align="left" valign="top" bgcolor="#EFEFEF"> 
    <td height="20" align="right" bgcolor="#EFEFEF"><font color="#000066" size="2" face="Verdana, Arial, Helvetica, sans-serif">log 
      entries:</font></td>
    <td height="20" align="left" valign="top" bgcolor="#EFEFEF"><font color="#000066" size="2" face="Verdana, Arial, Helvetica, sans-serif"> 
      &nbsp; 
      <? @$x=file(ZPATH.LOGFILE); eco((count($x)-1),'green'); ?>
      </font></td>
  </tr>
  <tr align="left" valign="top" bgcolor="#EFEFEF"> 
    <td height="20" align="right" bgcolor="#EFEFEF"><font color="#000066" size="2" face="Verdana, Arial, Helvetica, sans-serif">logfile 
      size: </font></td>
    <td height="20" align="left" valign="top" bgcolor="#EFEFEF"><font color="#000066" size="2" face="Verdana, Arial, Helvetica, sans-serif">&nbsp; 
      <? @$x=filesize(ZPATH.LOGFILE); eco((number_format(($x/1024),2)).' KB','green'); ?>
      </font></td>
  </tr>
  <tr align="left" valign="top" bgcolor="#EFEFEF"> 
    <td height="20" align="right" bgcolor="#EFEFEF"><font color="#000066" size="2" face="Verdana, Arial, Helvetica, sans-serif">logfile 
      is writable:</font></td>
    <td height="20" align="left" valign="top" bgcolor="#EFEFEF"><font color="#000066" size="2" face="Verdana, Arial, Helvetica, sans-serif">&nbsp; 
      <? if(is_writable(ZPATH.LOGFILE)) {eco('yes','green');} else {eco('no','red');} ;?>
      </font></td>
  </tr>
  <tr align="left" valign="top" bgcolor="#EFEFEF"> 
    <td height="20" align="right" bgcolor="#EFEFEF"><font color="#000066" size="2" face="Verdana, Arial, Helvetica, sans-serif">last 
      modified on:</font></td>
    <td height="20" align="left" valign="top" bgcolor="#EFEFEF"><font color="#000066" size="2" face="Verdana, Arial, Helvetica, sans-serif">&nbsp; 
      <? eco(date(DATEFORMAT,filemtime(ZPATH.LOGFILE)),'green');?>
      </font></td>
  </tr>
  <tr align="left" valign="top" bgcolor="#EFEFEF"> 
    <td height="21" colspan="2" align="right" bgcolor="#EFEFEF">&nbsp;</td>
  </tr>
  <tr align="center" valign="top" bgcolor="#EFEFEF"> 
    <td height="20" colspan="2"><font color="#000066" size="2" face="Verdana, Arial, Helvetica, sans-serif"> 
      existing script files</font></td>
  </tr>
  <tr align="left" valign="top" bgcolor="#EFEFEF"> 
    <td height="20" align="right" bgcolor="#EFEFEF"><font color="#000066" size="2" face="Verdana, Arial, Helvetica, sans-serif">admin.php</font></td>
    <td height="20" align="left" valign="top" bgcolor="#EFEFEF"><font color="#000066" size="2" face="Verdana, Arial, Helvetica, sans-serif">&nbsp; 
      <? if(file_exists('admin.php')){eco('yes','green');} else {eco('no','red');} ?>
      </font></td>
  </tr>
  <tr align="left" valign="top" bgcolor="#EFEFEF"> 
    <td height="20" align="right" bgcolor="#EFEFEF"><font color="#000066" size="2" face="Verdana, Arial, Helvetica, sans-serif">blogapi.php</font></td>
    <td height="20" align="left" valign="top" bgcolor="#EFEFEF"><font color="#000066" size="2" face="Verdana, Arial, Helvetica, sans-serif">&nbsp; 
      <? if(file_exists('blogapi.php')){eco('yes','green');} else {eco('no','red');} ?>
      </font></td>
  </tr>
  <tr align="left" valign="top" bgcolor="#EFEFEF"> 
    <td height="20" align="right" bgcolor="#EFEFEF"><font color="#000066" size="2" face="Verdana, Arial, Helvetica, sans-serif">config.php</font></td>
    <td height="20" align="left" valign="top" bgcolor="#EFEFEF"><font color="#000066" size="2" face="Verdana, Arial, Helvetica, sans-serif">&nbsp; 
      <? if(file_exists('config.php')){eco('yes','green');} else {eco('no','red');} ?>
      </font></td>
  </tr>
  <tr align="left" valign="top" bgcolor="#EFEFEF"> 
    <td height="20" align="right" bgcolor="#EFEFEF"><font color="#000066" size="2" face="Verdana, Arial, Helvetica, sans-serif">index.php</font></td>
    <td height="20" align="left" valign="top" bgcolor="#EFEFEF"><font color="#000066" size="2" face="Verdana, Arial, Helvetica, sans-serif">&nbsp; 
      <? if(file_exists('index.php')){eco('yes','green');} else {eco('no','red');} ?>
      </font></td>
  </tr>
  <tr align="left" valign="top" bgcolor="#EFEFEF"> 
    <td height="20" align="right" bgcolor="#EFEFEF"><font color="#000066" size="2" face="Verdana, Arial, Helvetica, sans-serif">install.php</font></td>
    <td height="20" align="left" valign="top" bgcolor="#EFEFEF"><font color="#000066" size="2" face="Verdana, Arial, Helvetica, sans-serif">&nbsp; 
      <? if(file_exists('install.php')){eco('yes','red');} else {eco('no','green');} ?>
      </font></td>
  </tr>
  <tr align="left" valign="top" bgcolor="#EFEFEF"> 
    <td height="20" align="right" bgcolor="#EFEFEF"><font color="#000066" size="2" face="Verdana, Arial, Helvetica, sans-serif">readnews.php</font></td>
    <td height="20" align="left" valign="top" bgcolor="#EFEFEF"><font color="#000066" size="2" face="Verdana, Arial, Helvetica, sans-serif">&nbsp; 
      <? if(file_exists('readnews.php')){eco('yes','green');} else {eco('no','red');} ?>
      </font></td>
  </tr>
  <tr align="left" valign="top" bgcolor="#EFEFEF"> 
    <td height="20" align="right" bgcolor="#EFEFEF"><font color="#000066" size="2" face="Verdana, Arial, Helvetica, sans-serif">rss.php</font></td>
    <td height="20" align="left" valign="top" bgcolor="#EFEFEF"><font color="#000066" size="2" face="Verdana, Arial, Helvetica, sans-serif">&nbsp; 
      <? if(file_exists('rss.php')){eco('yes','green');} else {eco('no','red');} ?>
      </font></td>
  </tr>
  <tr align="left" valign="top" bgcolor="#EFEFEF"> 
    <td height="20" align="right" bgcolor="#EFEFEF"><font color="#000066" size="2" face="Verdana, Arial, Helvetica, sans-serif">search.php</font></td>
    <td height="20" align="left" valign="top" bgcolor="#EFEFEF"><font color="#000066" size="2" face="Verdana, Arial, Helvetica, sans-serif">&nbsp; 
      <? if(file_exists('search.php')){eco('yes','green');} else {eco('no','red');} ?>
      </font></td>
  </tr>
  <tr align="left" valign="top" bgcolor="#EFEFEF"> 
    <td height="20" align="right" bgcolor="#EFEFEF"><font color="#000066" size="2" face="Verdana, Arial, Helvetica, sans-serif">smileys.php</font></td>
    <td height="20" align="left" valign="top" bgcolor="#EFEFEF"><font color="#000066" size="2" face="Verdana, Arial, Helvetica, sans-serif">&nbsp; 
      <? if(file_exists('smileys.php')){eco('yes','green');} else {eco('no','red');} ?>
      </font></td>
  </tr>
  <tr align="left" valign="top" bgcolor="#EFEFEF"> 
    <td height="20" align="right" bgcolor="#EFEFEF"><font color="#000066" size="2" face="Verdana, Arial, Helvetica, sans-serif">tofriend.php</font></td>
    <td height="20" align="left" valign="top" bgcolor="#EFEFEF"><font size="2" face="Verdana, Arial, Helvetica, sans-serif">&nbsp; 
      <? if(file_exists('tofriend.php')){eco('yes','green');} else {eco('no','red');} ?>
      </font></td>
  </tr>
  <tr align="left" valign="top" bgcolor="#EFEFEF"> 
    <td height="20" align="right" bgcolor="#EFEFEF"><font color="#000066" size="2" face="Verdana, Arial, Helvetica, sans-serif">trackback.php</font></td>
    <td height="20" align="left" valign="top" bgcolor="#EFEFEF"><font size="2" face="Verdana, Arial, Helvetica, sans-serif">&nbsp; 
      <? if(file_exists('trackback.php')){eco('yes','green');} else {eco('no','red');} ?>
      </font></td>
  </tr>
  <tr align="left" valign="top" bgcolor="#EFEFEF"> 
    <td height="20" align="right" bgcolor="#EFEFEF"><font color="#000066" size="2" face="Verdana, Arial, Helvetica, sans-serif">xmlrpcc.inc.php</font></td>
    <td height="20" align="left" valign="top" bgcolor="#EFEFEF"><font color="#000066" size="2" face="Verdana, Arial, Helvetica, sans-serif">&nbsp; 
      <? if(file_exists('xmlrpcc.inc.php')){eco('yes','green');} else {eco('no','red');} ?>
      </font></td>
  </tr>
  <tr align="left" valign="top" bgcolor="#EFEFEF"> 
    <td height="20" align="right" bgcolor="#EFEFEF"><font color="#000066" size="2" face="Verdana, Arial, Helvetica, sans-serif">xmlrpcs.inc.php</font></td>
    <td height="20" align="left" valign="top" bgcolor="#EFEFEF"><font color="#000066" size="2" face="Verdana, Arial, Helvetica, sans-serif">&nbsp; 
      <? if(file_exists('xmlrpcs.inc.php')){eco('yes','green');} else {eco('no','red');} ?>
      </font></td>
  </tr>
  <tr align="left" valign="top" bgcolor="#EFEFEF"> 
    <td height="18" colspan="2" align="right" bgcolor="#EFEFEF"><font size="2" face="Verdana, Arial, Helvetica, sans-serif">&nbsp;</font><font size="2" face="Verdana, Arial, Helvetica, sans-serif">&nbsp;</font></td>
  </tr>
  <tr align="left" valign="top" bgcolor="#EFEFEF"> 
    <td height="20" align="right" bgcolor="#EFEFEF"><font color="#000066" size="2" face="Verdana, Arial, Helvetica, sans-serif">defined 
      smileys:</font></td>
    <td height="20" align="left" valign="top" bgcolor="#EFEFEF"><font color="#000066" size="2" face="Verdana, Arial, Helvetica, sans-serif"> 
      &nbsp; 
      <? @include('smileys.php'); eco(count($sface),'green'); ?>
      </font></td>
  </tr>
  <tr align="left" valign="top" bgcolor="#EFEFEF"> 
    <td height="20" align="right" bgcolor="#EFEFEF"><font color="#000066" size="2" face="Verdana, Arial, Helvetica, sans-serif">available 
      reader templates: </font></td>
    <td height="20" align="left" valign="top" bgcolor="#EFEFEF"><font color="#000066" size="2" face="Verdana, Arial, Helvetica, sans-serif">&nbsp; 
      <?	$readertemp=0;
			$handle = opendir(ZPATH."templates/readnews"); 
			while($dirfile = readdir($handle))
			{ 
				if( is_dir(ZPATH.'templates/readnews/'.$dirfile) && $dirfile!='.' && $dirfile!='..' && file_exists(ZPATH.'templates/readnews/'.$dirfile.'/header.html') && file_exists(ZPATH.'templates/readnews/'.$dirfile.'/news.html') && file_exists(ZPATH.'templates/readnews/'.$dirfile.'/footer.html') )
				{ $readertemp++; }
			} 
			closedir($handle); 
			eco($readertemp,'green');
	?>
      </font></td>
  </tr>
  <tr align="left" valign="top" bgcolor="#EFEFEF"> 
    <td height="20" align="right" bgcolor="#EFEFEF"><font color="#000066" size="2" face="Verdana, Arial, Helvetica, sans-serif">available 
      email templates: </font></td>
    <td height="20" align="left" valign="top" bgcolor="#EFEFEF"><font color="#000066" size="2" face="Verdana, Arial, Helvetica, sans-serif">&nbsp; 
      <?		$emailtemp=0;
			$handle = opendir(ZPATH."templates/sendtofriend"); 
			while($dirfile = readdir($handle))
			{ 
				if( is_dir(ZPATH.'templates/sendtofriend/'.$dirfile) && $dirfile!='.' && $dirfile!='..' && file_exists(ZPATH.'templates/sendtofriend/'.$dirfile.'/email.html') )
				{ $emailtemp++; }
			} 
			closedir($handle); 
			eco($emailtemp,'green');
	?>
      </font></td>
  </tr>
  <tr align="left" valign="top" bgcolor="#EFEFEF"> 
    <td height="20" align="right" bgcolor="#EFEFEF"><font color="#000066" size="2" face="Verdana, Arial, Helvetica, sans-serif">configuration 
      modified on:</font></td>
    <td height="20" align="left" valign="top" bgcolor="#EFEFEF"><font color="#000066" size="2" face="Verdana, Arial, Helvetica, sans-serif">&nbsp; 
      <? eco(date(DATEFORMAT,filemtime(ZPATH.'config.php')),'green');?>
      </font></td>
  </tr>
  <tr align="left" valign="top" bgcolor="#EFEFEF"> 
    <td height="20" align="right" bgcolor="#EFEFEF"><font color="#000066" size="2" face="Verdana, Arial, Helvetica, sans-serif">config.php 
      is writable:</font></td>
    <td height="20" align="left" valign="top" bgcolor="#EFEFEF"><font size="2" face="Verdana, Arial, Helvetica, sans-serif">&nbsp; 
      </font><font color="#000066" size="2" face="Verdana, Arial, Helvetica, sans-serif"> 
      <? if(is_writable(ZPATH.'config.php')) {eco('yes','red');} else {eco('no','green');} ;?>
      </font><font size="2" face="Verdana, Arial, Helvetica, sans-serif">&nbsp; 
      </font></td>
  </tr>
  <tr align="left" valign="top" bgcolor="#E1E3E8"> 
    <td height="18" colspan="2" bgcolor="#E1E3E8"><font size="2" face="Verdana, Arial, Helvetica, sans-serif"> 
      &nbsp;</font></td>
  </tr>
</table>
