<? 

// zShaped 1.2 - copyright (c) 2003 Andrei Besleaga
// http://zvonnews.sourceforge.net

// This program is free software; you can redistribute it and/or
// modify it under the terms of the GNU General Public License
// as published by the Free Software Foundation; either version 2
// of the License, or (at your option) any later version.

// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with this program; if not, write to the Free Software
// Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.

if($_SESSION['loggedin']!='true') exit;

function pingTrackBack($host, $title, $excerpt, $url, $blog_name)
{
	if(!defined(RSS_CHANNEL)||RSS_CHANNEL=='') $name = "a zShaped blog";
	$addr=parse_url($host);
	$connectto=$addr['host'];
	@$fp = fsockopen($connectto, 80, &$errnum, &$errstr);
	if(!$fp)
	{ 
	  echo "$errstr ($errnum)<br>\n";
	  $output = "ERROR!";
	} 
	else
	{
		$postcontent="title=".urlencode($title)."&url=".urlencode($url)."&excerpt=".urlencode($excerpt)."&blog_name=".urlencode($blog_name)."\n";
		$contlength=strlen($postcontent);
		$postdata="POST $host HTTP/1.0\n";
		$postdata.="Content-Type: application/x-www-form-urlencoded\n";
		$postdata.="Content-Length: $contlength\n\n";
		$postdata.=$postcontent;
		fputs($fp,$postdata);
		$output="";
		while(!feof($fp)) $output.=fgets($fp,4096);
		fclose($fp);		 
	}
	return $output;
}
	
	if($_POST['dodelete']=='delete selected')
	{
		$xnews=file(ZPATH.NEWSFILE);		
		$ubound=count($xnews);
		$fp=fopen(ZPATH.NEWSFILE,"w");
		fwrite($fp,"<? exit(0); //DO NOT TOUCH THIS LINE?>\n");
		for($i=1;$i<$ubound;$i++)
		{
			$chk='check'.$i;
			if($_POST[$chk]!=$i) {fwrite($fp,trim($xnews[$i])."\n");}  
		}
		fclose($fp);
	}	

	if($_POST['do']=='modifynews' && $_POST['leaveit']!='Leave it')
	{
		$xnews=file(ZPATH.NEWSFILE);		
		$ubound=count($xnews);
		$fp=fopen(ZPATH.NEWSFILE,"w");
		fwrite($fp,"<? exit(0); //DO NOT TOUCH THIS LINE?>\n");
		for($i=1;$i<$ubound;$i++)
		{
			if($_GET['link']==$i) 
				{
					$title=$_POST['title'];
					$news=$_POST['news'];
					$date=$_POST['date'];
					$formatted=str_replace("\r\n","<br />",$news);
					$formatted=str_replace("\n","<br />",$formatted);
					$newsto=$date."%~#".$title."%~#".$formatted;
					if($_POST['trackbackurl']!='')
					{	
						$toping=split(",",$_POST['trackbackurl']);
						foreach($toping as $somei=>$pingurl)
							{ if($pingurl!='') echo "<br />response from the trackback URL: ".pingTrackBack($pingurl,$title,$news,READER_PAGE."?znshowitem=".md5($date.$title),RSS_CHANNEL)."<br />"; }
					}
					$rasp=fwrite($fp,StripSlashes($newsto)."\n");
					if($rasp) {	echo "<b><center><font color=\"red\"> News modified successfully... </font></center></b>"; }
					else
					{	echo "<b><center><font color=\"red\"> Error modifying news... check if ".ZPATH.NEWSFILE. " exists and it has write permisions</font></center></b>"; }
				}
			else { fwrite($fp,trim($xnews[$i])."\n"); }
		}
		fclose($fp);
	}	

	$xnews=file(ZPATH.NEWSFILE);
	$ubound=count($xnews);
	$link=$_GET['link'];
	echo "<table width=\"700\" border=\"0\" align=\"center\"><font size=\"2\" face=\"Verdana, Arial, Helvetica, sans-serif\">";
	echo "<tr><td colspan=\"3\" bgcolor=\"#F0F0F0\">";
	if( $link!=0 && $link<$ubound && ($_POST['do']!='modifynews' && $_POST['leaveit']!='Leave it') ) 
		{	$crttmp=$xnews[$link];
			$crt=explode("%~#",$crttmp); ?>

			<script language="JavaScript">
			function smiley(text) {
				if (document.form1.news.createTextRange && document.form1.news.caretPos) {
					var caretPos = document.form1.news.caretPos;
					caretPos.text = caretPos.text.charAt(caretPos.text.length - 1) == ' ' ?
					text + ' ' : text;
				}
				else document.form1.news.value += text;
				document.form1.news.focus(caretPos)
			}
			</script>
			  <table width="600" align="center">
			  <tr>
			<td height="443"> 
			<form name="form1" method="POST" action="<? echo $_SERVER['PHP_SELF'].'?znaction=editnews&link='.$_GET['link']; ?>">
			<p align="center"><font size="2" face="Verdana, Arial, Helvetica, sans-serif"><br>
			  Date : 
			  <input type="text" name="date" style="border-style:groove;" value="<? echo $crt[0];?>" size="40"></input>
			  </font></p>
			  <p align="center"><font size="2" face="Verdana, Arial, Helvetica, sans-serif">Title : 
				<input name="title" type="text" style="border-style:groove;" value="<? echo $crt[1]; ?>" size="40"></input>
				<br>
				<?php
				include("smileys.php");
				foreach($sface as $sfname=>$sffile)
				{ 
					echo "<a href=\"Javascript:smiley(' ".$sfname." ');\"><img src=\"smilies/$sffile\" border=\"0\"></a> ";
				} ?>
				  <br>
				  <br>
				  <a href="Javascript:smiley('<b>text</b>');"><img src="<? echo ZURL;?>images/editor/bold.gif" width="23" height="22" border="0" alt="bold"></a>
				  <a href="Javascript:smiley('<i>text</i>');"><img src="<? echo ZURL;?>images/editor/italic.gif" width="23" height="22" border="0" alt="italic"></a>
				  <a href="Javascript:smiley('<u>text</u>');"><img src="<? echo ZURL;?>images/editor/underline.gif" width="23" height="22" border="0" alt="underline"></a>
				  <a href="Javascript:smiley('<s>text</s>');"><img src="<? echo ZURL;?>images/editor/strike.gif" width="23" height="22" border="0" alt="strike"></a>
				  <a href="Javascript:smiley('<font face=&quot;verdana&quot;>text</font>');"><img src="<? echo ZURL;?>images/editor/fontface.gif" width="23" height="22" border="0" alt="fontface"></a>
				  <a href="Javascript:smiley('<font size=&quot;2&quot;>text</font>');"><img src="<? echo ZURL;?>images/editor/fontsize.gif" width="23" height="22" border="0" alt="fontsize"></a>
				  <a href="Javascript:smiley('<font color=&quot;blue&quot;>text</font>');"><img src="<? echo ZURL;?>images/editor/color.gif" width="23" height="22" border="0" alt="fontcolor"></a>
				  <a href="Javascript:smiley('<font style=&quot;Filter: Glow(color=green, Strength=2); Width=1px;&quot;>TEXT</font>');"><img src="<? echo ZURL;?>images/editor/glow.gif" width="23" height="22" border="0" alt="glow"></a>
				  <a href="Javascript:smiley('<font style=&quot;Filter: Shadow(color=blue, Direction=left); Width=1px;&quot;>TEXT</font>');"><img src="<? echo ZURL;?>images/editor/shadow.gif" width="23" height="22" border="0" alt="shadow"></a>
				  <a href="Javascript:smiley('<sub>text</sub>');"><img src="<? echo ZURL;?>images/editor/sub.gif" width="23" height="22" border="0" alt="subscript"></a>
				  <a href="Javascript:smiley('<sup>text</sup>');"><img src="<? echo ZURL;?>images/editor/sup.gif" width="23" height="22" border="0" alt="superscript"></a>
				  <a href="Javascript:smiley('<p align=&quot;left&quot;>text</p>');"><img src="<? echo ZURL;?>images/editor/fontleft.gif" width="23" height="22" border="0" alt="align"></a>
				  <a href="Javascript:smiley('<marquee>scrolling text</marquee>');"><img src="<? echo ZURL;?>images/editor/move.gif" width="23" height="22" border="0" alt="scroll"></a>
				  <a href="Javascript:smiley('<hr>');"><img src="<? echo ZURL;?>images/editor/hr.gif" width="23" height="22" border="0" alt="hr"></a>
				  <a href="Javascript:smiley('<ul><li>item1<li>item2<li>item3</ul>');"><img src="<? echo ZURL;?>images/editor/list.gif" width="23" height="22" border="0" alt="list"></a>
				  <a href="Javascript:smiley('<blockquote><span class=&quot;12px&quot;>quote:</span><hr>_quotted_text_<hr></blockquote>');"><img src="<? echo ZURL;?>images/editor/quote.gif" width="23" height="22" border="0" alt="quote"></a>
				  <a href="Javascript:smiley('<img src=&quot;URL&quot;>');"><img src="<? echo ZURL;?>images/editor/img.gif" width="23" height="22" border="0" alt="image"></a>
				  <a href="Javascript:smiley('<a href=&quot;mailto:username@site.com&quot;>mail me</a>');"><img src="<? echo ZURL;?>images/editor/email.gif" width="23" height="22" border="0" alt="mailto"></a>
				  <a href="Javascript:smiley('<a href=&quot;http://www.url.com&quot;>address</a>');"><img src="<? echo ZURL;?>images/editor/url.gif" width="23" height="22" border="0" alt="url"></a> 
				</font>
				<font size="2" face="Verdana, Arial, Helvetica, sans-serif"> 
				<textarea name="news" rows="13" cols="60" style="border-style:groove;"><? echo $crt[2]; ?></textarea>
				<br>note: HTML code is permitted 
				  <br>
				  <br>
				  Notify (ping) TrackBack URL : 
				  <input name="trackbackurl" type="text" id="trackbackurl" size="30" style="border-style:groove" />
				  <br>
				  <br>
				  <br>
				</font></p>
			  <p align="center"><font size="2" face="Verdana, Arial, Helvetica, sans-serif"> 
				<input type="submit" name="modifynews" value="Modify News" style="border-style:groove"></input> &nbsp;
				<input type="submit" name="leaveit" value="Leave it" style="border-style:groove"></input> 
				</font></p>
			  <font size="2" face="Verdana, Arial, Helvetica, sans-serif">
			  <input type="hidden" name="do" value="modifynews">
			</form>
			</td></tr></table>

<?		}
	echo "</td></tr>";
	echo "<form name=\"frmDelete\" method=\"post\" action=\"".$_SERVER['PHP_SELF']."\" >";

	for($i=1;$i<$ubound;$i++)
	{ 	$crt=explode("%~#",$xnews[$i]);
		echo "<tr><td bgcolor=\"#D0ECFD\" width=\"60\"><input type=\"checkbox\" name=\"check$i\" value=\"$i\">$i</input></td>";
		echo "<td bgcolor=\"#D0ECFD\">[ ".htmlspecialchars($crt[0])." ]</td>";
		echo "<td bgcolor=\"#D0ECFD\"><a href=\"".$_SERVER['PHP_SELF']."?znaction=editnews&link=$i\">[ ".htmlspecialchars($crt[1])." ]</a></td></tr>";
	}
	?>
	<tr><td colspan="3" bgcolor="#F0F0F0">
	<? if($ubound>1) {echo "<input type=\"submit\" name=\"dodelete\" value=\"delete selected\" style=\"border-style:groove\"></input>";}
		else eco('No news currently in newsfile: '.ZPATH.NEWSFILE,'red');
	?>
	</td></tr></form></font></table>


