<? 

// zShaped 1.2 - copyright (c) 2003 Andrei Besleaga
// http://zvonnews.sourceforge.net

// This program is free software; you can redistribute it and/or
// modify it under the terms of the GNU General Public License
// as published by the Free Software Foundation; either version 2
// of the License, or (at your option) any later version.

// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with this program; if not, write to the Free Software
// Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.


if($_SESSION['loggedin']!='true') exit;
elseif(!is_writable(ZPATH.'config.php')) echo "<font size=\"2\" face=\"Verdana, Arial, Helvetica, sans-serif\"><br><center>config.php is not writable (you cannot save changes) !</center></font>";

if($_POST['dosave']=='Save settings')
{
	@$fp=fopen(ZPATH.'config.php','w');
	if($fp)
	{	
		if($_POST['newpassword']==$_POST['confirmpassword'] && $_POST['newpassword']!='') $adminpassword=md5($_POST['newpassword']); else $adminpassword=ADMINPASS;
		fwrite($fp,"<?php\n// zShaped ".ZNVER." - copyright (c) 2003 Andrei Besleaga\n");
		fwrite($fp,"// configuration file\n\n\n");
		fwrite($fp,"// general configuration options\n\n");
		fwrite($fp,"define(\"SITEURL\",\"".$_POST['siteurl']."\"); // the URL (address) of your website (http://www.yourdomain.com)\n");
		fwrite($fp,"define(\"ZURL\",\"".$_POST['zvonurl']."\");	// full URL to zShaped script\n");
		fwrite($fp,"define(\"ZPATH\",\"".$_POST['zvonpath']."\"); // path to zShaped script\n");
		fwrite($fp,"define(\"READER_PAGE\",\"".$_POST['readerpage']."\"); // url to page where readnews.php is included\n");
		fwrite($fp,"define(\"NEWSFILE\",\"".$_POST['newsfile']."\"); // you can change this value if you rename your 'news.php' file\n");
		fwrite($fp,"define(\"ADMINUSER\",\"".$_POST['adminname']."\"); // admin username\n");
		fwrite($fp,"define(\"ADMINPASS\",\"".$adminpassword."\"); // crypted admin password\n");
		fwrite($fp,"define(\"LOGLOGIN\",\"".$_POST['logaccess']."\"); // if 'yes' then all admin logins are logged\n");
		fwrite($fp,"define(\"LOGFILE\",\"".$_POST['logfilename']."\"); // log file name\n");
		fwrite($fp,"define(\"BLOGAPI_ENABLED\",\"".$_POST['blogapi']."\"); // if 'yes' then blogger API is enabled and you can edit/add/delete news with a remote client\n\n\n");
		fwrite($fp,"// news reader options\n\n");
		fwrite($fp,"define(\"PERPAGE\",".$_POST['perpage'].");	// change to how many news you want displayed on a page - 0=none\n");
		fwrite($fp,"define(\"ZNTEMPLATE\",\"templates/readnews/".$_POST['template']."\"); // the template used for showing news (subdirectory of zShaped where template html files are located)\n");
		fwrite($fp,"define(\"DATEFORMAT\",\"".$_POST['dateformat']."\"); // date format (PHP date function compatible)\n");
		fwrite($fp,"define(\"SENDTOFRIEND\",\"".$_POST['sendtofriend']."\"); // if 'enabled' then send_to_friend news emailing system is enabled\n");
		fwrite($fp,"define(\"COPYRIGHT\",\"".$_POST['copyright']."\");	// if 'no' then only the news system name is displayed\n");
		fwrite($fp,"define(\"TRACKBACK_ENABLED\",\"".$_POST['trackback']."\"); // if 'yes' then trackbacking is enabled\n");
		fwrite($fp,"define(\"TRACKBACKSDIR\",\"".$_POST['trackbacksdir']."/\"); // directory where trackbacks are stored\n");
		fwrite($fp,"\n\n// news syndication options\n\n");
		fwrite($fp,"define(\"RSS_NR\",".$_POST['rssnr'].");	// how many latest news to syndicate; 0 - RSS syndication disabled\n");
		fwrite($fp,"define(\"RSS_XML_ENCODING\",\"".$_POST['xmlencoding']."\");	// the RSS XML charset\n");
		fwrite($fp,"define(\"RSS_CHANNEL\",\"".$_POST['rsschannel']."\"); // the RSS Channel (feed) name\n");
		fwrite($fp,"define(\"RSS_DESC\",\"".$_POST['rssdesc']."\"); // the RSS channel description\n");
		fwrite($fp,"define(\"RSS_LANG\",\"".$_POST['rsslang']."\"); // the RSS language\n");
		fwrite($fp,"define(\"RSS_WEBMASTER\",\"".$_POST['rsswebmaster']."\"); //the webmaster's email address\n");
		fwrite($fp,"define(\"RSS_EDITOR\",\"".$_POST['rsseditor']."\"); // the news managing editor email address\n");
		fwrite($fp,"define(\"RSS_COPYRIGHT\",\"".$_POST['rsscopyright']."\"); // copyright notice for news in the channel\n");
		fwrite($fp,"define(\"RSS_DOMAIN\",\"".$_POST['rssdomain']."\"); // category domain (ex.: Syndic8)\n");
		fwrite($fp,"define(\"RSS_CATEGORY\",\"".$_POST['rsscategory']."\"); // category id (ex.: 1756)\n");
		fwrite($fp,"define(\"RSS_TTL\",\"".$_POST['rssttl']."\"); // feed time to live (nr. of minutes for which aggregators can cache content)\n");
		fwrite($fp,"define(\"RSS_IMAGE_TITLE\",\"".$_POST['rssimagetitle']."\"); // channel logo title\n");
		fwrite($fp,"define(\"RSS_IMAGE_URL\",\"".$_POST['rssimageurl']."\"); // channel logo url\n");
		fwrite($fp,"define(\"RSS_IMAGE_LINK\",\"".$_POST['rssimagelink']."\"); // channel logo link\n");
		fwrite($fp,"define(\"RSS_IMAGE_DESC\",\"".$_POST['rssimagedesc']."\"); // channel logo description\n");
		fwrite($fp,"define(\"RSS_IMAGE_WIDTH\",\"".$_POST['rssimagewidth']."\"); // channel logo width\n");
		fwrite($fp,"define(\"RSS_IMAGE_HEIGHT\",\"".$_POST['rssimageheight']."\"); // channel logo height\n");
		fwrite($fp,"define(\"RSS_DISABLED_TITLE\",\"".$_POST['rssdisabledtitle']."\"); // when RSS is disabled then feed will generate this title\n");
		fwrite($fp,"define(\"RSS_DISABLED_DESC\",\"".$_POST['rssdisableddesc']."\"); // when RSS is disabled then feed will generate this description\n");
		fwrite($fp,"define(\"RSS_DESC_LENGTH\",".$_POST['rssdesclength']."); // RSS items description length (news content length) -1 no description, 0 full description\n");
		fwrite($fp,"define(\"RSS_ITEM_PUBDATE\",\"".$_POST['rssitempubdate']."\"); // if date format is RFC 822 compatible then if this is yes pubdate will be generated for each item\n\n");
		fwrite($fp,"\n\n//////END OF CONFIGURATION///////////////////////////////////////////////////\n\n");
		fwrite($fp,"define(\"ZNVER\",\"".ZNVER."\"); // current zShaped version - do not modify\n?>");
		fclose($fp);
		echo "<font size=\"2\" face=\"Verdana, Arial, Helvetica, sans-serif\"><br><center>settings saved ...</center><br></font>";
	}
}
else
{
?>

<table width="700" border="0" align="center" cellpadding="0" cellspacing="3">
  <form name="configform" action="<? echo $_SERVER['PHP_SELF'].'?znaction=config';?>" method="post">
    <tr valign="top"> 
      <td colspan="2" align="center"><font color="#CC3300" size="2" face="Verdana, Arial, Helvetica, sans-serif"><br>
        notes:</font><font color="#000066" size="2" face="Verdana, Arial, Helvetica, sans-serif"> 
        - take care when changing options (don't change what you don't know for 
        sure)<br>
        <strong><font color="#000000">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</font></strong>- 
        fields marked with * are required, anything else is optional and can be 
        empty</font></td>
    </tr>
    <tr valign="top"> 
      <td colspan="2" align="center">&nbsp;</td>
    </tr>
    <tr valign="top"> 
      <td colspan="2" align="center"><strong><font color="#000000" size="2" face="Verdana, Arial, Helvetica, sans-serif">General 
        configuration</font></strong></td>
    </tr>
    <tr valign="top"> 
      <td colspan="2" align="center"><font color="#000066" size="2" face="Verdana, Arial, Helvetica, sans-serif">&nbsp; 
        </font></td>
    </tr>
    <tr valign="top"> 
      <td align="right"><font color="#000066" size="2" face="Verdana, Arial, Helvetica, sans-serif">* 
        site url :</font></td>
      <td><font color="#000066" size="2" face="Verdana, Arial, Helvetica, sans-serif">&nbsp; 
        <input name="siteurl" type="text" id="siteurl" value="<? echo SITEURL;?>" size="60" style="border-style:groove;" ></input> 
        </font></td>
    </tr>
    <tr valign="top"> 
      <td align="right"><font color="#000066" size="2" face="Verdana, Arial, Helvetica, sans-serif">* 
        zShaped url :</font></td>
      <td><font color="#000066" size="2" face="Verdana, Arial, Helvetica, sans-serif">&nbsp; 
        <input name="zvonurl" type="text" id="zvonurl"  value="<? echo ZURL;?>" size="60" style="border-style:groove;" ></input> 
        </font></td>
    </tr>
    <tr valign="top"> 
      <td align="right"><font color="#000066" size="2" face="Verdana, Arial, Helvetica, sans-serif">* 
        zShaped path :</font></td>
      <td><font color="#000066" size="2" face="Verdana, Arial, Helvetica, sans-serif">&nbsp; 
        <input name="zvonpath" type="text" id="zvonpath" value="<? echo ZPATH;?>" size="60" style="border-style:groove;"></input> 
        </font></td>
    </tr>
    <tr valign="top"> 
      <td height="22" align="right"><font color="#000066" size="2" face="Verdana, Arial, Helvetica, sans-serif">* 
        url to page where <font size="1">readnews.php</font> is included :</font></td>
      <td><font color="#000066" size="2" face="Verdana, Arial, Helvetica, sans-serif">&nbsp; 
        <input name="readerpage" type="text" id="readerpage" value="<? echo READER_PAGE;?>" size="60" style="border-style:groove;"></input> 
        </font></td>
    </tr>
    <tr valign="top"> 
      <td height="22" align="right"><font color="#000066" size="2" face="Verdana, Arial, Helvetica, sans-serif">* 
        news file name :</font></td>
      <td valign="top"><font color="#000066" size="2" face="Verdana, Arial, Helvetica, sans-serif">&nbsp; 
        <input type="text" name="newsfile" id="newsfile" value="<? echo NEWSFILE;?>" style="border-style:groove;"></input> 
        <font size="1">(change only if you rename news file)</font></font></td>
    </tr>
    <tr valign="top"> 
      <td align="right"><font color="#000066" size="2" face="Verdana, Arial, Helvetica, sans-serif">* 
        admin username :</font></td>
      <td><font color="#000066" size="2" face="Verdana, Arial, Helvetica, sans-serif">&nbsp; 
        <input name="adminname" type="text" id="adminname" style="border-style:groove;"  value="<? echo ADMINUSER;?>"></input> 
        </font></td>
    </tr>
    <tr valign="top"> 
      <td height="16" align="right"><font color="#000066" size="2" face="Verdana, Arial, Helvetica, sans-serif">* 
        log admin login :</font></td>
      <td><font color="#000066" size="2" face="Verdana, Arial, Helvetica, sans-serif">&nbsp; 
        <select name="logaccess" id="logaccess" style="border-style:groove;">
          <option value="yes" <? if(LOGLOGIN!='yes') echo 'selected';?>>yes</option>
          <option value="no" <? if(LOGLOGIN!='yes') echo 'selected';?>>no</option>
        </select>
        </font></td>
    </tr>
    <tr valign="top"> 
      <td align="right"><font color="#000066" size="2" face="Verdana, Arial, Helvetica, sans-serif">* 
        log file name :</font></td>
      <td><font color="#000066" size="2" face="Verdana, Arial, Helvetica, sans-serif">&nbsp; 
        <input type="text" name="logfilename" id="logfilename" value="<? echo LOGFILE;?>" style="border-style:groove;"></input> 
        <font size="1">(change only if you rename log file)</font></font></td>
    </tr>
    <tr valign="top"> 
      <td align="right"><font color="#000066" size="2" face="Verdana, Arial, Helvetica, sans-serif">* 
        enable offline editing and posting :</font></td>
      <td><font color="#000066" size="2" face="Verdana, Arial, Helvetica, sans-serif">&nbsp; 
        <select name="blogapi" id="blogapi" style="border-style:groove;">
          <option value="yes" <? if(BLOGAPI_ENABLED=='yes') echo 'selected';?> >yes</option>
          <option value="no" <? if(BLOGAPI_ENABLED!='yes') echo 'selected';?>>no</option>
        </select>
        <font size="1">(if yes then blogger API is enabled)</font></font></td>
    </tr>
    <tr valign="top"> 
      <td align="right"><font color="#000066" size="2" face="Verdana, Arial, Helvetica, sans-serif">admin 
        new password :</font></td>
      <td><font color="#000066" size="2" face="Verdana, Arial, Helvetica, sans-serif">&nbsp; 
        <input type="password" name="newpassword" id="newpassword" style="border-style:groove;">
        </input> 
        </font></td>
    </tr>
    <tr valign="top"> 
      <td align="right"><font color="#000066" size="2" face="Verdana, Arial, Helvetica, sans-serif"> 
        admin new password confirm :</font></td>
      <td><font color="#000066" size="2" face="Verdana, Arial, Helvetica, sans-serif">&nbsp; 
        <input type="password" name="confirmpassword" id="confirmpassword" style="border-style:groove;">
        </input> 
        </font></td>
    </tr>
    <tr valign="top"> 
      <td colspan="2" align="right"><font color="#000066" size="2" face="Verdana, Arial, Helvetica, sans-serif">&nbsp;</font><font color="#000066" size="2" face="Verdana, Arial, Helvetica, sans-serif">&nbsp;</font></td>
    </tr>
    <tr valign="top"> 
      <td colspan="2" align="center"><strong><font color="#000000" size="2" face="Verdana, Arial, Helvetica, sans-serif">News 
        reader options</font></strong></td>
    </tr>
    <tr valign="top"> 
      <td align="right"><font color="#000066" size="2" face="Verdana, Arial, Helvetica, sans-serif">&nbsp;</font></td>
      <td><font color="#000066" size="2" face="Verdana, Arial, Helvetica, sans-serif">&nbsp;</font></td>
    </tr>
    <tr valign="top"> 
      <td align="right"><font color="#000066" size="2" face="Verdana, Arial, Helvetica, sans-serif">* 
        how many news to display on a page :</font></td>
      <td><font color="#000066" size="2" face="Verdana, Arial, Helvetica, sans-serif">&nbsp; 
        <input name="perpage" type="text" id="perpage" value="<? echo PERPAGE;?>" style="border-style:groove;"></input> 
        </font></td>
    </tr>
    <tr valign="top"> 
      <td align="right"><font color="#000066" size="2" face="Verdana, Arial, Helvetica, sans-serif">* 
        template used to display news :</font></td>
      <td><font color="#000066" size="2" face="Verdana, Arial, Helvetica, sans-serif">&nbsp; 
        <select name="template" id="template" style="border-style:groove;">
          <?		
				$handle = opendir(ZPATH."templates/readnews"); 
				while($dirfile = readdir($handle))
				{ 
					if( is_dir(ZPATH.'templates/readnews/'.$dirfile) && $dirfile!='.' && $dirfile!='..' && file_exists(ZPATH.'templates/readnews/'.$dirfile.'/header.html') && file_exists(ZPATH.'templates/readnews/'.$dirfile.'/news.html') && file_exists(ZPATH.'templates/readnews/'.$dirfile.'/footer.html') )
					{ 
						if(ZNTEMPLATE=='templates/readnews/'.$dirfile) echo "<option value=\"$dirfile\" selected>$dirfile</option>";
					  	else echo "<option value=\"$dirfile\">$dirfile</option>"; 
					}
				} 
				closedir($handle); 
		 ?>
        </select>
        </font></td>
    </tr>
    <tr valign="top"> 
      <td align="right"><font color="#000066" size="2" face="Verdana, Arial, Helvetica, sans-serif">* 
        date format <font color="#006699">(PHP date format)</font> :</font></td>
      <td><font color="#000066" size="2" face="Verdana, Arial, Helvetica, sans-serif">&nbsp; 
        <input name="dateformat" type="text" id="dateformat" value="<? echo DATEFORMAT;?>" style="border-style:groove;"></input> 
        <a href="http://www.php.net/manual/en/function.date.php" onClick="window.open('http://www.php.net/manual/en/function.date.php'); return false;">?</a> 
        </font></td>
    </tr>
    <tr valign="top"> 
      <td align="right"><font color="#000066" size="2" face="Verdana, Arial, Helvetica, sans-serif">* 
        should author copyright be also visible :</font></td>
      <td><font color="#000066" size="2" face="Verdana, Arial, Helvetica, sans-serif">&nbsp; 
        <select name="copyright" id="copyright" style="border-style:groove;">
          <option value="yes" <? if(COPYRIGHT=='yes') echo 'selected';?> >yes</option>
          <option value="no" <? if(COPYRIGHT!='yes') echo 'selected';?>>no</option>
        </select>
        </font></td>
    </tr>
    <tr valign="top"> 
      <td align="right"><font color="#000066" size="2" face="Verdana, Arial, Helvetica, sans-serif"> 
        * (email news) send to friend enabled :</font></td>
      <td><font color="#000066" size="2" face="Verdana, Arial, Helvetica, sans-serif">&nbsp; 
        <select name="sendtofriend" id="sendtofriend" style="border-style:groove;">
          <option value="enabled" <? if(SENDTOFRIEND=='enabled') echo 'selected';?>>enabled</option>
          <option value="disabled" <? if(SENDTOFRIEND!='enabled') echo 'selected';?>>disabled</option>
        </select>
        </font></td>
    </tr>
    <tr valign="top"> 
      <td align="right"><font color="#000066" size="2" face="Verdana, Arial, Helvetica, sans-serif">* 
        enable trackback :</font></td>
      <td><font color="#000066" size="2" face="Verdana, Arial, Helvetica, sans-serif">&nbsp; 
        <select name="trackback" id="trackback" style="border-style:groove;">
          <option value="yes" <? if(TRACKBACK_ENABLED=='yes') echo 'selected';?> >yes</option>
          <option value="no" <? if(TRACKBACK_ENABLED!='yes') echo 'selected';?>>no</option>
        </select>
        </font></td>
    </tr>
    <tr valign="top"> 
      <td align="right"><font color="#000066" size="2" face="Verdana, Arial, Helvetica, sans-serif">* 
        trackbacks directory :</font></td>
      <td><font color="#000066" size="2" face="Verdana, Arial, Helvetica, sans-serif">&nbsp; 
        <input name="trackbacksdir" type="text" id="trackbacksdir" value="<? if(!defined(TRACKBACKSDIR)|| TRACKBACKSDIR=='') echo "trackbacks"; else echo substr(TRACKBACKSDIR,0,-1);?>" style="border-style:groove;">
        </font></td>
    </tr>
    <tr valign="top"> 
      <td height="18" align="right"><font color="#000066" size="2" face="Verdana, Arial, Helvetica, sans-serif">&nbsp;</font></td>
      <td><font color="#000066" size="2" face="Verdana, Arial, Helvetica, sans-serif">&nbsp;</font></td>
    </tr>
    <tr valign="top"> 
      <td colspan="2" align="center"><strong><font color="#000000" size="2" face="Verdana, Arial, Helvetica, sans-serif">RSS 
        syndication options (<a href="http://backend.userland.com/rss/" onClick="window.open('http://backend.userland.com/rss/'); return false;">RSS 
        specs</a>)</font></strong></td>
    </tr>
    <tr valign="top"> 
      <td align="right"><font color="#000066" size="2" face="Verdana, Arial, Helvetica, sans-serif">&nbsp;</font></td>
      <td><font color="#000066" size="2" face="Verdana, Arial, Helvetica, sans-serif">&nbsp;</font></td>
    </tr>
    <tr valign="top"> 
      <td align="right"><font color="#000066" size="2" face="Verdana, Arial, Helvetica, sans-serif">* 
        how many latest news to syndicate :<br>
        <font color="#006699">(0 - disabled)</font> </font></td>
      <td><font color="#000066" size="2" face="Verdana, Arial, Helvetica, sans-serif">&nbsp; 
        <input name="rssnr" type="text" id="rssnr" value="<? echo RSS_NR;?>" style="border-style:groove;"></input> 
        </font></td>
    </tr>
    <tr valign="top"> 
      <td align="right"><font color="#000066" size="2" face="Verdana, Arial, Helvetica, sans-serif">XML 
        encoding charset :</font></td>
      <td><font color="#000066" size="2" face="Verdana, Arial, Helvetica, sans-serif">&nbsp; 
        <input name="xmlencoding" type="text" id="xmlencoding" value="<? echo RSS_XML_ENCODING;?>" size="60" style="border-style:groove;"></input> 
        <a href="http://www.iana.org/assignments/character-sets" onClick="window.open('http://www.iana.org/assignments/character-sets'); return false;">?</a> 
        </font></td>
    </tr>
    <tr valign="top"> 
      <td align="right"><font color="#000066" size="2" face="Verdana, Arial, Helvetica, sans-serif"> 
        * channel (weblog) name :</font></td>
      <td><font color="#000066" size="2" face="Verdana, Arial, Helvetica, sans-serif">&nbsp; 
        <input name="rsschannel" type="text" id="rsschannel" value="<? echo RSS_CHANNEL;?>" size="60" style="border-style:groove;"></input> 
        </font></td>
    </tr>
    <tr valign="top"> 
      <td align="right"><font color="#000066" size="2" face="Verdana, Arial, Helvetica, sans-serif">* 
        channel description :</font></td>
      <td><font color="#000066" size="2" face="Verdana, Arial, Helvetica, sans-serif">&nbsp; 
        <input name="rssdesc" type="text" id="rssdesc" value="<? echo RSS_DESC;?>" size="60" style="border-style:groove;"></input> 
        </font></td>
    </tr>
    <tr valign="top"> 
      <td align="right"><font color="#000066" size="2" face="Verdana, Arial, Helvetica, sans-serif">channel 
        language :</font></td>
      <td><font color="#000066" size="2" face="Verdana, Arial, Helvetica, sans-serif">&nbsp; 
        <input name="rsslang" type="text" id="rsslang" value="<? echo RSS_LANG;?>" style="border-style:groove;"></input style="border-style:groove;"></input> 
        <a href="http://backend.userland.com/stories/storyReader$16" onClick="window.open('http://backend.userland.com/stories/storyReader$16'); return false;">?</a> 
        </font></td>
    </tr>
    <tr valign="top"> 
      <td align="right"><font color="#000066" size="2" face="Verdana, Arial, Helvetica, sans-serif">webmaster 
        email address :</font></td>
      <td><font color="#000066" size="2" face="Verdana, Arial, Helvetica, sans-serif">&nbsp; 
        <input name="rsswebmaster" type="text" id="rsswebmaster" value="<? echo RSS_WEBMASTER;?>" style="border-style:groove;"></input> 
        </font></td>
    </tr>
    <tr valign="top"> 
      <td align="right"><font color="#000066" size="2" face="Verdana, Arial, Helvetica, sans-serif">managing 
        editor email address :</font></td>
      <td><font color="#000066" size="2" face="Verdana, Arial, Helvetica, sans-serif">&nbsp; 
        <input name="rsseditor" type="text" id="rsseditor" value="<? echo RSS_EDITOR;?>" style="border-style:groove;"></input> 
        </font></td>
    </tr>
    <tr valign="top"> 
      <td align="right"><font color="#000066" size="2" face="Verdana, Arial, Helvetica, sans-serif">copyright 
        notice for content in channel :</font></td>
      <td><font color="#000066" size="2" face="Verdana, Arial, Helvetica, sans-serif">&nbsp; 
        <input name="rsscopyright" type="text" id="rsscopyright" value="<? echo RSS_COPYRIGHT;?>" size="60" style="border-style:groove;"></input> 
        </font></td>
    </tr>
    <tr valign="top"> 
      <td align="right"><font color="#000066" size="2" face="Verdana, Arial, Helvetica, sans-serif">category 
        domain :</font></td>
      <td><font color="#000066" size="2" face="Verdana, Arial, Helvetica, sans-serif">&nbsp; 
        <input name="rssdomain" type="text" id="rssdomain" value="<? echo RSS_DOMAIN;?>" style="border-style:groove;"></input> 
        </font></td>
    </tr>
    <tr valign="top"> 
      <td align="right"><font color="#000066" size="2" face="Verdana, Arial, Helvetica, sans-serif">category 
        id :</font></td>
      <td><font color="#000066" size="2" face="Verdana, Arial, Helvetica, sans-serif">&nbsp; 
        <input name="rsscategory" type="text" id="rsscategory" value="<? echo RSS_CATEGORY;?>" style="border-style:groove;"></input> 
        </font></td>
    </tr>
    <tr valign="top"> 
      <td align="right"><font color="#000066" size="2" face="Verdana, Arial, Helvetica, sans-serif">time 
        to live :<br>
        <font color="#006699">(minutes aggregators can cache the feed)</font> 
        </font></td>
      <td><font color="#000066" size="2" face="Verdana, Arial, Helvetica, sans-serif">&nbsp; 
        <input name="rssttl" type="text" id="rssttl" value="<? echo RSS_TTL;?>" style="border-style:groove;"></input> 
        </font></td>
    </tr>
    <tr valign="top"> 
      <td align="right"><font color="#000066" size="2" face="Verdana, Arial, Helvetica, sans-serif">channel 
        image title :</font></td>
      <td><font color="#000066" size="2" face="Verdana, Arial, Helvetica, sans-serif">&nbsp; 
        <input name="rssimagetitle" type="text" id="rssimagetitle" value="<? echo RSS_IMAGE_TITLE;?>" size="60" style="border-style:groove;"></input> 
        </font></td>
    </tr>
    <tr valign="top"> 
      <td align="right"><font color="#000066" size="2" face="Verdana, Arial, Helvetica, sans-serif">channel 
        image url :</font></td>
      <td><font color="#000066" size="2" face="Verdana, Arial, Helvetica, sans-serif">&nbsp; 
        <input name="rssimageurl" type="text" id="rssimageurl" value="<? echo RSS_IMAGE_URL;?>" size="60" style="border-style:groove;"></input> 
        </font></td>
    </tr>
    <tr valign="top"> 
      <td align="right"><font color="#000066" size="2" face="Verdana, Arial, Helvetica, sans-serif">channel 
        image link :</font></td>
      <td><font color="#000066" size="2" face="Verdana, Arial, Helvetica, sans-serif">&nbsp; 
        <input name="rssimagelink" type="text" id="rssimagelink" value="<? echo RSS_IMAGE_LINK;?>" size="60" style="border-style:groove;"></input> 
        </font></td>
    </tr>
    <tr valign="top"> 
      <td align="right"><font color="#000066" size="2" face="Verdana, Arial, Helvetica, sans-serif">channel 
        image description :</font></td>
      <td><font color="#000066" size="2" face="Verdana, Arial, Helvetica, sans-serif">&nbsp; 
        <input name="rssimagedesc" type="text" id="rssimagedesc" value="<? echo RSS_IMAGE_DESC;?>" size="60" style="border-style:groove;"></input> 
        </font></td>
    </tr>
    <tr valign="top"> 
      <td align="right"><font color="#000066" size="2" face="Verdana, Arial, Helvetica, sans-serif">channel 
        image width :</font></td>
      <td><font color="#000066" size="2" face="Verdana, Arial, Helvetica, sans-serif">&nbsp; 
        <input name="rssimagewidth" type="text" id="rssimagewidth" value="<? echo RSS_IMAGE_WIDTH;?>" style="border-style:groove;"></input> 
        </font></td>
    </tr>
    <tr valign="top"> 
      <td align="right"><font color="#000066" size="2" face="Verdana, Arial, Helvetica, sans-serif">channel 
        image height :</font></td>
      <td><font color="#000066" size="2" face="Verdana, Arial, Helvetica, sans-serif">&nbsp; 
        <input name="rssimageheight" type="text" id="rssimageheight" value="<? echo RSS_IMAGE_HEIGHT;?>" style="border-style:groove;"></input> 
        </font></td>
    </tr>
    <tr valign="top"> 
      <td align="right"><font color="#000066" size="2" face="Verdana, Arial, Helvetica, sans-serif">if 
        RSS is disabled title :</font></td>
      <td><font color="#000066" size="2" face="Verdana, Arial, Helvetica, sans-serif">&nbsp; 
        <input name="rssdisabledtitle" type="text" id="rssdisabledtitle" value="<? echo RSS_DISABLED_TITLE;?>" size="60" style="border-style:groove;"></input> 
        </font></td>
    </tr>
    <tr valign="top"> 
      <td align="right"><font color="#000066" size="2" face="Verdana, Arial, Helvetica, sans-serif"> 
        if RSS is disabled content :</font></td>
      <td><font color="#000066" size="2" face="Verdana, Arial, Helvetica, sans-serif">&nbsp; 
        <input name="rssdisableddesc" type="text" id="rssdisableddesc" value="<? echo RSS_DISABLED_DESC;?>" size="60" style="border-style:groove;"></input> 
        </font></td>
    </tr>
    <tr valign="top"> 
      <td height="19" align="right"><font color="#000066" size="2" face="Verdana, Arial, Helvetica, sans-serif">items 
        description length (characters) :<br>
        <font color="#006699">(-1 no news content, 0 full news content)</font></font></td>
      <td><font color="#000066" size="2" face="Verdana, Arial, Helvetica, sans-serif">&nbsp; 
        <input name="rssdesclength" type="text" id="rssdesclength" value="<? echo RSS_DESC_LENGTH; ?>" style="border-style:groove;"></input> 
        </font></td>
    </tr>
    <tr valign="top"> 
      <td height="24" align="right"><font color="#000066" size="2" face="Verdana, Arial, Helvetica, sans-serif">items 
        publication date :</font></td>
      <td><font color="#000066" size="2" face="Verdana, Arial, Helvetica, sans-serif">&nbsp; 
        <select name="rssitempubdate" id="rssitempubdate">
          <option value="yes" <? if(RSS_ITEM_PUBDATE=='yes') echo 'selected';?>>yes</option>
          <option value="no" <? if(RSS_ITEM_PUBDATE!='yes') echo 'selected';?>>no</option>
        </select>
        <font color="#006699">(only if date format is &quot;r&quot; or RFC 822 
        compatible)</font> </font></td>
    </tr>
    <tr valign="top"> 
      <td align="right">&nbsp;</td>
      <td>&nbsp;</td>
    </tr>
    <tr valign="top"> 
      <td colspan="2" align="center"> <font size="2" face="Verdana, Arial, Helvetica, sans-serif"> 
        <input type="submit" name="dosave" id="dosave" value="Save settings" style="border-style:groove;"></input> 
        </font></td>
    </tr>
    <tr valign="top"> 
      <td align="right"><font color="#000066" size="2" face="Verdana, Arial, Helvetica, sans-serif">&nbsp;</font></td>
      <td><font color="#000066" size="2" face="Verdana, Arial, Helvetica, sans-serif">&nbsp;</font></td>
    </tr>
  </form>
</table>
<br>
<? } ?>