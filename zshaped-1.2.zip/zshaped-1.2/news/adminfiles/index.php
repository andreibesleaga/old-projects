<?
// zShaped 1.2 - copyright (c) 2003 Andrei Besleaga
// http://zvonnews.sourceforge.net
?>