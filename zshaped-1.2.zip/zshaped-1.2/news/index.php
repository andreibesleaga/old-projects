<?php

// zShaped 1.2 - copyright (c) 2003 Andrei Besleaga
// http://zvonnews.sourceforge.net

// This program is free software; you can redistribute it and/or
// modify it under the terms of the GNU General Public License
// as published by the Free Software Foundation; either version 2
// of the License, or (at your option) any later version.

// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with this program; if not, write to the Free Software
// Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.


define("ZNVER","1.2");

if(!file_exists('config.php') || filesize('config.php')<2000)
{?>

<html>
<head>
<title>z S h a p e d</title>
<head>
<style type="text/css">
a:link {color: blue}
a:visited {color: #5F5FB8}
a:hover {color: #EE7A06}
a:active {color: blue}
</style>
</head>
</head>
<body>
<table width="222" border="0" align="center">
  <tr align="left" valign="middle"> 
    <td width="15%" valign="middle"><strong><font color="#006699" size="2" face="Verdana, Arial, Helvetica, sans-serif"><img src="images/zslogo.gif" width="80" height="15"> 
      </font></strong></td>
    <td width="85%" align="center" valign="middle"><strong><font color="#006699" size="2" face="Verdana, Arial, Helvetica, sans-serif">W</font><font color="#006699" size="2" face="Verdana, Arial, Helvetica, sans-serif">elcome 
      to zShaped</font></strong></td>
  </tr>
</table>
<table width="435" border="0" align="center">
  <tr align="center" valign="middle" bgcolor="#D0ECFD"> 
    <td height="15" align="center" valign="middle">&nbsp; </td>
  </tr>
  <tr align="center" valign="middle" bgcolor="#F4F4F4"> 
    <td height="149" align="center" valign="middle"> <p><font color="#000066" size="2" face="Verdana, Arial, Helvetica, sans-serif"> 
        It seems that config.php is not ok.<br>
        This happens in the following situations:</font><font color="#000066" size="2" face="Verdana, Arial, Helvetica, sans-serif"> 
        </font></p>
      <font color="#000066" size="2" face="Verdana, Arial, Helvetica, sans-serif"> 
      <li> you haven't installed yet zShaped<br>
        <font color="#000099">(if so then you have to proceed with install) </font></li>
      <font color="#000099"><br>
      </font><br>
      <li>config.php has been </li>
      accidentally or intentionally corrupted<br>
      <font color="#000099">(if so then if you have a backup of config.php you 
      can simply put it back to make the system work again or you can reinstall)<br><br>
      </font></font></td>
  </tr>
  <tr align="center" valign="middle" bgcolor="#F4F4F4"> 
    <td height="61" align="center" valign="middle"><font size="2" face="Verdana, Arial, Helvetica, sans-serif"><a href="install.php?id=act1"><img src="images/install.gif" alt="start install" width="40" height="40" border="0"><br>
      proceed with install</a></font><font size="2" face="Verdana, Arial, Helvetica, sans-serif">&nbsp;</font></td>
  </tr>
  <tr align="center" valign="middle" bgcolor="#D0ECFD"> 
    <td height="15">&nbsp;</td>
  </tr>
  <tr align="center" valign="middle"> 
    <td height="15"><font size="2" face="Verdana, Arial, Helvetica, sans-serif"> 
      powered by <a href="http://zvonnews.sourceforge.net"> zShaped <? echo ZNVER;?></a> - &copy;2003 Andrei Besleaga</font></td>
  </tr>
</table>
</body>
</html>

<? } else { require("config.php"); ?>

<html>
<head>
<style type="text/css">
a:link {color: blue}
a:visited {color: #5F5FB8}
a:hover {color: #EE7A06}
a:active {color: blue}
</style>
<title>z S h a p e d</title>
</head>
<body>
<table width="222" border="0" align="center">
  <tr align="left" valign="middle"> 
    <td width="15%" valign="middle"><strong><font color="#006699" size="2" face="Verdana, Arial, Helvetica, sans-serif"><img src="images/zslogo.gif" /> 
      </font></strong></td>
    <td width="85%" align="center" valign="middle"><strong><font color="#006699" size="2" face="Verdana, Arial, Helvetica, sans-serif">W</font><font color="#006699" size="2" face="Verdana, Arial, Helvetica, sans-serif">elcome 
      to zShaped</font></strong></td>
  </tr>
</table>
  
<table width="435" border="0" align="center">
  <tr align="center" valign="middle" bgcolor="#D0ECFD"> 
    <td height="15" colspan="3" align="center" valign="middle">&nbsp; </td>
  </tr>
  <tr align="center" valign="middle" bgcolor="#F4F4F4"> 
    <td width="36%" height="70" align="center" valign="middle"><font size="2" face="Verdana, Arial, Helvetica, sans-serif"><a href="admin.php"><img src="images/admin.gif" alt="go to admin panel" width="40" height="40" border="0"><br>
      go to admin panel</a></font></td>
    <td width="36%" height="70" align="center" valign="middle"><font size="2" face="Verdana, Arial, Helvetica, sans-serif"><a href="<?php echo SITEURL;?>"><img src="images/www.gif" alt="go to website" width="40" height="40" border="0"><br>
      go to site</a></font></td>
    <td width="36%" height="70" align="center" valign="middle"><font size="2" face="Verdana, Arial, Helvetica, sans-serif"><a href="javascript:history.back();"><img src="images/back.gif" alt="go back" width="40" height="40" border="0"><br>
      go back</a></font></td>
  </tr>
  <tr align="center" valign="middle" bgcolor="#D0ECFD"> 
    <td height="15" colspan="3">&nbsp;</td>
  </tr>
  <tr align="center" valign="middle"> 
    <td height="15" colspan="3"><font size="2" face="Verdana, Arial, Helvetica, sans-serif"> 
      powered by <a href="http://zvonnews.sourceforge.net"> zShaped <? echo ZNVER;?></a> - &copy;2003 Andrei Besleaga</font></td>
  </tr>
</table>
</body>
</html>

<? } ?>