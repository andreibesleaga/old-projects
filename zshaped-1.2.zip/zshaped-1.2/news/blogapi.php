<?
// zShaped 1.2 - copyright (c) 2003 Andrei Besleaga
// http://zvonnews.sourceforge.net
//
// This program is free software; you can redistribute it and/or
// modify it under the terms of the GNU General Public License
// as published by the Free Software Foundation; either version 2
// of the License, or (at your option) any later version.
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with this program; if not, write to the Free Software
// Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.


require(dirname(__FILE__).'/config.php');

function getdetails()
{
	$dataval="Date: ".date("r")."<br>";
	$ip = getenv("REMOTE_ADDR");
	$host = getenv("REMOTE_HOST");
	$clientip = getenv("HTTP_CLIENT_IP"); 
	$fwdfor=getenv("HTTP_X_FORWARDED_FOR");
	$ident=getenv("REMOTE_IDENT");
	$useragent=getenv("HTTP_USER_AGENT");
	$reffer=$_SERVER['HTTP_REFERRER'];
	$query=$_SERVER['QUERY_STRING'];
	$requesturi=$_SERVER['REQUEST_URI'];
	$httpvia=getenv("HTTP_VIA");
	if ($ip) { $dataval.="IP: $ip <br>";}
	if ($host) { $dataval.="Host: $host <br>";}
	if ($clientip) { $dataval.= "client IP: $clientip <br>";}
	if ($fwdfor) { $dataval.= "Forwarded for: $fwdfor <br>";}
	if ($httpvia) { $dataval.="HTTP via: $httpvia <br>";}
	if ($reffer) { $dataval.="Refferer: $reffer <br>";}
	if ($query) { $dataval.="Query: $query <br>";}
	if ($ident) { $dataval.="IDENT: $ident <br>";}
	if ($requesturi) { $dataval.="Request URI: $requesturi <br>";}
	if ($useragent) { $dataval.="UserAgent: $useragent <br>";}
	return $dataval;
}

function logtofile($data)
{
	@$fp=fopen(ZPATH.LOGFILE,"a");
	@fwrite($fp,$data,strlen($data));
	@fclose($fp);
}

function authUser($userobject, $passobject)
{
	$adminuser=''; $adminpass='';
	$adminuser=$userobject->scalarval();
	$adminpass=md5($passobject->scalarval());
	if( $adminuser!=ADMINUSER || $adminpass!=ADMINPASS )
	{
		if(LOGLOGIN=='yes')
		{
			$somedata=getdetails();
			$somedata=str_replace("<br>"," || ",$somedata);
			logtofile($somedata."via Blogger API\n");
		}
		return false;
	}
	return true;
}

function _getUsersBlogs($param)
{	global $xmlrpcerruser;
	if( !authUser($param->getParam(1),$param->getParam(2)) ) return new xmlrpcresp(0, $xmlrpcerruser, "Authentication failed !");
	$v=new xmlrpcval();
	$outAr=array();
	$outAr[]=new xmlrpcval(array(
			"blogid" => new xmlrpcval("1"),
			"url" => new xmlrpcval(SITEURL),
			"blogname" => new xmlrpcval(RSS_CHANNEL)),
			"struct"
	);
	$v->addArray($outAr);
	return new xmlrpcresp($v);
}

function _newPost($param)
{	global $xmlrpcerruser;
	$content=$param->getParam(4); $content=chop($content->scalarval());
	if( !authUser($param->getParam(2),$param->getParam(3)) ) return new xmlrpcresp(0, $xmlrpcerruser, "Authentication failed !");
	preg_match("'<title>(.*?)</title>'si",$content,$title);
	$news=$title[1]."%~#".preg_replace ("'<title>(.*?)</title>'si", "", $content,1);
	$date=date(DATEFORMAT);
	$formatted=str_replace("\r\n","<br />",$news);
	$formatted=str_replace("\n","<br />",$formatted);
	@$fp=fopen(ZPATH.NEWSFILE,"a");
	if(!$fp) { return new xmlrpcresp(0, $xmlrpcerruser, "Could not open news file for writing !"); }
	$newsto=$date."%~#".$formatted;
	@$rasp=fwrite($fp,StripSlashes($newsto)."\n");
	if($rasp)
	{	@fclose($fp);
		return new xmlrpcresp(new xmlrpcval(md5($date.$title)));
	}
	else
	{	@fclose($fp); return new xmlrpcresp(0, $xmlrpcerruser, "Error adding news... check if ".ZPATH.NEWSFILE. " exists and it has write permisions"); }

}

function _editPost($param)
{	global $xmlrpcerruser;
	$postid=$param->getParam(1); $postid=$postid->scalarval();
	if( !authUser($param->getParam(2),$param->getParam(3)) ) return new xmlrpcresp(0, $xmlrpcerruser, "Authentication failed !");
	$content=$param->getParam(4); $content=chop($content->scalarval());
	@$xnews=file(ZPATH.NEWSFILE); 
	if(!$xnews) { return new xmlrpcresp(0, $xmlrpcerruser, "Could not open news file !"); }
	$ubound=count($xnews);
	if($ubound<2) { return new xmlrpcresp(0, $xmlrpcerruser, "No news posted yet !"); }
	if(!is_writable(ZPATH.NEWSFILE)) { return new xmlrpcresp(0, $xmlrpcerruser, "News file is not writeable !"); }
	@$fp=fopen(ZPATH.NEWSFILE,"w");
	@fwrite($fp,"<? exit(0); //DO NOT TOUCH THIS LINE?>\n");
	for($i=1;$i<$ubound;$i++)
	{
		$crtsplit="";
		$crtsplit=explode("%~#",$xnews[$i]);
		$tmpdate=$crtsplit[0];
		$tmptitle=$crtsplit[1];
		$tmpnews=$crtsplit[2];
		if(md5($tmpdate.$tmptitle)!=$postid) { @fwrite($fp,chop($xnews[$i])."\n"); }
		else
		{
				preg_match("'<title>(.*?)</title>'si",$content,$title);
				$news=$title[1]."%~#".preg_replace ("'<title>(.*?)</title>'si", "", $content,1);
				$date=date(DATEFORMAT);
				$formatted=str_replace("\r\n","<br />",$news);
				$formatted=str_replace("\n","<br />",$formatted);
				$newsto=$date."%~#".$formatted;
				@$rasp=fwrite($fp,StripSlashes($newsto)."\n");
				if($rasp) $updated="ok";
		}
	}
	@fclose($fp);
	if($updated=="ok") return new xmlrpcresp(new xmlrpcval(true,"boolean"));
	else return new xmlrpcresp(0, $xmlrpcerruser, "Could not update that post !");	
}

function _deletePost($param)
{	global $xmlrpcerruser;
	$postid=$param->getParam(1); $postid=$postid->scalarval();
	if( !authUser($param->getParam(2),$param->getParam(3)) ) return new xmlrpcresp(0, $xmlrpcerruser, "Authentication failed !");
	@$xnews=file(ZPATH.NEWSFILE); 
	if(!$xnews) { return new xmlrpcresp(0, $xmlrpcerruser, "Could not open news file !"); }
	$ubound=count($xnews);
	if($ubound<2) { return new xmlrpcresp(0, $xmlrpcerruser, "No news posted yet !"); }
	if(!is_writable(ZPATH.NEWSFILE)) { return new xmlrpcresp(0, $xmlrpcerruser, "News file is not writeable !"); }
	@$fp=fopen(ZPATH.NEWSFILE,"w");
	@fwrite($fp,"<? exit(0); //DO NOT TOUCH THIS LINE?>\n");
	for($i=1;$i<$ubound;$i++)
	{
		$crtsplit="";
		$crtsplit=explode("%~#",$xnews[$i]);
		$tmpdate=$crtsplit[0];
		$tmptitle=$crtsplit[1];
		$tmpnews=$crtsplit[2];
		if(md5($tmpdate.$tmptitle)!=$postid) @fwrite($fp,chop($xnews[$i])."\n");
	}
	@fclose($fp);
	return new xmlrpcresp(new xmlrpcval(true,"boolean"));
}

function _getRecentPosts($param)
{	global $xmlrpcerruser;
	$nrofposts=$param->getParam(4); $$nrofposts=$nrofposts->scalarval();
	if( !authUser($param->getParam(2),$param->getParam(3)) ) return new xmlrpcresp(0, $xmlrpcerruser, "Authentication failed !");
	$v=new xmlrpcval();
	$outAr=array();
	@$xnews=file(ZPATH.NEWSFILE); 
	if(!$xnews) { return new xmlrpcresp(0, $xmlrpcerruser, "Could not open news file !"); }
	$xnews=array_reverse($xnews);
	$ubound=count($xnews);
	if($ubound<2) { return new xmlrpcresp(0, $xmlrpcerruser, "No news posted yet !"); }
	for($i=0;$i<$ubound-1 && $i<$nrofposts;$i++)
	{
		$crtsplit="";
		$crtsplit=explode("%~#",$xnews[$i]);
		$tmpdate=$crtsplit[0];
		$tmptitle=$crtsplit[1];
		$tmpnews=$crtsplit[2];
		$outAr[]=new xmlrpcval(array(
				"dateCreated" => new xmlrpcval($tmpdate),
				"userid" => new xmlrpcval(ADMINUSER),
				"postid" => new xmlrpcval(md5($tmpdate.$tmptitle)),
				"content" => new xmlrpcval("<title>".$tmptitle."</title>".$tmpnews)),
				"struct"
		);
	}
	$v->addArray($outAr);
	return new xmlrpcresp($v);
}

function _getPost($param)
{	global $xmlrpcerruser;
	$postid=$param->getParam(1); $postid=$postid->scalarval();
	if( !authUser($param->getParam(2),$param->getParam(3)) ) return new xmlrpcresp(0, $xmlrpcerruser, "Authentication failed !");
	@$xnews=file(ZPATH.NEWSFILE); 
	if(!$xnews) { return new xmlrpcresp(0, $xmlrpcerruser, "Could not open news file !"); }
	$xnews=array_reverse($xnews);
	$ubound=count($xnews);
	if($ubound<2) { return new xmlrpcresp(0, $xmlrpcerruser, "No news posted yet !"); }
	for($i=0;$i<$ubound-1;$i++)
	{
		$crtsplit="";
		$crtsplit=explode("%~#",$xnews[$i]);
		$tmpdate=$crtsplit[0];
		$tmptitle=$crtsplit[1];
		$tmpnews=$crtsplit[2];
		if(md5($tmpdate.$tmptitle)==$postid)
		{
			return new xmlrpcresp(new xmlrpcval(array(
			"dateCreated" => new xmlrpcval($tmpdate), "userid" => new xmlrpcval(ADMINUSER), "postid" => new xmlrpcval($postid), "content" => new xmlrpcval("<title>".$tmptitle."</title>".$tmpnews)),
			"struct"));
			exit;
		}
	}
	return new xmlrpcresp(0, $xmlrpcerruser, "Could not find that post !");
}


if(BLOGAPI_ENABLED=="yes")
{	
	require(dirname(__FILE__).'/xmlrpcc.inc.php');
	require(dirname(__FILE__).'/xmlrpcs.inc.php');
	
	$getusersblogs_sig=array(array($xmlrpcArray, $xmlrpcString, $xmlrpcString, $xmlrpcString));
	$editpost_sig=array(array($xmlrpcBoolean, $xmlrpcString, $xmlrpcString, $xmlrpcString, $xmlrpcString, $xmlrpcString, $xmlrpcBoolean));
	$deletepost_sig=array(array($xmlrpcBoolean, $xmlrpcString, $xmlrpcString, $xmlrpcString, $xmlrpcString, $xmlrpcBoolean));
	$newpost_sig=array(array($xmlrpcString, $xmlrpcString, $xmlrpcString, $xmlrpcString, $xmlrpcString, $xmlrpcString, $xmlrpcBoolean));
	$getrecentposts_sig=array(array($xmlrpcArray, $xmlrpcString, $xmlrpcString, $xmlrpcString, $xmlrpcString, $xmlrpcInt));
	$getpost_sig=array(array($xmlrpcStruct, $xmlrpcString, $xmlrpcString, $xmlrpcString, $xmlrpcString));
	
	$s=new xmlrpc_server(array(
		"blogger.getUsersBlogs" => array("function" => "_getUsersBlogs", "signature" => $getusersblogs_sig),
		"blogger.getRecentPosts" => array("function" => "_getRecentPosts", "signature" => $getrecentposts_sig),
		"blogger.getPost" => array("function" => "_getPost", "signature" => $getpost_sig),
		"blogger.editPost" => array("function" => "_editPost", "signature" => $editpost_sig),
		"blogger.deletePost" => array("function" => "_deletePost", "signature" => $deletepost_sig),
		"blogger.newPost" => array("function" => "_newPost", "signature" => $newpost_sig),
	));
}
?>