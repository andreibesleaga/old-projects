<? exit(0); //DO NOT TOUCH THIS LINE?>
Tue, 10 Jun 2003 12:00:00 +0200%~#zvonNews started%~#Essentialy changing and adding new features.<br />As of today works begins on zvonNews<br />
Sat, 28 Jun 2003 12:00:00 +0200%~#zvonNews 1.0 finished%~#zvonNews 1.0 has been finished.<br />Launching will be soon.<br />Work begins in adding more features to it
Tue, 12 Aug 2003 12:07:59 +0200%~#zvonNews 1.1.2%~#zvonNews 1.1.2 has been finished.<br />Features remote xmlrpc blogger API and different auth method.
Wed, 01 Oct 2003 00:00:00 +0200%~#zShaped%~#zvonNews has been renamed to zShaped
