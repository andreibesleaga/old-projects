<?php

// zShaped 1.2 - copyright (c) 2003 Andrei Besleaga
// http://zvonnews.sourceforge.net

// This program is free software; you can redistribute it and/or
// modify it under the terms of the GNU General Public License
// as published by the Free Software Foundation; either version 2
// of the License, or (at your option) any later version.

// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with this program; if not, write to the Free Software
// Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.



require(dirname(__FILE__).'/config.php');
include(ZPATH.'smileys.php');

function zntemplate_exists($templatedir, $echoexit=false)
{
	if(!file_exists($templatedir."/news.html")) {$x=false;}
	elseif(!file_exists($templatedir."/header.html")) {$x=false;}
	elseif(!file_exists($templatedir."/footer.html")) {$x=false;}
	else {$x=true;}
	if($echoexit==true && $x==false) 
	{	
		echo "<font color=\"red\"><b>Error: one or more template files ( $templatedir ) doesn't exist.<br>Make sure templates exists and are readable and define it in the script ...</b></font>";
		exit;
	}
	return $x;
}
function znprogram_end()
{
	if(COPYRIGHT=='no')	{echo "<br><font size=\"1\">powered by <a href=\"http://zvonnews.sourceforge.net\">zShaped</a></font>"; }
	else { echo "<br><font size=\"1\">powered by <a href=\"http://zvonnews.sourceforge.net\">zShaped</a> &copy;2003 Andrei Besleaga</font>"; }
}
function znload($file)
{	global $zntemplate;
	$temp=file($zntemplate.'/'.$file);
	foreach($temp as $i=>$htmldata) {$html.=$htmldata;}
	return $html;
}

set_magic_quotes_runtime(0);
if($_GET['zntemplate']!='')
{
	if(zntemplate_exists(ZPATH.$_GET['zntemplate'],true))
	{
		$zntemplate=ZPATH.$_GET['zntemplate'];
		$htmlheader=znload('header.html');
		$htmlnews=znload('news.html');
		$htmlfooter=znload('footer.html');
	}
}
elseif(zntemplate_exists(ZPATH.ZNTEMPLATE,true)) 
{	
	$zntemplate=ZPATH.ZNTEMPLATE;
	$htmlheader=znload('header.html');
	$htmlnews=znload('news.html');
	$htmlfooter=znload('footer.html');
}


if($_GET['znshowitem']!='')
{
	function znparse_template($html)
	{	global $tmpdate, $tmptitle, $tmpnews, $tmpmsg;
		$html=str_replace("{pubdate}",$tmpdate,$html);
		$html=str_replace("{newstitle}",$tmptitle,$html);
		$html=str_replace("{newscontent}",$tmpnews,$html);
		$html=str_replace("{tofriendurl}",ZURL.'tofriend.php?msg='.$tmpmsg,$html);
		$html=str_replace("{zvonurl}",ZURL,$html);
		$html=str_replace("{pagetab}",'',$html);
		if(TRACKBACK_ENABLED=='yes')
		{
			$entryid=md5($tmpdate.$tmptitle);
			@$tmptracks=file(ZPATH.TRACKBACKSDIR.$entryid);
			if($tmptracks) $trackbacks=count($tmptracks); else $trackbacks=0;
			$rdfabout=READER_PAGE."?znshowitem=".$entryid;
			$zurl=ZURL; $tbdesc=substr($tmpnews,0,50)."...";
			$discovertrackback=<<<EOD
			<!--
			<rdf:RDF xmlns:rdf="http://www.w3.org/1999/02/22-rdf-syntax-ns#"
					 xmlns:trackback="http://madskills.com/public/xml/rss/module/trackback/"
					 xmlns:dc="http://purl.org/dc/elements/1.1/">
			<rdf:Description
				rdf:about="$rdfabout"
				trackback:ping="{$zurl}trackback.php/$entryid"
				dc:title="$tmptitle"
				dc:identifier="$rdfabout"
				dc:description="$tbdesc"
				dc:date="$tmpdate" />
			</rdf:RDF>
			-->
EOD;
			$trackbackhtml="\n".$discovertrackback."\n<a href=\"javascript:open('".ZURL."trackback.php?__mode=view&entry_id=".$entryid."')\" onclick=\"newWindow=window.open('".ZURL."trackback.php?__mode=view&entry_id=".$entryid."','trackback','width=600,height=480,scrollbars=yes,status=yes'); newWindow.focus(); return false;\">TrackBack (".$trackbacks.")</a>\n";
		 	$html=str_replace("{trackback}",$trackbackhtml,$html); 
		}
		else $html=str_replace("{trackback}",'',$html);
		return $html;
	}
	$xnews=file(ZPATH.NEWSFILE); 
	$xnews=array_reverse($xnews);
	$ubound=count($xnews);
	$itemfound=false;
	for($i=0;$i<$ubound-1 && $itemfound==false;$i++)
	{
		$crtsplit="";
		$crtsplit=explode("%~#",$xnews[$i]);
		$tmpdate=$crtsplit[0];
		$tmptitle=$crtsplit[1];
		$tmpnews=$crtsplit[2];
		if(md5($tmpdate.$tmptitle)==$_GET['znshowitem'])
		{
			$tmpmsg=$i;
			echo znparse_template($htmlheader);
			foreach($sface as $sfname => $sffile)
			{
				$tmpnews=str_replace($sfname,"<img src=\"".ZURL."smilies/".$sffile."\"></img>",$tmpnews);
				$tmptitle=str_replace($sfname,"<img src=\"".ZURL."smilies/".$sffile."\"></img>",$tmptitle);
			}
			echo(znparse_template($htmlnews));
			echo znparse_template($htmlfooter);
			znprogram_end();
			$itemfound=true;
		}
	}
	if($itemfound==false)
	{
		$tmpdate=date(DATEFORMAT);
		$tmptitle="Item not found !";
		$tmpnews="<p align=\"center\"><br /><strong>Sorry, that item could not be found !</strong><br /></p>";
		echo znparse_template($htmlheader);
		echo znparse_template($htmlnews);
		echo znparse_template($htmlfooter);
		znprogram_end();
	}
}
elseif(PERPAGE>0)
{

	function pagetab($startpage,$ubound)
	{	global $gettemplate;
		$pagetab='';
		if (PERPAGE<$ubound)
		{
			if($startpage==0) { $pagetab.="< previous | &nbsp;"; }
			else { $pagetab.="&lt; <a href=".$_SERVER['PHP_SELF']."?znpage=$startpage".$gettemplate.">previous</a> | &nbsp;"; }
		}
		if($ubound>PERPAGE)
		{
			for($j=1;$j<=ceil($ubound/PERPAGE);$j++)
			{
				if($j==$startpage+1)
					{ $pagetab.= "$j &nbsp;"; }
				else
					{ $pagetab.= "<a href=".$_SERVER['PHP_SELF']."?znpage=$j".$gettemplate.">$j</a> &nbsp;"; }
			}
		}
		if(PERPAGE<$ubound)
		{
			if($startpage+1>=$ubound/PERPAGE) { $pagetab.= "&nbsp; | next >"; }
			else	{ $pagetab.= "&nbsp; | <a href=".$_SERVER['PHP_SELF']."?znpage=".($startpage+2).$gettemplate.">next</a> &gt;"; }
		}
		return $pagetab;
	}
	
	function znparse_template($html)
	{	global $startpage, $ubound, $tmpdate, $tmptitle, $tmpnews, $tmpmsg;
		$html=str_replace("{pubdate}",$tmpdate,$html);
		$html=str_replace("{newstitle}",$tmptitle,$html);
		$html=str_replace("{newscontent}",$tmpnews,$html);
		$html=str_replace("{tofriendurl}",ZURL.'tofriend.php?msg='.$tmpmsg,$html);
		$html=str_replace("{zvonurl}",ZURL,$html);
		$html=str_replace("{pagetab}",pagetab($startpage,$ubound-1),$html);
		if(TRACKBACK_ENABLED=='yes')
		{
			$entryid=md5($tmpdate.$tmptitle);
			@$tmptracks=file(ZPATH.TRACKBACKSDIR.$entryid);
			if($tmptracks) $trackbacks=count($tmptracks); else $trackbacks=0;
			$rdfabout=READER_PAGE."?znshowitem=".$entryid;
			$zurl=ZURL; $tbdesc=substr($tmpnews,0,50)."...";
			$discovertrackback=<<<EOD
			<!--
			<rdf:RDF xmlns:rdf="http://www.w3.org/1999/02/22-rdf-syntax-ns#"
					 xmlns:trackback="http://madskills.com/public/xml/rss/module/trackback/"
					 xmlns:dc="http://purl.org/dc/elements/1.1/">
			<rdf:Description
				rdf:about="$rdfabout"
				trackback:ping="{$zurl}trackback.php/$entryid"
				dc:title="$tmptitle"
				dc:identifier="$rdfabout"
				dc:description="$tbdesc"
				dc:date="$tmpdate" />
			</rdf:RDF>
			-->
EOD;
			$trackbackhtml="\n".$discovertrackback."\n<a href=\"javascript:open('".ZURL."trackback.php?__mode=view&entry_id=".$entryid."')\" onclick=\"newWindow=window.open('".ZURL."trackback.php?__mode=view&entry_id=".$entryid."','trackback','width=600,height=480,scrollbars=yes,status=yes'); newWindow.focus(); return false;\">TrackBack (".$trackbacks.")</a>\n";
		 	$html=str_replace("{trackback}",$trackbackhtml,$html); 
		}
		else $html=str_replace("{trackback}",'',$html);
		return $html;
	}
	
	

	$startpage=$_GET['znpage'];
	if($_GET['zntemplate']!='') $gettemplate='&zntemplate='.$_GET['zntemplate']; else $gettemplate='';
	$xnews=file(ZPATH.NEWSFILE); 
	$xnews=array_reverse($xnews);
	$startpage-=1;
	$ubound=count($xnews);
	if($startpage<0 || $startpage>=$ubound/PERPAGE) $startpage=0;

	echo znparse_template($htmlheader);
	for($i=$startpage*PERPAGE;$i<$startpage*PERPAGE+PERPAGE && $i<$ubound-1;$i++)
	{
		$crtsplit=""; $tmpmsg=$i;
		$crtsplit=explode("%~#",$xnews[$i]);
		foreach($sface as $sfname => $sffile)
		{
			$crtsplit[2]=str_replace($sfname,"<img src=\"".ZURL."smilies/".$sffile."\"></img>",$crtsplit[2]);
			$crtsplit[1]=str_replace($sfname,"<img src=\"".ZURL."smilies/".$sffile."\"></img>",$crtsplit[1]);
		}
		echo "<a name=\"zn".$tmpmsg."\"></a>";
		$tmpdate=$crtsplit[0];
		$tmptitle=$crtsplit[1];
		$tmpnews=$crtsplit[2];
		echo(znparse_template($htmlnews));
	}
	echo znparse_template($htmlfooter);
	znprogram_end();
}

?>
