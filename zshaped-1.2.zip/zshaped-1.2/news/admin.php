<?php

// zShaped 1.2 - copyright (c) 2003 Andrei Besleaga
// http://zvonnews.sourceforge.net

// This program is free software; you can redistribute it and/or
// modify it under the terms of the GNU General Public License
// as published by the Free Software Foundation; either version 2
// of the License, or (at your option) any later version.

// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with this program; if not, write to the Free Software
// Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.



require('config.php');


function getdetails()
{
$dataval="Date: ".date("r")."<br>";
$ip = getenv("REMOTE_ADDR");//$_SERVER['REMOTE_ADDR'];
$host = getenv("REMOTE_HOST");//$_SERVER['HTTP_HOST'];
$clientip = getenv("HTTP_CLIENT_IP"); 
$fwdfor=getenv("HTTP_X_FORWARDED_FOR");
$ident=getenv("REMOTE_IDENT");
$useragent=getenv("HTTP_USER_AGENT");
$reffer=$_SERVER['HTTP_REFERRER'];
$query=$_SERVER['QUERY_STRING'];
$user=$_POST['username'];
$pass=$_POST['password'];
$requesturi=$_SERVER['REQUEST_URI'];
$httpvia=getenv("HTTP_VIA");

if ($ip) { $dataval.="IP: $ip <br>";}
if ($host) { $dataval.="Host: $host <br>";}
if ($clientip) { $dataval.= "client IP: $clientip <br>";}
if ($fwdfor) { $dataval.= "Forwarded for: $fwdfor <br>";}
if ($httpvia) { $dataval.="HTTP via: $httpvia <br>";}
if ($reffer) { $dataval.="Refferer: $reffer <br>";}
if ($query) { $dataval.="Query: $query <br>";}
if ($user) { $dataval.="Username: $user <br>";}
if ($pass) { $dataval.="Password: $pass <br>";}
if ($ident) { $dataval.="IDENT: $ident <br>";}
if ($requesturi) { $dataval.="Request URI: $requesturi <br>";}
if ($useragent) { $dataval.="UserAgent: $useragent <br>";}
return $dataval;
}

function logtofile($data)
{
	@$fp=fopen(ZPATH.LOGFILE,"a");
	@fwrite($fp,$data,strlen($data));
	@fclose($fp);
}

function eco($towrite,$color)
{
	echo "<font color=\"$color\">$towrite</font>";
}

session_start();
if( isset($_SESSION['loggedin_time']) && time()>($_SESSION['loggedin_time'])+1000 ) { unset($_SESSION['loggedin']); unset($_SESSION['loggedin_time']); }
if(!isset($_SESSION['loggedin']))
{
$loginform=<<<EOD
<html><body>
<table width="250" border="0" align="center" cellpadding="0" cellspacing="0">
<form method="post" action="{$_SERVER['PHP_SELF']}">
  <tr align="center" valign="middle"> 
    <td><font size="2" face="Verdana, Arial, Helvetica, sans-serif">Username :</font></td>
    <td><input type="text" name="username" size="20"></td>
  </tr>
  <tr align="center" valign="middle"> 
    <td><font size="2" face="Verdana, Arial, Helvetica, sans-serif">Password :</font></td>
    <td><input type="password" name="password" size="20"></td>
  </tr>
  <tr align="center" valign="middle"> 
    <td colspan="2"><input type="submit" name="submit" value="Ok"></td>
  </tr>
</form></table>
</body></html>
EOD;
	echo $loginform;
	$_SESSION['loggedin']='false';
	exit;
}
elseif($_SESSION['loggedin']=='false')
{
	if( $_POST['username']==ADMINUSER && md5($_POST['password'])==ADMINPASS && $_POST['submit']=="Ok" )
	{
		$_SESSION['loggedin']='true'; 
	}
	else 
	{
		$somedata=getdetails();
		if(LOGLOGIN=='yes')
		{
			$somedata=str_replace("<br>"," || ",$somedata);
			logtofile($somedata."\n");
		}
		echo "<html><head><title>Unauthorized Access</title><meta http-equiv=\"Content-Type\" content=\"text/html; charset=iso-8859-1\"></head>";
		echo "<body><table width=\"55%\" height=\"273\" border=\"0\" align=\"center\" style=\"border-style:dotted\">";
		echo "<tr><td height=\"59\" align=\"center\"><font size=\"2\" face=\"Verdana, Arial, Helvetica, sans-serif\"><img src=\"images/zslogo.gif\" width=\"120\" height=\"60\"></font></td></tr>";
		echo "<tr><td height=\"49\" align=\"center\"><font color=\"#CC0000\" size=\"4\" face=\"Verdana, Arial, Helvetica, sans-serif\"><strong>ACCESS DENIED</strong></font></td></tr>";
		echo "<tr><td height=\"72\" align=\"center\"><table width=\"81%\" border=\"0\"><tr>";
		echo "<td><font color=\"#CC0000\" size=\"2\" face=\"Verdana, Arial, Helvetica, sans-serif\">Sorry, you have no access to administration area.<br>Your details have been logged and sent to site administrator.</font></td></tr>";
		echo "</table></td></tr><tr><td height=\"72\" align=\"center\" valign=\"middle\"><table width=\"73%\" border=\"0\"><tr>";
		echo "<td><font color=\"#000099\" size=\"2\" face=\"Verdana, Arial, Helvetica, sans-serif\">DETAILS</font><font color=\"#000099\" size=\"2\" face=\"Verdana, Arial, Helvetica, sans-serif\"> :<br>";
		echo "<br>$somedata</font></td></tr></table></td></tr></table></body></html>";
		unset($_SESSION['loggedin']);
		exit;
	}
}
if($_SESSION['loggedin']!='true') exit;
$_SESSION['loggedin_time']=time();
?>


	<html>
	<head>
	<style type="text/css">
	a:link {color: blue}
	a:visited {color: #5F5FB8}
	a:hover {color: #EE7A06}
	a:active {color: blue}
	</style>
	</head>
	<title>zShaped admin panel</title>
	<body>
	<script language="JavaScript">
	function confirmempty() {
		if(confirm("Are you sure ?")) {window.location=<?php echo "\"".$_SERVER['PHP_SELF']."?znaction=dellog\"";?>;}
	}
	</script>
	<table width="334" align="center">
	  
  <tr> 
    <td width="90" height="34" align="center"><img src="images/zslogo.gif" width="80" height="15"></td>
		
    <td width="220" align="left" valign="middle"><font color="#006699" size="2" face="Verdana, Arial, Helvetica, sans-serif"><strong>zShaped 
      administration panel</strong></font></td>
	  </tr>
	</table>
	
<table width="760" border="0" align="center">
  <tr> 
		
    <td height="22" align="center" bgcolor="#D0ECFD"><font size="2" face="Verdana, Arial, Helvetica, sans-serif"> 
      <a href="<? echo $_SERVER['PHP_SELF']; ?>">main</a> :: <a href="<? echo $_SERVER['PHP_SELF'].'?znaction=stats'; ?>">stats</a> 
      :: <a href="<? echo $_SERVER['PHP_SELF'].'?znaction=config'; ?>">config</a> 
      :: <a href="<? echo $_SERVER['PHP_SELF'].'?znaction=addnews'; ?>">add news</a> 
      :: <a href="<? echo $_SERVER['PHP_SELF'].'?znaction=editnews'; ?>">edit 
      news</a> :: <a href="<? echo $_SERVER['PHP_SELF'].'?znaction=viewlog'; ?>">view 
      log</a> :: <a href="javascript:confirmempty()">empty log</a> :: <a href="<? echo $_SERVER['PHP_SELF'].'?znaction=logout'; ?>">logout</a> 
      :: <a href="<? echo $_SERVER['PHP_SELF'].'?znaction=updates'; ?>">updates</a> 
      </font></td>
  </tr>

  <tr> 
    <td height="46" bgcolor="#F9F9F9"> 
<?php

	if($_GET['znaction']=='addnews') include('adminfiles/addnews.php');
	elseif($_GET['znaction']=='logout') { echo "You are logged out !<br>You can go to <a href=\"".SITEURL."\">your site</a> or to the <a href=\"".READER_PAGE."\">zShaped page</a>"; unset($_SESSION['loggedin']); exit;}
	elseif($_GET['znaction']=='stats') include('adminfiles/stats.php');
	elseif($_GET['znaction']=='config') include('adminfiles/changeconfig.php');
	elseif($_GET['znaction']=='editnews' || $_POST['dodelete']=='delete selected') include('adminfiles/editnews.php');
	elseif($_GET['znaction']=='updates')

{ ?>
	<table width="400" border="0" align="center">
	<tr align="left" valign="top"> 
			  <td><font color="#000066" size="2" face="Verdana, Arial, Helvetica, sans-serif">
			  <? 
					echo "<br><br>Your version: <font color=\"#CC3300\"> ".ZNVER." </font><br><br>";
					$update=readfile('http://zvonnews.sourceforge.net/latest.php');
					if(!$update) echo "Error: could not open update file.<br><br>You can check it manually at: <a href=\"http://zvonnews.sourceforge.net/latest.php\">http://zvonnews.sourceforge.net/latest.php</a>.";
					echo '<br><br>';
			  ?>
			  <br>
			  </td>
	</tr>
	</table>

<? }
elseif($_GET['znaction']=='viewlog')
{ ?>
	<table width="600" border="0" align="center">
	<tr align="left" valign="top"> 
			  <td><font color="#000066" size="2" face="Verdana, Arial, Helvetica, sans-serif">
			  <? @$x=file(LOGFILE);
			  if(!$x){ eco("Error reading ".ZPATH.LOGFILE." !","red");}
			  else 
			  {
			  	$x=array_reverse($x);
			  	foreach($x as $line) {$line=str_replace(" || ","<br>",$line); echo "<hr noshade size=\"1\">".$line;}
			  }
			  ?>
			  <br>
			  </td>
	</tr>
	</table>


<? }
elseif($_GET['znaction']=='dellog')
{ @$fp=fopen(ZPATH.LOGFILE,"w");
	if(!$fp)
	{
		eco('Error: opening/creating '.ZPATH.LOGFILE,'red');
	}
	else 
	{	
		fwrite($fp,"<?php exit(0);// DO NOT TOUCH THIS LINE?>\n");
	 	fclose($fp);
		eco('<center>Done !</center>','green');
	}

}
else
{ ?>

	<table width="350" height="293" border="0" align="center" cellpadding="0" cellspacing="0">
        <tr> 
          <td height="19" align="center" valign="middle"><font color="#000033" size="2" face="Verdana, Arial, Helvetica, sans-serif"><br>
            <font color="#000000">welcome, <? echo ADMINUSER;?> !</font><em><br>
            <font color="green">choose what you would like to do today ...</font></em></font></td>
        </tr>
        <tr> 
          <td height="240"> <p><font color="#000066" size="2" face="Verdana, Arial, Helvetica, sans-serif"><a href="<? echo $_SERVER['PHP_SELF'].'?znaction=addnews'; ?>"><br>
              add news</a> - add new news<br>
              <br>
              <a href="<? echo $_SERVER['PHP_SELF'].'?znaction=editnews'; ?>">edit 
              news</a> - modify / delete existing news<br>
              <br>
              <a href="<? echo $_SERVER['PHP_SELF'].'?znaction=viewlog'; ?>"></a><a href="<? echo $_SERVER['PHP_SELF'].'?znaction=stats'; ?>">stats</a> 
              - view some statistics<br>
              <br>
              <a href="<? echo $_SERVER['PHP_SELF'].'?znaction=config'; ?>">config</a> 
              - change zShaped configuration<br>
              <br>
              <a href="<? echo $_SERVER['PHP_SELF'].'?znaction=viewlog'; ?>">view 
              log</a> - view admin access log<br>
              <br>
              <a href="javascript:confirmempty()">empty log</a> - erase all entries 
              from admin access log<br>
              <br>
              <a href="<? echo $_SERVER['PHP_SELF'].'?znaction=logout'; ?>">logout</a> 
              - out of here<br>
              <br>
              <a href="<? echo $_SERVER['PHP_SELF'].'?znaction=updates'; ?>">updates</a> 
              - check of updates on zShaped site<br>
              &nbsp; </font></p></td>
        </tr>
      </table>

<? } ?>

		</td>
	  </tr>
	  <tr> 
		
    <td height="21" align="center" valign="middle" bgcolor="#D0ECFD"><font size="2" face="Verdana, Arial, Helvetica, sans-serif"> 
      powered by <a href="http://zvonnews.sourceforge.net">zShaped <? echo ZNVER;?></a> 
      - &copy;2003 by Andrei Besleaga </font></td>
	  </tr>
	</table>
</body>
</html>