<?php

// zShaped 1.2 - copyright (c) 2003 Andrei Besleaga
// http://zvonnews.sourceforge.net

// This program is free software; you can redistribute it and/or
// modify it under the terms of the GNU General Public License
// as published by the Free Software Foundation; either version 2
// of the License, or (at your option) any later version.

// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with this program; if not, write to the Free Software
// Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.

define("ZNVER","1.2");
?>


<html>
<head>
<title>zShaped installation</title>
<head>
<style type="text/css">
a:link {color: blue}
a:visited {color: #5F5FB8}
a:hover {color: #EE7A06}
a:active {color: blue}
</style>
</head>
</head>
<body>
<table width="222" border="0" align="center">
  <tr align="left" valign="middle"> 
    <td width="15%" valign="middle"><strong><font color="#006699" size="2" face="Verdana, Arial, Helvetica, sans-serif"><img src="images/zslogo.gif" /> 
      </font></strong></td>
    <td width="85%" align="center" valign="middle"><strong><font color="#006699" size="2" face="Verdana, Arial, Helvetica, sans-serif">W</font><font color="#006699" size="2" face="Verdana, Arial, Helvetica, sans-serif">elcome 
      to zShaped installation</font></strong></td>
  </tr>
</table>
<table width="700" border="0" align="center">
  <tr align="center" valign="middle" bgcolor="#D0ECFD"> 
    <td height="15" align="center" valign="top">&nbsp; </td>
  </tr>
  <tr align="center" valign="middle" bgcolor="#F4F4F4"> 
    <td align="center" valign="top"> 
      <? 
function eco($towrite,$color)
{
	echo "<font color=\"$color\">$towrite</font>";
}
$id=$_REQUEST['id'];
if($id=='act1')
{  $allok=true; ?>
      <table width="600" border="0">
        <tr> 
          <td height="117" colspan="2" align="center"><font color="#000066" size="2" face="Verdana, Arial, Helvetica, sans-serif">Before 
            continuing with install you need to make sure that : <br>
            <font color="#CC3300"> <font color="#000066"><br>
            -</font> config.php</font>, <font color="#CC3300">log.php</font>, 
            <font color="#CC3300">news.php</font> have write permissions<br>
            (you can do this with your FTP client, or CHMOD 0766)<br>
            <br>
            - all the script files exists in the same directory as this installer 
            <br>
            <br>
            - the rest of files does have execute permissions (CHMOD 0755)<br>
            </font> <hr width="500" size="1" noshade> <font color="#000066" size="2" face="Verdana, Arial, Helvetica, sans-serif"> 
            system summary check:<br>
            </font></td>
        </tr>
        <tr> 
          <td width="296" align="right"><font color="#000066" size="2" face="Verdana, Arial, Helvetica, sans-serif">admin.php 
            </font></td>
          <td width="294" align="left"><font color="#000066" size="2" face="Verdana, Arial, Helvetica, sans-serif">&nbsp; 
            <? if(file_exists('admin.php')) {eco('exists','green');} else {eco('does not exists','red');$allok=false;} ?>
            </font></td>
        </tr>
        <tr> 
          <td align="right"><font color="#CC3300" size="2" face="Verdana, Arial, Helvetica, sans-serif">config.php 
            </font></td>
          <td align="left"><font size="2" face="Verdana, Arial, Helvetica, sans-serif">&nbsp; 
            <? if(file_exists('config.php')) {eco('exists','green'); if(is_writable('config.php')){eco('&nbsp; and is writable','green');} else {eco('&nbsp; and is NOT writable','red');$allok=false;} } else {eco('does not exists','red');$allok=false;} ?>
            </font></td>
        </tr>
        <tr> 
          <td align="right"><font color="#000066" size="2" face="Verdana, Arial, Helvetica, sans-serif">index.php</font></td>
          <td align="left"><font color="#000066" size="2" face="Verdana, Arial, Helvetica, sans-serif">&nbsp; 
            <? if(file_exists('index.php')) eco('exists','green'); else {eco('does not exists','red');$allok=false;} ?>
            </font></td>
        </tr>
        <tr> 
          <td align="right"><font color="#CC3300" size="2" face="Verdana, Arial, Helvetica, sans-serif">log.php</font></td>
          <td align="left"><font color="#000066" size="2" face="Verdana, Arial, Helvetica, sans-serif">&nbsp; 
            <? if(file_exists('log.php')) {eco('exists','green'); if(is_writable('log.php')){eco('&nbsp; and is writable','green');} else {eco('&nbsp; and is NOT writable','red');$allok=false;} } else {eco('does not exists','red');$allok=false;} ?>
            </font></td>
        </tr>
        <tr> 
          <td align="right"><font color="#CC3300" size="2" face="Verdana, Arial, Helvetica, sans-serif">news.php</font></td>
          <td align="left"><font color="#000066" size="2" face="Verdana, Arial, Helvetica, sans-serif">&nbsp; 
            <? if(file_exists('news.php')) {eco('exists','green'); if(is_writable('news.php')){eco('&nbsp; and is writable','green');} else {eco('&nbsp; and is NOT writable','red');$allok=false;} } else {eco('does not exists','red');$allok=false;} ?>
            </font></td>
        </tr>
        <tr> 
          <td align="right"><font color="#000066" size="2" face="Verdana, Arial, Helvetica, sans-serif">readnews.php</font></td>
          <td align="left"><font color="#000066" size="2" face="Verdana, Arial, Helvetica, sans-serif">&nbsp; 
            <? if(file_exists('readnews.php')) eco('exists','green'); else {eco('does not exists','red');$allok=false;} ?>
            </font></td>
        </tr>
        <tr> 
          <td align="right"><font color="#000066" size="2" face="Verdana, Arial, Helvetica, sans-serif">rss.php</font></td>
          <td align="left"><font color="#000066" size="2" face="Verdana, Arial, Helvetica, sans-serif">&nbsp; 
            <? if(file_exists('rss.php')) eco('exists','green'); else {eco('does not exists','red');$allok=false;} ?>
            </font></td>
        </tr>
        <tr> 
          <td align="right"><font color="#000066" size="2" face="Verdana, Arial, Helvetica, sans-serif">search.php</font></td>
          <td align="left"><font color="#000066" size="2" face="Verdana, Arial, Helvetica, sans-serif">&nbsp; 
            <? if(file_exists('search.php')) eco('exists','green'); else {eco('does not exists','red');$allok=false;} ?>
            </font></td>
        </tr>
        <tr> 
          <td align="right"><font color="#000066" size="2" face="Verdana, Arial, Helvetica, sans-serif">smileys.php</font></td>
          <td align="left"><font color="#000066" size="2" face="Verdana, Arial, Helvetica, sans-serif">&nbsp; 
            <? if(file_exists('smileys.php')) eco('exists','green'); else {eco('does not exists','red');$allok=false;} ?>
            </font></td>
        </tr>
        <tr> 
          <td align="right"><font color="#000066" size="2" face="Verdana, Arial, Helvetica, sans-serif">tofriend.php</font></td>
          <td align="left"><font color="#000066" size="2" face="Verdana, Arial, Helvetica, sans-serif"> 
            &nbsp; 
            <? if(file_exists('tofriend.php')) eco('exists','green'); else {eco('does not exists','red');$allok=false;} ?>
            </font></td>
        </tr>
        <tr> 
          <td colspan="2" align="right">&nbsp;</td>
        </tr>
        <tr align="center"> 
          <td colspan="2"><font color="#000066" size="2" face="Verdana, Arial, Helvetica, sans-serif">when</font><font color="#000066" size="2" face="Verdana, Arial, Helvetica, sans-serif"> 
            conditions are met you can <br>
            <? if($allok==true) echo " <a href=\"".$_SERVER['PHP_SELF']."?id=act2\"><img src=\"images/install.gif\" alt=\"continue\" width=\"40\" height=\"40\" border=\"0\"></img><br><center>continue installing</center></a>"; else echo "<center> refresh this page and continue installing</center>";?>
            &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</font></td>
        </tr>
      </table>
<? } elseif($id=='act2')
{ 
      function geturl()
	{
            $url = '';
            if(isset($_SERVER['HTTP_REFERRER'])) $url = str_replace( "install.php", "", $_SERVER['HTTP_REFERRER']);
            if (!$url && isset($_SERVER['SCRIPT_NAME']))
		{ $url = 'http://'.$_SERVER['SERVER_NAME'].substr($_SERVER['SCRIPT_NAME'],0, -11); }
            return $url;
	}

      function getpath()
	{
            $path = dirname(__FILE__);
            return str_replace("\\", "/", $path)."/";
	}

	$serverurl = 'http://'.$_SERVER['SERVER_NAME'];
	$zurl = geturl();
	$zpath = getpath();
?>

		
      <table width="700" border="0" align="center" cellpadding="0" cellspacing="3">
        <form name="configform" action="<? echo $_SERVER['PHP_SELF'].'?id=act3';?>" method="post">
          <tr align="center" valign="middle"> 
            <td height="99" colspan="2"> <table width="600" border="0" cellspacing="0" cellpadding="0">
                <tr> 
                  <td height="99"><font color="#CC3300" size="2" face="Verdana, Arial, Helvetica, sans-serif">Notes:<br>
                    </font><font color="#000066" size="2" face="Verdana, Arial, Helvetica, sans-serif"><br>
                    - fields marked with * are required, anything else is optional 
                    and can be empty<br>
                    </font><font color="#000066" size="2" face="Verdana, Arial, Helvetica, sans-serif">- 
                    url's and path are guessed by the script so be sure to check 
                    the fields to be correct <br>
                    - password will be encrypted and cannot be revealed, make 
                    sure you remeber it<br>
                    &nbsp;&nbsp;(or you will have to reinstall)</font></td>
                </tr>
              </table></td>
          </tr>
          <tr valign="top"> 
            <td colspan="2" align="center">&nbsp;</td>
          </tr>
          <tr valign="top"> 
            <td colspan="2" align="center"><strong><font color="#000000" size="2" face="Verdana, Arial, Helvetica, sans-serif">General 
              configuration</font></strong></td>
          </tr>
          <tr valign="top"> 
            <td colspan="2" align="center"><font color="#000066" size="2" face="Verdana, Arial, Helvetica, sans-serif">&nbsp; 
              </font></td>
          </tr>
          <tr valign="top"> 
            <td align="right"><font color="#000066" size="2" face="Verdana, Arial, Helvetica, sans-serif">* 
              your site url :</font></td>
            <td><font color="#000066" size="2" face="Verdana, Arial, Helvetica, sans-serif">&nbsp; 
              <input name="siteurl" type="text" id="siteurl" value="<? echo $serverurl;?>" size="60" style="border-style:groove;" ></input> 
              </font></td>
          </tr>
          <tr valign="top"> 
            <td align="right"><font color="#000066" size="2" face="Verdana, Arial, Helvetica, sans-serif">* 
              zShaped url :</font></td>
            <td><font color="#000066" size="2" face="Verdana, Arial, Helvetica, sans-serif">&nbsp; 
              <input name="zvonurl" type="text" id="zvonurl" value="<? echo $zurl;?>" size="60" style="border-style:groove;" ></input> 
              </font></td>
          </tr>
          <tr valign="top"> 
            <td align="right"><font color="#000066" size="2" face="Verdana, Arial, Helvetica, sans-serif">* 
              zShaped path :</font></td>
            <td><font color="#000066" size="2" face="Verdana, Arial, Helvetica, sans-serif">&nbsp; 
              <input name="zvonpath" type="text" id="zvonpath" value="<? echo $zpath;?>" size="60" style="border-style:groove;"></input> 
              </font></td>
          </tr>
          <tr valign="top"> 
            <td height="22" align="right"><font color="#000066" size="1" face="Verdana, Arial, Helvetica, sans-serif"><font size="2">* 
              url to page where</font> readnews.php <font size="2">is included</font></font><font color="#000066" size="2" face="Verdana, Arial, Helvetica, sans-serif"> 
              :</font></td>
            <td><font color="#000066" size="2" face="Verdana, Arial, Helvetica, sans-serif">&nbsp; 
              <input name="readerpage" type="text" id="readerpage" size="60" style="border-style:groove;"></input> 
              </font></td>
          </tr>
          <tr valign="top"> 
            <td align="right"><font color="#000066" size="2" face="Verdana, Arial, Helvetica, sans-serif">* 
              admin username :</font></td>
            <td><font color="#000066" size="2" face="Verdana, Arial, Helvetica, sans-serif">&nbsp; 
              <input name="adminname" type="text" id="adminname" style="border-style:groove;"></input> 
              </font></td>
          </tr>
          <tr valign="top"> 
            <td height="16" align="right"><font color="#000066" size="2" face="Verdana, Arial, Helvetica, sans-serif">* 
              log admin login :</font></td>
            <td><font color="#000066" size="2" face="Verdana, Arial, Helvetica, sans-serif">&nbsp; 
              <select name="logaccess" id="logaccess" style="border-style:groove;">
                <option value="yes" selected >yes</option>
                <option value="no" >no</option>
              </select>
              </font></td>
          </tr>
          <tr valign="top"> 
            <td align="right"><font color="#000066" size="2" face="Verdana, Arial, Helvetica, sans-serif">* 
              admin password :</font></td>
            <td><font color="#000066" size="2" face="Verdana, Arial, Helvetica, sans-serif">&nbsp; 
              <input name="adminpass" type="password" id="adminpass" style="border-style:groove;"></input> 
              </font></td>
          </tr>
          <tr valign="top"> 
            <td align="right"><font color="#000066" size="2" face="Verdana, Arial, Helvetica, sans-serif"> 
              * admin password confirm :</font></td>
            <td><font color="#000066" size="2" face="Verdana, Arial, Helvetica, sans-serif">&nbsp; 
              <input name="admincheck" type="password" id="admincheck" style="border-style:groove;"></input> 
              </font></td>
          </tr>
          <tr valign="top"> 
            <td align="right"><font color="#000066" size="2" face="Verdana, Arial, Helvetica, sans-serif">* 
              enable offline composing :</font></td>
            <td><font color="#000066" size="2" face="Verdana, Arial, Helvetica, sans-serif">&nbsp; 
              <select name="blogapi" id="blogapi" style="border-style:groove;">
                <option value="yes" selected>yes</option>
                <option value="no">no</option>
              </select>
              <font color="#006699" size="1">(if yes then blogger API is enabled)</font></font></td>
          </tr>
          <tr valign="top"> 
            <td colspan="2" align="right"><font color="#000066" size="2" face="Verdana, Arial, Helvetica, sans-serif">&nbsp;</font><font color="#000066" size="2" face="Verdana, Arial, Helvetica, sans-serif">&nbsp;</font></td>
          </tr>
          <tr valign="top"> 
            <td colspan="2" align="center"><strong><font color="#000000" size="2" face="Verdana, Arial, Helvetica, sans-serif">News 
              reader options</font></strong></td>
          </tr>
          <tr valign="top"> 
            <td align="right"><font color="#000066" size="2" face="Verdana, Arial, Helvetica, sans-serif">&nbsp;</font></td>
            <td><font color="#000066" size="2" face="Verdana, Arial, Helvetica, sans-serif">&nbsp;</font></td>
          </tr>
          <tr valign="top"> 
            <td align="right"><font color="#000066" size="2" face="Verdana, Arial, Helvetica, sans-serif">* 
              how many news to display on a page :</font></td>
            <td><font color="#000066" size="2" face="Verdana, Arial, Helvetica, sans-serif">&nbsp; 
              <input name="perpage" type="text" id="perpage" value="3" style="border-style:groove;"></input> 
              </font></td>
          </tr>
          <tr valign="top"> 
            <td align="right"><font color="#000066" size="2" face="Verdana, Arial, Helvetica, sans-serif">* 
              template used to display news :</font></td>
            <td><font color="#000066" size="2" face="Verdana, Arial, Helvetica, sans-serif">&nbsp; 
              <select name="template" id="template" style="border-style:groove;">
                <?		
				$handle = opendir("templates/readnews"); 
				while($dirfile = readdir($handle))
				{ 
					if( is_dir('templates/readnews/'.$dirfile) && $dirfile!='.' && $dirfile!='..' && file_exists('templates/readnews/'.$dirfile.'/header.html') && file_exists('templates/readnews/'.$dirfile.'/news.html') && file_exists('templates/readnews/'.$dirfile.'/footer.html') )
					{ echo "<option value=\"$dirfile\">$dirfile</option>"; }
				} 
				closedir($handle); 
		 ?>
              </select>
              </font></td>
          </tr>
          <tr valign="top"> 
            <td align="right"><font color="#000066" size="2" face="Verdana, Arial, Helvetica, sans-serif">* 
              date format <font color="#006699">(PHP date format)</font> :</font></td>
            <td><font color="#000066" size="2" face="Verdana, Arial, Helvetica, sans-serif">&nbsp; 
              <input name="dateformat" type="text" id="dateformat" value="r" style="border-style:groove;"></input> 
              <a href="http://www.php.net/manual/en/function.date.php" onClick="window.open('http://www.php.net/manual/en/function.date.php'); return false;">?</a></font></td>
          </tr>
          <tr valign="top"> 
            <td align="right"><font color="#000066" size="2" face="Verdana, Arial, Helvetica, sans-serif">* 
              should author copyright be also visible :</font></td>
            <td><font color="#000066" size="2" face="Verdana, Arial, Helvetica, sans-serif">&nbsp; 
              <select name="copyright" id="copyright" style="border-style:groove;">
                <option value="yes" selected >yes</option>
                <option value="no">no</option>
              </select>
              </font></td>
          </tr>
          <tr valign="top"> 
            <td align="right"><font color="#000066" size="2" face="Verdana, Arial, Helvetica, sans-serif"> 
              * (email news) send to friend enabled :</font></td>
            <td><font color="#000066" size="2" face="Verdana, Arial, Helvetica, sans-serif">&nbsp; 
              <select name="sendtofriend" id="sendtofriend" style="border-style:groove;">
                <option value="enabled" selected>enabled</option>
                <option value="disabled">disabled</option>
              </select>
              </font></td>
          </tr>
          <tr valign="top"> 
            <td align="right"><font color="#000066" size="2" face="Verdana, Arial, Helvetica, sans-serif">* 
              enable trackback :</font></td>
            <td><font color="#000066" size="2" face="Verdana, Arial, Helvetica, sans-serif">&nbsp; 
              <select name="trackback" id="trackback" style="border-style:groove;">
                <option value="yes">yes</option>
                <option value="no" selected>no</option>
              </select>
              </font></td>
          </tr>
          <tr valign="top"> 
            <td align="right"><font color="#000066" size="2" face="Verdana, Arial, Helvetica, sans-serif">* 
              trackbacks directory :</font></td>
            <td><font color="#000066" size="2" face="Verdana, Arial, Helvetica, sans-serif">&nbsp; 
              <input name="trackbacksdir" type="text" id="trackbacksdir" value="trackbacks" style="border-style:groove;">
              </font></td>
          </tr>
          <tr valign="top"> 
            <td height="18" align="right"><font color="#000066" size="2" face="Verdana, Arial, Helvetica, sans-serif">&nbsp;</font></td>
            <td><font color="#000066" size="2" face="Verdana, Arial, Helvetica, sans-serif">&nbsp;</font></td>
          </tr>
          <tr valign="top"> 
            <td colspan="2" align="center"><strong><font color="#000000" size="2" face="Verdana, Arial, Helvetica, sans-serif">RSS 
              syndication options (<a href="http://backend.userland.com/rss/" onClick="window.open('http://backend.userland.com/rss/'); return false;">RSS 
              specs</a>)</font></strong></td>
          </tr>
          <tr valign="top"> 
            <td align="right"><font color="#000066" size="2" face="Verdana, Arial, Helvetica, sans-serif">&nbsp;</font></td>
            <td><font color="#000066" size="2" face="Verdana, Arial, Helvetica, sans-serif">&nbsp;</font></td>
          </tr>
          <tr valign="top"> 
            <td align="right"><font color="#000066" size="2" face="Verdana, Arial, Helvetica, sans-serif">* 
              how many latest news to syndicate :<br>
              <font color="#006699">(0 - disabled)</font> </font></td>
            <td><font color="#000066" size="2" face="Verdana, Arial, Helvetica, sans-serif">&nbsp; 
              <input name="rssnr" type="text" id="rssnr" value="10" style="border-style:groove;"></input> 
              </font></td>
          </tr>
          <tr valign="top"> 
            <td align="right"><font color="#000066" size="2" face="Verdana, Arial, Helvetica, sans-serif">XML 
              encoding charset :</font></td>
            <td><font color="#000066" size="2" face="Verdana, Arial, Helvetica, sans-serif">&nbsp; 
              <input name="xmlencoding" type="text" id="xmlencoding" size="60" style="border-style:groove;"></input> 
              <a href="http://www.iana.org/assignments/character-sets" onClick="window.open('http://www.iana.org/assignments/character-sets'); return false;">?</a> 
              </font></td>
          </tr>
          <tr valign="top"> 
            <td align="right"><font color="#000066" size="2" face="Verdana, Arial, Helvetica, sans-serif"> 
              * channel (weblog) name :</font></td>
            <td><font color="#000066" size="2" face="Verdana, Arial, Helvetica, sans-serif">&nbsp; 
              <input name="rsschannel" type="text" id="rsschannel" value="a zShaped channel" size="60" style="border-style:groove;"></input> 
              </font></td>
          </tr>
          <tr valign="top"> 
            <td align="right"><font color="#000066" size="2" face="Verdana, Arial, Helvetica, sans-serif">* 
              channel description :</font></td>
            <td><font color="#000066" size="2" face="Verdana, Arial, Helvetica, sans-serif">&nbsp; 
              <input name="rssdesc" type="text" id="rssdesc" value="powered by zShaped" size="60" style="border-style:groove;"></input> 
              </font></td>
          </tr>
          <tr valign="top"> 
            <td align="right"><font color="#000066" size="2" face="Verdana, Arial, Helvetica, sans-serif">channel 
              language :</font></td>
            <td><font color="#000066" size="2" face="Verdana, Arial, Helvetica, sans-serif">&nbsp; 
              <input name="rsslang" type="text" id="rsslang" value="en" style="border-style:groove;"></input> 
              <a href="http://backend.userland.com/stories/storyReader$16" onClick="window.open('http://backend.userland.com/stories/storyReader$16'); return false;">?</a> 
              </font></td>
          </tr>
          <tr valign="top"> 
            <td align="right"><font color="#000066" size="2" face="Verdana, Arial, Helvetica, sans-serif">webmaster 
              email address :</font></td>
            <td><font color="#000066" size="2" face="Verdana, Arial, Helvetica, sans-serif">&nbsp; 
              <input name="rsswebmaster" type="text" id="rsswebmaster" style="border-style:groove;"></input> 
              </font></td>
          </tr>
          <tr valign="top"> 
            <td align="right"><font color="#000066" size="2" face="Verdana, Arial, Helvetica, sans-serif">managing 
              editor email address :</font></td>
            <td><font color="#000066" size="2" face="Verdana, Arial, Helvetica, sans-serif">&nbsp; 
              <input name="rsseditor" type="text" id="rsseditor" style="border-style:groove;"></input> 
              </font></td>
          </tr>
          <tr valign="top"> 
            <td align="right"><font color="#000066" size="2" face="Verdana, Arial, Helvetica, sans-serif">copyright 
              notice for content in channel :</font></td>
            <td><font color="#000066" size="2" face="Verdana, Arial, Helvetica, sans-serif">&nbsp; 
              <input name="rsscopyright" type="text" id="rsscopyright" size="60" style="border-style:groove;"></input> 
              </font></td>
          </tr>
          <tr valign="top"> 
            <td align="right"><font color="#000066" size="2" face="Verdana, Arial, Helvetica, sans-serif">category 
              domain :</font></td>
            <td><font color="#000066" size="2" face="Verdana, Arial, Helvetica, sans-serif">&nbsp; 
              <input name="rssdomain" type="text" id="rssdomain" style="border-style:groove;"></input> 
              </font></td>
          </tr>
          <tr valign="top"> 
            <td align="right"><font color="#000066" size="2" face="Verdana, Arial, Helvetica, sans-serif">category 
              id :</font></td>
            <td><font color="#000066" size="2" face="Verdana, Arial, Helvetica, sans-serif">&nbsp; 
              <input name="rsscategory" type="text" id="rsscategory" style="border-style:groove;"></input> 
              </font></td>
          </tr>
          <tr valign="top"> 
            <td align="right"><font color="#000066" size="2" face="Verdana, Arial, Helvetica, sans-serif">time 
              to live :<br>
              <font color="#006699">(minutes aggregators can cache the feed)</font> 
              </font></td>
            <td><font color="#000066" size="2" face="Verdana, Arial, Helvetica, sans-serif">&nbsp; 
              <input name="rssttl" type="text" id="rssttl" style="border-style:groove;"></input> 
              </font></td>
          </tr>
          <tr valign="top"> 
            <td align="right"><font color="#000066" size="2" face="Verdana, Arial, Helvetica, sans-serif">channel 
              image title :</font></td>
            <td><font color="#000066" size="2" face="Verdana, Arial, Helvetica, sans-serif">&nbsp; 
              <input name="rssimagetitle" type="text" id="rssimagetitle" value="a zShaped channel" size="60" style="border-style:groove;"></input> 
              </font></td>
          </tr>
          <tr valign="top"> 
            <td align="right"><font color="#000066" size="2" face="Verdana, Arial, Helvetica, sans-serif">channel 
              image url :</font></td>
            <td><font color="#000066" size="2" face="Verdana, Arial, Helvetica, sans-serif">&nbsp; 
              <input name="rssimageurl" type="text" id="rssimageurl" value="http://zvonnews.sourceforge.net/images/rsslogo.gif" size="60" style="border-style:groove;"></input> 
              </font></td>
          </tr>
          <tr valign="top"> 
            <td align="right"><font color="#000066" size="2" face="Verdana, Arial, Helvetica, sans-serif">channel 
              image link :</font></td>
            <td><font color="#000066" size="2" face="Verdana, Arial, Helvetica, sans-serif">&nbsp; 
              <input name="rssimagelink" type="text" id="rssimagelink" value="http://zvonnews.sourceforge.net" size="60" style="border-style:groove;"></input> 
              </font></td>
          </tr>
          <tr valign="top"> 
            <td align="right"><font color="#000066" size="2" face="Verdana, Arial, Helvetica, sans-serif">channel 
              image description :</font></td>
            <td><font color="#000066" size="2" face="Verdana, Arial, Helvetica, sans-serif">&nbsp; 
              <input name="rssimagedesc" type="text" id="rssimagedesc" value="zShaped - PHP scripts for news management and RSS syndication" size="60" style="border-style:groove;"></input> 
              </font></td>
          </tr>
          <tr valign="top"> 
            <td align="right"><font color="#000066" size="2" face="Verdana, Arial, Helvetica, sans-serif">channel 
              image width :</font></td>
            <td><font color="#000066" size="2" face="Verdana, Arial, Helvetica, sans-serif">&nbsp; 
              <input name="rssimagewidth" type="text" id="rssimagewidth" style="border-style:groove;"></input> 
              </font></td>
          </tr>
          <tr valign="top"> 
            <td align="right"><font color="#000066" size="2" face="Verdana, Arial, Helvetica, sans-serif">channel 
              image height :</font></td>
            <td><font color="#000066" size="2" face="Verdana, Arial, Helvetica, sans-serif">&nbsp; 
              <input name="rssimageheight" type="text" id="rssimageheight" style="border-style:groove;"></input> 
              </font></td>
          </tr>
          <tr valign="top"> 
            <td align="right"><font color="#000066" size="2" face="Verdana, Arial, Helvetica, sans-serif">if 
              RSS is disabled title :</font></td>
            <td><font color="#000066" size="2" face="Verdana, Arial, Helvetica, sans-serif">&nbsp; 
              <input name="rssdisabledtitle" type="text" id="rssdisabledtitle" value="News is disabled !" size="60" style="border-style:groove;"></input> 
              </font></td>
          </tr>
          <tr valign="top"> 
            <td align="right"><font color="#000066" size="2" face="Verdana, Arial, Helvetica, sans-serif"> 
              if RSS is disabled content :</font></td>
            <td><font color="#000066" size="2" face="Verdana, Arial, Helvetica, sans-serif">&nbsp; 
              <input name="rssdisableddesc" type="text" id="rssdisableddesc" value="News on this channel has been disabled by webmaster" size="60" style="border-style:groove;"></input> 
              </font></td>
          </tr>
          <tr valign="top"> 
            <td height="19" align="right"><font color="#000066" size="2" face="Verdana, Arial, Helvetica, sans-serif">items 
              description length (characters) :<br>
              <font color="#006699">(-1 no news content, 0 full news content)</font></font></td>
            <td><font color="#000066" size="2" face="Verdana, Arial, Helvetica, sans-serif">&nbsp; 
              <input name="rssdesclength" type="text" id="rssdesclength" value="0" style="border-style:groove;"></input> 
              </font></td>
          </tr>
          <tr valign="top"> 
            <td height="24" align="right"><font color="#000066" size="2" face="Verdana, Arial, Helvetica, sans-serif">items 
              publication date :<font color="#006699"><br>
              </font></font></td>
            <td><font color="#000066" size="2" face="Verdana, Arial, Helvetica, sans-serif">&nbsp; 
              <select name="rssitempubdate" id="rssitempubdate">
                <option value="yes">yes</option>
                <option value="no" selected>no</option>
              </select>
              <font color="#006699">(only if date format is &quot;r&quot; or RFC 
              822 compatible)</font> </font></td>
          </tr>
          <tr valign="top"> 
            <td align="right">&nbsp;</td>
            <td>&nbsp;</td>
          </tr>
          <tr valign="top"> 
            <td height="24" colspan="2" align="center"><font size="2" face="Verdana, Arial, Helvetica, sans-serif"><a href="<? echo $_SERVER['PHP_SELF'].'?id=act3';?>"> 
              <input name="submitform" type="submit" id="submitform" value="submit and continue" style="border-style:groove;"></input> 
            </td>
          </tr>
          <tr valign="top"> 
            <td height="16" align="right"><font color="#000066" size="2" face="Verdana, Arial, Helvetica, sans-serif">&nbsp;</font></td>
            <td><font color="#000066" size="2" face="Verdana, Arial, Helvetica, sans-serif">&nbsp;</font></td>
          </tr>
        </form>
      </table>

<? }

if($_POST['submitform']=='submit and continue' && $id=='act3')
{	$allok=true;
	if($_POST['siteurl']=='') {eco('<hr><br>Enter a site URL .<br>Please go back and try again ...<hr>','red');$allok=false;}
	if($_POST['zvonurl']=='') {eco('<hr><br>Enter a zShaped URL.<br>Please go back and try again ...<hr>','red');$allok=false;}
	if($_POST['zvonpath']=='') {eco('<hr><br>Enter a zShaped path .<br>Please go back and try again ...<hr>','red');$allok=false;}
	if($_POST['adminname']=='') {eco('<hr><br>Enter an admin username.<br>Please go back and try again ...<hr>','red');$allok=false;}
	if($_POST['adminpass']=='') {eco('<hr><br>Enter an access password .<br>Please go back and try again ...<hr>','red');$allok=false;}
	if($_POST['adminpass']!=$_POST['admincheck']) {eco('<hr><br>Passwords do not match.<br>Please go back and try again ...<hr>','red');$allok=false;}
	if($_POST['perpage']<0 || $_POST['perpage']=='') {eco('<hr><br>Enter news per page .<br>Please go back and try again ...<hr>','red');$allok=false;}
	if($_POST['dateformat']=='') {eco('<hr><br>Enter a date format (same as PHP date function format).<br>Please go back and try again ...<hr>','red');$allok=false;}
	if($_POST['rssnr']=='' || $_POST['rssnr']<0) {eco('<hr><br>Enter a number of news to be advertised with RSS (0 - disabled).<br>Please go back and try again ...<hr>','red');$allok=false;}
	if($_POST['rsschannel']=='') {eco('<hr><br>Enter a name for your RSS feed channel.<br>Please go back and try again ...<hr>','red');$allok=false;}
	if($_POST['rssdesc']=='') {eco('<hr><br>Enter a RSS channel description .<br>Please go back and try again ...<hr>','red');$allok=false;}
	if($_POST['trackbacksdir']=='') {eco('<hr><br>Enter a directory where trackbacks should be stored.<br>Please go back and try again ...<hr>','red');$allok=false;}
	if($_POST['readerpage']=='') {eco('<hr><br>Enter the full URL of the file in which readnews.php will be included<br>Please go back and try again ...<hr>','red');$allok=false;}
	if($allok==true)
	{
		@$fp=fopen('news.php','a');
		@fwrite($fp,date($_POST['dateformat'])."%~#zShaped installation%~#zShaped ".ZNVER." has been installed today<br>Congratulations and thank you for choosing zShaped ! :smile:\n");
		@fclose($fp);

		@$fp=fopen('config.php','w');
		if($fp)
		{	
			$adminpassword=md5($_POST['adminpass']);
			fwrite($fp,"<?php\n// zShaped ".ZNVER." - copyright (c) 2003 Andrei Besleaga\n");
			fwrite($fp,"// configuration file\n\n\n");
			fwrite($fp,"// general configuration options\n\n");
			fwrite($fp,"define(\"SITEURL\",\"".$_POST['siteurl']."\"); // the URL (address) of your website (http://www.yourdomain.com)\n");
			fwrite($fp,"define(\"ZURL\",\"".$_POST['zvonurl']."\");	// full URL to zShaped script\n");
			fwrite($fp,"define(\"ZPATH\",\"".$_POST['zvonpath']."\"); // path to zShaped script\n");
			fwrite($fp,"define(\"READER_PAGE\",\"".$_POST['readerpage']."\"); // url to page where readnews.php is included\n");
			fwrite($fp,"define(\"NEWSFILE\",\"news.php\"); // you can change this value if you rename your 'news.php' file\n");
			fwrite($fp,"define(\"ADMINUSER\",\"".$_POST['adminname']."\"); // admin username\n");
			fwrite($fp,"define(\"ADMINPASS\",\"".$adminpassword."\"); // crypted admin password\n");
			fwrite($fp,"define(\"LOGLOGIN\",\"".$_POST['logaccess']."\"); // if 'yes' then all admin logins are logged\n");
			fwrite($fp,"define(\"LOGFILE\",\"log.php\"); // log file name\n");
			fwrite($fp,"define(\"BLOGAPI_ENABLED\",\"".$_POST['blogapi']."\"); // if 'yes' then blogger API is enabled and you can edit/add/delete news with a remote client\n\n\n");
			fwrite($fp,"// news reader options\n\n");
			fwrite($fp,"define(\"PERPAGE\",".$_POST['perpage'].");	// change to how many news you want displayed on a page - 0=none\n");
			fwrite($fp,"define(\"ZNTEMPLATE\",\"templates/readnews/".$_POST['template']."\"); // the template used for showing news (subdirectory of zShaped where template html files are located)\n");
			fwrite($fp,"define(\"DATEFORMAT\",\"".$_POST['dateformat']."\"); // date format (PHP date function compatible)\n");
			fwrite($fp,"define(\"SENDTOFRIEND\",\"".$_POST['sendtofriend']."\"); // if 'enabled' then send_to_friend news emailing system is enabled\n");
			fwrite($fp,"define(\"COPYRIGHT\",\"".$_POST['copyright']."\");	// if 'no' then only the news system name is displayed\n");
			fwrite($fp,"define(\"TRACKBACK_ENABLED\",\"".$_POST['trackback']."\"); // if 'yes' then trackbacking is enabled\n");
			fwrite($fp,"define(\"TRACKBACKSDIR\",\"".$_POST['trackbacksdir']."/\"); // directory where trackbacks are stored\n");
			fwrite($fp,"\n\n// news syndication options\n\n");
			fwrite($fp,"define(\"RSS_NR\",".$_POST['rssnr'].");	// how many latest news to syndicate; 0 - RSS syndication disabled\n");
			fwrite($fp,"define(\"RSS_XML_ENCODING\",\"".$_POST['xmlencoding']."\");	// the RSS XML charset\n");
			fwrite($fp,"define(\"RSS_CHANNEL\",\"".$_POST['rsschannel']."\"); // the RSS Channel (feed) name\n");
			fwrite($fp,"define(\"RSS_DESC\",\"".$_POST['rssdesc']."\"); // the RSS channel description\n");
			fwrite($fp,"define(\"RSS_LANG\",\"".$_POST['rsslang']."\"); // the RSS language\n");
			fwrite($fp,"define(\"RSS_WEBMASTER\",\"".$_POST['rsswebmaster']."\"); //the webmaster's email address\n");
			fwrite($fp,"define(\"RSS_EDITOR\",\"".$_POST['rsseditor']."\"); // the news managing editor email address\n");
			fwrite($fp,"define(\"RSS_COPYRIGHT\",\"".$_POST['rsscopyright']."\"); // copyright notice for news in the channel\n");
			fwrite($fp,"define(\"RSS_DOMAIN\",\"".$_POST['rssdomain']."\"); // category domain (ex.: Syndic8)\n");
			fwrite($fp,"define(\"RSS_CATEGORY\",\"".$_POST['rsscategory']."\"); // category id (ex.: 1756)\n");
			fwrite($fp,"define(\"RSS_TTL\",\"".$_POST['rssttl']."\"); // feed time to live (nr. of minutes for which aggregators can cache content)\n");
			fwrite($fp,"define(\"RSS_IMAGE_TITLE\",\"".$_POST['rssimagetitle']."\"); // channel logo title\n");
			fwrite($fp,"define(\"RSS_IMAGE_URL\",\"".$_POST['rssimageurl']."\"); // channel logo url\n");
			fwrite($fp,"define(\"RSS_IMAGE_LINK\",\"".$_POST['rssimagelink']."\"); // channel logo link\n");
			fwrite($fp,"define(\"RSS_IMAGE_DESC\",\"".$_POST['rssimagedesc']."\"); // channel logo description\n");
			fwrite($fp,"define(\"RSS_IMAGE_WIDTH\",\"".$_POST['rssimagewidth']."\"); // channel logo width\n");
			fwrite($fp,"define(\"RSS_IMAGE_HEIGHT\",\"".$_POST['rssimageheight']."\"); // channel logo height\n");
			fwrite($fp,"define(\"RSS_DISABLED_TITLE\",\"".$_POST['rssdisabledtitle']."\"); // when RSS is disabled then feed will generate this title\n");
			fwrite($fp,"define(\"RSS_DISABLED_DESC\",\"".$_POST['rssdisableddesc']."\"); // when RSS is disabled then feed will generate this description\n");
			fwrite($fp,"define(\"RSS_DESC_LENGTH\",".$_POST['rssdesclength']."); // RSS items description length (news content length) -1 no description, 0 full description\n");
			fwrite($fp,"define(\"RSS_ITEM_PUBDATE\",\"".$_POST['rssitempubdate']."\"); // if date format is RFC 822 compatible then if this is yes pubdate will be generated for each item\n\n");
			fwrite($fp,"\n\n//////END OF CONFIGURATION///////////////////////////////////////////////////\n\n");
			fwrite($fp,"define(\"ZNVER\",\"".ZNVER."\"); // current zShaped version - do not modify\n?>");
			fclose($fp);
			echo "<font size=\"2\" face=\"Verdana, Arial, Helvetica, sans-serif\"><br><center>settings saved ...</center><br></font>";
		}

?>
			
			<table width="600" border="0">
			  <tr> 
				
          <td align="center"><font color="#000066" size="2" face="Verdana, Arial, Helvetica, sans-serif">Congratulations, 
            installation of zShaped has ended.</font></td>
			  </tr>
			  <tr> 
				<td><font color="#000066" size="2" face="Verdana, Arial, Helvetica, sans-serif">&nbsp;</font></td>
			  </tr>
			  <tr> 
				
          <td><font color="#000066" size="2" face="Verdana, Arial, Helvetica, sans-serif">Important 
            :<br>
            <br>
            - if install is ok then you should delete <font color="#CC3300">install.php</font> 
            immediatly<br>
            - if not then you should run it again<br>
            - change attributes of <font color="#CC3300">config.php</font> to 
            0755 (read and execute access only)<br>
            &nbsp;&nbsp;(only if you don't plan to change config from admin panel; 
            for that it must have 0766)<br>
            - you can make a backup of <font color="#CC3300">config.php</font> 
            to use when times gets tough<br>
            - <a href="<? echo $zurl."index.php";?>">go to zShaped folder</a> 
            and login as admin to get used to the system<br>
            <br>
            - include readnews.php on your page where you want news displayed<br>
            - include search.php on your page where you want to search for news</font></td>
			  </tr>
			  <tr> 
				<td><font color="#000066" size="2" face="Verdana, Arial, Helvetica, sans-serif">&nbsp;</font></td>
			  </tr>
			</table>
<?	} else {echo "<a href=\"JavaScript:history.back()\"><img src=\"images/back.gif\" alt=\"go back\" width=\"40\" height=\"40\" border=\"0\"><br><font size=\"2\" face=\"Verdana, Arial, Helvetica, sans-serif\">go back</font></a></td>";}
}
?>
	  
	  </td>
  </tr>
  <tr align="center" valign="middle" bgcolor="#D0ECFD"> 
    <td height="15" valign="top">&nbsp;</td>
  </tr>
  <tr align="center" valign="middle"> 
    <td height="15" valign="top"><font size="2" face="Verdana, Arial, Helvetica, sans-serif"> 
      powered by <a href="http://zvonnews.sourceforge.net"> zShaped <? echo ZNVER;?></a> - &copy;2003 Andrei Besleaga</font></td>
  </tr>
</table>
</body>
</html>