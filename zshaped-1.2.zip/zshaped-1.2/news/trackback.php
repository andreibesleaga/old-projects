<?php

// zShaped 1.2 - copyright (c) 2003 Andrei Besleaga
// http://zvonnews.sourceforge.net

// This program is free software; you can redistribute it and/or
// modify it under the terms of the GNU General Public License
// as published by the Free Software Foundation; either version 2
// of the License, or (at your option) any later version.

// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with this program; if not, write to the Free Software
// Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.



require(dirname(__FILE__).'/config.php');

function returnResponse($error, $message='', $showmsgtag=true)
{
	header("Content-Type: text/xml");
	echo "<?xml version=\"1.0\"?>\r\n";
	echo "<response>\r\n<error>$error</error>\r\n";
	if($message!='' && $showmsgtag==true) echo "<message>$message</message>\r\n";
	elseif($message!='') echo $message;
	echo "</response>";
}
function zntemplate_exists($templatedir, $echoexit=false)
{
	if(!file_exists($templatedir."/trackback_head.html")) {$x=false;} 
	elseif(!file_exists($templatedir."/trackbacks.html")) {$x=false;} 
	else {$x=true;}
	if($echoexit==true && $x==false) 
	{	
		echo "<font color=\"red\"><b>Error: one or more template files ( $templatedir ) doesn't exist.<br>Make sure templates exists and are readable and define it in the script ...</b></font>";
		exit;
	}
	return $x;
}
function znload($file)
{
	$temp=file(ZPATH.ZNTEMPLATE.'/'.$file);
	foreach($temp as $i=>$htmldata) {$html.=$htmldata;}
	return $html;
}
function znparse_head($html, $tburl, $pubdate="", $newstitle="")
{
	$html=str_replace("{tburl}",$tburl,$html);
	$html=str_replace("{pubdate}",$pubdate,$html);
	$html=str_replace("{newstitle}",$newstitle,$html);
	$html=str_replace("{zvonurl}",ZURL,$html);
	return $html;
}
function znparse_trackback($html, $tb_blogname, $tb_url, $tb_ip, $tb_hostname, $tb_date, $tb_title, $tb_excerpt)
{	
	$html=str_replace("{tb_blogname}",$tb_blogname,$html);
	$html=str_replace("{tb_url}",$tb_url,$html);
	$html=str_replace("{tb_ip}",$tb_ip,$html);
	$html=str_replace("{tb_hostname}",$tb_hostname,$html);
	$html=str_replace("{tb_date}",$tb_date,$html);
	$html=str_replace("{tb_title}",$tb_title,$html);
	$html=str_replace("{tb_excerpt}",$tb_excerpt,$html);
	$html=str_replace("{zvonurl}",ZURL,$html);
	return $html;
}
 
if(TRACKBACK_ENABLED!='yes')
{
	returnResponse(503,"TrackBack has been disabled on this site.");
}
else
{
	if( !empty($_GET['tb_id']) && !empty($_GET['url']) )
	{
		$tb_id = $_GET['tb_id'];
		$title = $_GET['title'];
		$url = $_GET['url'];
		$excerpt = $_GET['excerpt'];
		$blog_name = $_GET['blog_name'];
	}
	elseif( !empty($_POST['url']) )
	{
		$tbid = explode("/",$_SERVER['REQUEST_URI']);
		$tb_id = $tbid[count($tbid)-1];
		$title = $_POST['title'];
		$url = $_POST['url'];
		$excerpt = $_POST['excerpt'];
		$blog_name = $_POST['blog_name'];
	}
	if ( ($tb_id!='') && (empty($_GET['__mode'])) && ($url!='') )
	{
		$title = str_replace("\r\n","<br />",chop(strip_tags($title)));
		$title = str_replace("\n","<br />",$title);
		$title = (strlen($title) > 255) ? substr($title, 0, 252).'...' : $title;
		$excerpt = str_replace("\r\n","<br />",chop(strip_tags($excerpt)));
		$excerpt = str_replace("\n","<br />", $excerpt);
		$excerpt = (strlen($excerpt) > 255) ? substr($excerpt, 0, 252).'...' : $excerpt;
		$blog_name = str_replace("\r\n","<br />",htmlspecialchars(chop($blog_name)));
		$blog_name = str_replace("\n","<br />",$blog_name);
		$blog_name = (strlen($blog_name) > 255) ? substr($blog_name, 0, 252).'...' : $blog_name;
		$user_ip = $_SERVER['REMOTE_ADDR'];
		@$user_domain = gethostbyaddr($user_ip);
		$trackeddate = date(DATEFORMAT);
		@$xnews=file(ZPATH.NEWSFILE);
		$ubound=count($xnews);
		$itemfound=false;
		for($i=0;$i<$ubound;$i++)
		{	
			$crtsplit=explode("%~#",$xnews[$i]);
			if(md5($crtsplit[0].$crtsplit[1])==$tb_id) { $itemfound=true; break;}
		}
		if($itemfound!=true) returnResponse(404,"Item not found.");
		else
		{
			if( !file_exists(ZPATH.TRACKBACKSDIR.$tb_id) ) @$fp=fopen(ZPATH.TRACKBACKSDIR.$tb_id,"w");
			else @$fp=fopen(ZPATH.TRACKBACKSDIR.$tb_id,"a");
			if(!$fp) returnResponse(500,"Could not add trackback - dbopen error.");
			else
			{
				@$rasp=fwrite($fp,"$trackeddate%~#*$blog_name%~#*$url%~#*$title%~#*$excerpt%~#*$user_ip%~#*$user_domain\n"); 
				if($rasp) returnResponse(0); else returnResponse(500,"Could not add trackback - dbwrite error.");
				@fclose($fp); @chmod(ZPATH.TRACKBACKSDIR.$tb_id,0766);
			}
		}
	}
	elseif( $_GET['__mode']=='rss' )
	{
		$tbid=explode("/",$_SERVER['REQUEST_URI']);
		$tb_id=$tbid[count($tbid)-1];
		$tb_id=substr($tb_id,0,strpos($tb_id,"?"));
		if(file_exists(ZPATH.TRACKBACKSDIR.$tb_id))
		{	
			$rssdata="<rss version=\"2.0\">\n<channel>\n<title>TrackBack pings at ".ZURL."trackbacks.php/$tb_id</title>\n<link>".READER_PAGE."?znshowitem=$tb_id</link>\n\n";
			$trackbacks=file(ZPATH.TRACKBACKSDIR.$tb_id);
			foreach($trackbacks as $i=>$crtval)
			{
				$crtsplit=explode("%~#*",$crtval);
				$rssdata.="<item>\n<title>".htmlspecialchars($crtsplit[3])."</title>\n<link>".htmlspecialchars($crtsplit[2])."</link>\n<description>".htmlspecialchars($crtsplit[4])."</description>\n</item>\n\n";
			}
			$rssdata.="</channel></rss>";
			returnResponse(0,$rssdata,false);
		}
		else { returnResponse(404,"TrackBacks not found for that item."); }
	}
	elseif( $_GET['__mode']=='view' && $_GET['entry_id']!='' )
	{
		$tb_id=$_GET['entry_id'];
		if(file_exists(ZPATH.TRACKBACKSDIR.$tb_id) && zntemplate_exists(ZNTEMPLATE, true))
		{
			$htmlheader=znload('trackback_head.html');
			$htmlcontent=znload('trackbacks.html');
			echo "<html>\n<title>TrackBacks</title>\n<body>\n";
			echo znparse_head($htmlheader,ZURL."trackback.php/{$tb_id}");
			@$trackbacks=file(ZPATH.TRACKBACKSDIR.$tb_id);
			foreach($trackbacks as $i=>$crtval)
			{
				$crtsplit=explode("%~#*",strip_tags($crtval));
				echo znparse_trackback($htmlcontent,$crtsplit[1], $crtsplit[2], $crtsplit[5], $crtsplit[6], $crtsplit[0], $crtsplit[3], $crtsplit[4]);
			}
			echo "\n</body></html>";
		}
		else 
		{
			echo "<html><title>TrackBacks</title>\n<body>";
			$htmlheader=znload('trackback_head.html');
			echo znparse_head($htmlheader,ZURL."trackback.php/{$tb_id}");
			echo "\n</body></html>";
		}
	}
	else returnResponse(500,"Internal trackback error or Wrong Parameters given !");
}




?>