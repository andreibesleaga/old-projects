<?

// zShaped 1.2 - copyright (c) 2003 Andrei Besleaga
// http://zvonnews.sourceforge.net

// This program is free software; you can redistribute it and/or
// modify it under the terms of the GNU General Public License
// as published by the Free Software Foundation; either version 2
// of the License, or (at your option) any later version.

// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with this program; if not, write to the Free Software
// Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.



// here you can define what smilies should be used
// to add a new smiley you simply copy the image to smilies folder
// and map it here
// everything on left is replaced with the image on right

$sface[':amazed:']='amazed.gif';
$sface[':amuse:']='amuse.gif';
$sface[':bigsmile:']='bigsmile.gif';
$sface[':blink:']='blink.gif';
$sface[':blink1:']='blink1.gif';
$sface[':cheesy:']='cheesy.gif';
$sface[':confused:']='confused.gif';
$sface[':cool:']='cool.gif';
$sface[':cry:']='cry.gif';
$sface[':embarrest:']='embarrest.gif';
$sface[':evil:']='evil.gif';
$sface[':huh:']='huh.gif';
$sface[':idea:']='idea.gif';
$sface[':laugh:']='laugh.gif';
$sface[':love:']='love.gif';
$sface[':mad:']='mad.gif';
$sface[':notrust:']='notrust.gif';
$sface[':noworry:']='noworry.gif';
$sface[':nuts:']='nuts.gif';
$sface[':oh:']='oh.gif';
$sface[':push:']='push.gif';
$sface[':rolleyes:']='rolleyes.gif';
$sface[':sad:']='sad.gif';
$sface[':sad2:']='sad2.gif';
$sface[':sick:']='sick.gif';
$sface[':smile:']='smile.gif';
$sface[':smile1:']='smile1.gif';
$sface[':suspicious:']='suspicious.gif';
$sface[':toung:']='toung.gif';
$sface[':unsure:']='unsure.gif';
$sface[':wacko:']='wacko.gif';
$sface[':weird:']='weird.gif';
//$sface[':whip:']='whip.gif';
$sface[':wondering:']='wondering.gif';
$sface[':worried:']='worried.gif';

?>