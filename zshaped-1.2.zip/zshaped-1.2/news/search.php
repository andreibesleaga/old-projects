<?

// zShaped 1.2 - copyright (c) 2003 Andrei Besleaga
// http://zvonnews.sourceforge.net

// This program is free software; you can redistribute it and/or
// modify it under the terms of the GNU General Public License
// as published by the Free Software Foundation; either version 2
// of the License, or (at your option) any later version.

// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with this program; if not, write to the Free Software
// Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.



require(dirname(__FILE__).'/config.php');

?>


<form name="searchform" method="post">
  <table width="149" height="68">
    <tr> 
      <td align="center"> <font size="2" face="Verdana, Arial, Helvetica, sans-serif"> 
        <input type="text" name="searchznfor" size="23"></input>
        <input type="submit" value="Search!"></input>
        </font></tr>
  </table>
</form>
<font size="2" face="Verdana, Arial, Helvetica, sans-serif"> 

<?
if(READER_PAGE!='') $readerpage=READER_PAGE; else $readerpage=ZURL.'readnews.php';
$search_str = $_POST['searchznfor'];
if(isset($_POST['searchznfor']) && $search_str!='')
{
	echo "<font color=\"#FF0000\">searching for: $search_str </font><hr size=\"1\" />";
	$fp = file(ZPATH.NEWSFILE);
	$r = 0;
	foreach($fp as $item)
	{
		if(stristr($item, $search_str))
		{
			$crtsplit = explode("%~#", $item);
			$itemmd5=md5($crtsplit[0].$crtsplit[1]);
			echo "<a href=".$readerpage."?znshowitem=".$itemmd5.">".$crtsplit[0]." <br /><br /> ".$crtsplit[1]."</a><hr noshade size=\"1\" />";
			$r++;
		}
	}
if($r == 0){echo "<hr /><font color=\"#FF0000\">Sorry, \"".$search_str."\" not found !</font><hr />";}
else {echo "<hr /><font color=\"#FF0000\">".$r." item(s) found on ".$search_str." query string</font><hr />";}
}

?>

</font> 
