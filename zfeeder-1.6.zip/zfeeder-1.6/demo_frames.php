<html>

<head>
	<META NAME="ROBOTS" CONTENT="NOINDEX, NOFOLLOW">
	<title>zFeeder News</title>
	<style>
	body
	{ 
	margin: 5px; 
	}
	</style>
</head>

<body scroll="no">
<iframe name="sidebar" src="framesdemo_sidebar.php" marginwidth="0" marginheight="0" hspace="0" vspace="0" frameborder="0" scrolling="auto" style="float: left; height: 100%; width: 325px; border-right: dotted 1px #000000;"></iframe>

<iframe name="mainframe" src="framesdemo_mainframe.php" marginwidth="0" marginheight="0" hspace="0" vspace="0" frameborder="0" scrolling="auto" style="position: absolute; left: 332; height: 98%; width: 690px;"></iframe>

</body>

</html>