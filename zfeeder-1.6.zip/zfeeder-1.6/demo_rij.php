<html>
<head>
<link rel="stylesheet" href="newsfeeds/templates/css/RiJ.css" type="text/css">
</head>

<body>

<?php $_GET['zftemplate']='RiJ';include('newsfeeds/zfeeder.php');?>
</body>
</html>