<html>
<head>
<style type="text/css">
a:link {color: blue}
a:visited {color: #5F5FB8}
a:hover {color: #EE7A06}
a:active {color: blue}
</style>
</head>

<body>
<table width="75%" height="141" border="0" align="center">
  <tr align="center"> 
    <td height="18" colspan="3" bgcolor="#D0ECFD"><strong><font color="#006699" size="2" face="Verdana, Arial, Helvetica, sans-serif">Welcome 
      to zFeeder</font></strong></td>
  </tr>
  <tr align="center"> 
    <td height="75" colspan="3" bgcolor="#F4F4F4"> 
      <p><font color="#003366" size="2" face="Verdana, Arial, Helvetica, sans-serif">This 
        is a demo page to demonstrate you the use of zfeeder, including just one 
        line in any webpage. <br>
        <font size="3">Please <a href="readme.html">read the help</a></font></font></p>
    </td>
  </tr>
  <tr align="center" valign="middle"> 
    <td height="18" colspan="3" bgcolor="#D0ECFD"> <font color="#006699" size="2" face="Verdana, Arial, Helvetica, sans-serif"><strong>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;::&gt;&gt; 
      <a href="newsfeeds/admin.php"> admin</a> &lt;&lt;::</strong></font></td>
  </tr>
  <tr align="center"> 
    <td width="5%" height="20" valign="top" bgcolor="#F7F7F7"><font size="2" face="Verdana, Arial, Helvetica, sans-serif">&nbsp;</font></td>
    <td width="88%" valign="top" bgcolor="#F7F7F7"><font size="2" face="Verdana, Arial, Helvetica, sans-serif"> 
      <?php include("newsfeeds/zfeeder.php");?>
      </font></td>
    <td width="7%" valign="top" bgcolor="#F7F7F7"><font size="2" face="Verdana, Arial, Helvetica, sans-serif">&nbsp;</font></td>
  </tr>
</table>
<div align="center"></div>
<p><br></p><p><br></p><p><br></p><p><br></p><p><br></p><p><br></p><p><br></p>
</body></html>