<html>
<head>
<link rel="stylesheet" href="newsfeeds/templates/css/css.css" type="text/css">
</head>

<body>

<?php $_GET['zftemplate']='css';include('newsfeeds/zfeeder.php');?>
</body>
</html>