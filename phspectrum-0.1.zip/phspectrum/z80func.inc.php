<?php
// phspectrum - (c) Andrei Besleaga
// Z80 processor functions

function adc_a($b)
{
global $flags;
global $regA;
	$c=($flags['C'])?1:0;
    $wans = $regA + $b + $c;
    $ans = $wans & 0xFF;

    $flags['S'] = ($ans & F_S) != 0;
    $flags['3'] = ($ans & F_3) != 0;
    $flags['5'] = ($ans & F_5) != 0;
    $flags['Z'] = ($ans == 0);
    $flags['C'] = ($wans & 0x100) != 0;
    $flags['PV'] = (($regA ^ ((~ $b) & 0xFFFF)) & ($regA ^ $ans) & 0x80) != 0;
    $flags['H'] = ((($regA & 0xF) + ($b & 0xF) + $c) & F_H) != 0;
    $flags['N'] = False;

    $regA = $ans;
}

function adc16($a, $b)
{
global $flags;
	$c=($flags['C'])?1:0;
    $lans = $a + $b + $c;
    $ans = $lans & 0xFFFF;

    $flags['S'] = ($ans & (F_S * 256)) != 0;
    $flags['3'] = ($ans & (F_3 * 256)) != 0;
    $flags['5'] = ($ans & (F_5 * 256)) != 0;
    $flags['Z'] = ($ans == 0);
    $flags['C'] = ($lans & 0x10000) != 0;
    $flags['PV'] = (($a ^ ((~ $b) & 0xFFFF)) & ($a ^ $ans) & 0x8000) != 0;
    $flags['H'] = ((($a & 0xFFF) + ($b & 0xFFF) + $c) & 0x1000) != 0;
    $flags['N'] = False;

    return $ans;
}

function add_a($b)
{
global $regA;
global $flags;
    $wans = $regA + $b;
    $ans = $wans & 0xFF;

    $flags['S'] = ($ans & F_S) != 0;
    $flags['3'] = ($ans & F_3) != 0;
    $flags['5'] = ($ans & F_5) != 0;
    $flags['Z'] = ($ans == 0);
    $flags['C'] = ($wans & 0x100) != 0;
    $flags['PV'] = (($regA ^ ((~ ($b)) & 0xFFFF)) & ($regA ^ $ans) & 0x80) != 0;
    $flags['H'] = ((($regA & 0xF) + ($b & 0xF)) & F_H) != 0;
    $flags['N'] = False;

    $regA = $ans;
}

function add16($a, $b)
{

global $flags;
    $lans = $a + $b;
    $ans = $lans & 0xFFFF;

    $flags['3'] = ($ans & (F_3 * 256)) != 0;
    $flags['5'] = ($ans & (F_5 * 256)) != 0;
    $flags['C'] = ($lans & 0x10000) != 0;
    $flags['H'] = ((($a & 0xFFF) + ($b & 0xFFF)) & 0x1000) != 0;
    $flags['N'] = False;

    return $ans;
}

function and_a($b)
{
global $regA;
global $flags,$Parity;
    $regA = ($regA & $b);

    $flags['S'] = ($regA & F_S) != 0;
    $flags['3'] = ($regA & F_3) != 0;
    $flags['5'] = ($regA & F_5) != 0;
    $flags['H'] = True;
    $flags['PV'] = $Parity[$regA];
    $flags['Z'] = ($regA == 0);
    $flags['N'] = False;
    $flags['C'] = False;
}

function bit($b, $r)
{

global $flags;    
    $IsbitSet = (($r & $b) != 0);
    $flags['N'] = False;
    $flags['H'] = True;
    $flags['3'] = ($r & F_3) != 0;
    $flags['5'] = ($r & F_5) != 0;

    if($b == F_S) $flags['S'] = $IsbitSet; else $flags['S'] = False;

    $flags['Z'] = ! $IsbitSet;
    $flags['PV'] = $flags['Z'];
}

function bitRes($bit, $val)
{
    return ($val & (~ ($bit) & 0xFFFF));
}

function bitSet($bit, $val)
{
    return ($val | $bit);
}

function ccf()
{
global $regA;
global $flags;
    $flags['3'] = ($regA & F_3) != 0;
    $flags['5'] = ($regA & F_5) != 0;
    $flags['H'] = $flags['C'];
    $flags['N'] = False;
    $flags['C'] = ! $flags['C'];
}

function cp_a($b)
{

global $flags,$regA;
    $a = $regA;
    $wans = $a - $b;
    $ans = $wans & 0xFF;

    $flags['S'] = ($ans & F_S) != 0;
    $flags['3'] = ($b & F_3) != 0;
    $flags['5'] = ($b & F_5) != 0;
    $flags['N'] = True;
    $flags['Z'] = ($ans == 0);
    $flags['C'] = ($wans & 0x100) != 0;
    $flags['H'] = ((($a & 0xF) - ($b & 0xF)) & F_H) != 0;
    $flags['PV'] = (($a ^ $b) & ($a ^ $ans) & 0x80) != 0;
}

function cpl_a()
{
global $regA;
global $flags;
    $regA = ($regA ^ 0xFF) & 0xFF;

    $flags['3'] = ($regA & F_3) != 0;
    $flags['5'] = ($regA & F_5) != 0;
    $flags['H'] = True;
    $flags['N'] = True;
}

function sub_a($b)
{
global $regA;
global $flags;
    $a = $regA;
    $wans = $a - $b;
    $ans = $wans & 0xFF;

    $flags['S'] = ($ans & F_S) != 0;
    $flags['3'] = ($ans & F_3) != 0;
    $flags['5'] = ($ans & F_5) != 0;
    $flags['Z'] = ($ans == 0);
    $flags['C'] = ($wans & 0x100) != 0;
    $flags['PV'] = (($a ^ $b) & ($a ^ $ans) & 0x80) != 0;
    $flags['H'] = ((($a & 0xF) - ($b & 0xF)) & F_H) != 0;
    $flags['N'] = True;

    $regA = $ans;
}


function daa_a()
{
global $regA;
global $flags,$Parity;
    $incr = 0;
    $ans = $regA;
    $carry = $flags['C'];

    If ($flags['H'] or (($ans & 0xF) > 0x9))
        $incr = $incr | 0x6;

    If ($carry Or ($ans > 0x9F))
        $incr = $incr | 0x60;

    If (($ans > 0x8F) and (($ans & 0xF) > 9))
        $incr = $incr | 0x60;

    If ($ans > 0x99)
        $carry = True;

    If ($flags['N']) sub_a($incr); Else add_a($incr);
    
    $ans = $regA;
    $flags['C'] = $carry;
    $flags['PV'] = $Parity[$ans];
}

function dec16($a)
{
    return (($a - 1) & 0xFFFF);
}

function ex_af_af()
{
global $regAF_;

    $t = getAF();
    setAF($regAF_);
    $regAF_ = $t;
}

function rlc($ans)
{

global $flags,$Parity;
    $c = (($ans & 0x80) != 0);

	$ans = ($c)?(($ans * 2) | 0x1):($ans * 2);
    $ans &= 0xFF;

    $flags['S'] = ($ans & F_S) != 0;
    $flags['3'] = ($ans & F_3) != 0;
    $flags['5'] = ($ans & F_5) != 0;
    $flags['Z'] = ($ans == 0);
    $flags['PV'] = $Parity[$ans];
    $flags['H'] = False;
    $flags['N'] = False;
    $flags['C'] = $c;

    return $ans;
}

function setD($l)
{
global $regDE;

  $regDE = ($l * 256) | ($regDE & 0xFF);
}

function getD()
{
global $regDE;

  return (int)($regDE / 256);
}

function setE($l)
{
global $regDE;

  $regDE = ($regDE & 0xFF00) | $l;
}

function getE()
{
global $regDE;
  return ($regDE & 0xFF);
}

function setF($b)
{

global $flags;
    $flags['S'] = ($b & F_S) != 0;
    $flags['Z'] = ($b & F_Z) != 0;
    $flags['5'] = ($b & F_5) != 0;
    $flags['H'] = ($b & F_H) != 0;
    $flags['3'] = ($b & F_3) != 0;
    $flags['PV'] = ($b & F_PV) != 0;
    $flags['N'] = ($b & F_N) != 0;
    $flags['C'] = ($b & F_C) != 0;
}

function setH($l)
{
global $regHL;

    $regHL = ($l * 256) | ($regHL & 0xFF);
}


function setL($l)
{
global $regHL;

    $regHL = ($regHL & 0xFF00) | $l;
}


function getF()
{

global $flags;
    $res = 0;
    If ($flags['S']) $res += F_S;
    If ($flags['Z']) $res += F_Z;
    If ($flags['5']) $res += F_5;
    If ($flags['H']) $res += F_H;
    If ($flags['3']) $res += F_3;
    If ($flags['PV']) $res += F_PV;
    If ($flags['N']) $res += F_N;
    If ($flags['C']) $res += F_C;
    return $res;
}


function getAF()
{
global $regA;

    return (($regA * 256) | getF());
}

function getBC()
{
global $regB,$regC;

    return (($regB * 256) | $regC);
}

function getH()
{
global $regHL;

    return (int)($regHL / 256);
}

function getIDH()
{
global $regID;

    return ((int)($regID / 256) & 0xFF);
}

function getIDL()
{
global $regID;

    return ($regID & 0xFF);
}


function getL()
{
global $regHL;

    return ($regHL & 0xFF);
}

function rrc_a()
{
global $regA;
global $flags;
    $c = (($regA & 0x1) != 0);

	$regA = ($c)?((int)($regA / 2) | 0x80):(int)($regA  / 2);

    $flags['3'] = ($regA & F_3) != 0;
    $flags['5'] = ($regA & F_5) != 0;
    $flags['N'] = False;
    $flags['H'] = False;
    $flags['C'] = $c;
}


function rl($ans)
{

global $flags,$Parity;
    $c = (($ans & 0x80) != 0);

	$ans=($flags['C'])?(($ans * 2) | 0x1):($ans * 2);
    $ans &= 0xFF;

    $flags['S'] = ($ans & F_S) != 0;
    $flags['3'] = ($ans & F_3) != 0;
    $flags['5'] = ($ans & F_5) != 0;
    $flags['Z'] = ($ans == 0);
    $flags['PV'] = $Parity[$ans];
    $flags['H'] = False;
    $flags['N'] = False;
    $flags['C'] = $c;

    return $ans;
}

function rl_a()
{
global $regA;
global $flags;
    $ans = $regA;
    $c = (($ans & 0x80) != 0);

	$ans=($flags['C'])?(($ans * 2) | 0x1):($ans * 2);
    $ans &= 0xFF;

    $flags['3'] = ($ans & F_3) != 0;
    $flags['5'] = ($ans & F_5) != 0;
    $flags['N'] = False;
    $flags['H'] = False;
    $flags['C'] = $c;

    $regA = $ans;
}


function rlc_a()
{
global $regA;
global $flags;
    $c = ($regA & 0x80) != 0;

	$regA = ($c)?(($regA * 2) | 1):($regA * 2);
    $regA &= 0xFF;

    $flags['3'] = ($regA & F_3) != 0;
    $flags['5'] = ($regA & F_5) != 0;
    $flags['N'] = False;
    $flags['H'] = False;
    $flags['C'] = $c;
}

function rr($ans)
{

global $flags,$Parity;
    $c = ($ans & 0x1) != 0;

	$ans=($flags['C'])?((int)($ans / 2) | 0x80):(int)($ans / 2);	

    $flags['S'] = ($ans & F_S) != 0;
    $flags['3'] = ($ans & F_3) != 0;
    $flags['5'] = ($ans & F_5) != 0;
    $flags['Z'] = ($ans == 0);
    $flags['PV'] = $Parity[$ans];
    $flags['H'] = False;
    $flags['N'] = False;
    $flags['C'] = $c;

    return $ans;
}

function rr_a()
{
global $regA;
global $flags;
    $ans = $regA;
    $c = (($ans & 0x1) != 0);

	$ans=($flags['C'])?((int)($ans / 2) | 0x80):(int)($ans / 2);	

    $flags['3'] = ($ans & F_3) != 0;
    $flags['5'] = ($ans & F_5) != 0;
    $flags['N'] = False;
    $flags['H'] = False;
    $flags['C'] = $c;

    $regA = $ans;
}

function rrc($ans)
{

global $flags,$Parity;
    $c = (($ans & 0x1) != 0);

	$ans=($c)?((int)($ans / 2 ) | 0x80):(int)($ans / 2);	

    $flags['S'] = ($ans & F_S) != 0;
    $flags['3'] = ($ans & F_3) != 0;
    $flags['5'] = ($ans & F_5) != 0;
    $flags['Z'] = ($ans == 0);
    $flags['PV'] = $Parity[$ans];
    $flags['H'] = False;
    $flags['N'] = False;
    $flags['C'] = $c;

    return $ans;
}

function rrd_a()
{
global $regA,$regHL;
global $flags,$intIFF2,$Parity;
    $ans = $regA; 
    $t = peekb($regHL);
    $q = $t;

    $t = ((int)($t / 16) | ($ans * 16)) & 0xFF;
    $ans = ($ans & 0xF0) | ($q & 0x0F);
    pokeb($regHL, $t);

    $flags['S'] = ($ans & F_S) != 0;
    $flags['3'] = ($ans & F_3) != 0;
    $flags['5'] = ($ans & F_5) != 0;
    $flags['Z'] = ($ans == 0);
//    $flags['PV'] = $intIFF2;
	$flags['PV'] = $Parity[$ans];
    $flags['H'] = False;
    $flags['N'] = False;

    $regA = $ans;
}


function sbc_a($b)
{
global $regA;
global $flags;
    $a = $regA;

	$c=($flags['C'])?1:0;

    $wans = $a - $b - $c;
    $ans = $wans & 0xFF;

    $flags['S'] = ($ans & F_S) != 0;
    $flags['3'] = ($ans & F_3) != 0;
    $flags['5'] = ($ans & F_5) != 0;
    $flags['Z'] = ($ans == 0);
    $flags['C'] = ($wans & 0x100) != 0;
    $flags['PV'] = (($a ^ $b) & ($a ^ $ans) & 0x80) != 0;
    $flags['H'] = ((($a & 0xF) - ($b & 0xF) - $c) & F_H) != 0;
    $flags['N'] = True;

    $regA = $ans;
}

function sbc16($a, $b)
{

global $flags;
	$c=($flags['C'])?1:0;

    $lans = $a - $b - $c;
    $ans = $lans & 0xFFFF;

    $flags['S'] = ($ans & (F_S * 256)) != 0;
    $flags['3'] = ($ans & (F_3 * 256)) != 0;
    $flags['5'] = ($ans & (F_5 * 256)) != 0;
    $flags['Z'] = ($ans == 0);
    $flags['C'] = ($lans & 0x10000) != 0;
    $flags['PV'] = (($a ^ $b) & ($a ^ $ans) & 0x8000) != 0;
    $flags['H'] = ((($a & 0xFFF) - ($b & 0xFFF) - $c) & 0x1000) != 0;
    $flags['N'] = True;

    return $ans;
}

function scf()
{
global $regA;
global $flags;
    $flags['3'] = ($regA & F_3) != 0;
    $flags['5'] = ($regA & F_5) != 0;
    $flags['N'] = False;
    $flags['H'] = False;
    $flags['C'] = True;
}

function setAF($v)
{
global $regA;

    $regA = (int)(($v & 0xFF00) / 256);
    setF($v & 0xFF);
}

function setBC($nn)
{
global $regB,$regC;

    $regB = (int)(($nn & 0xFF00) / 256);
    $regC = $nn & 0xFF;
}

function inc16($a)
{
    return (($a + 1) & 0xFFFF);
}

function sla($ans)
{
global $flags,$Parity;
    $c = ($ans & 0x80) != 0;
    $ans = ($ans * 2) & 0xFF;

    $flags['S'] = ($ans & F_S) != 0;
    $flags['3'] = ($ans & F_3) != 0;
    $flags['5'] = ($ans & F_5) != 0;
    $flags['Z'] = ($ans == 0);
    $flags['PV'] = $Parity[$ans];
    $flags['H'] = False;
    $flags['N'] = False;
    $flags['C'] = $c;
    return $ans;
}

function sls($ans)
{
global $flags,$Parity;
    $c = ($ans & 0x80) != 0;
    $ans = (($ans * 2) | 0x1) & 0xFF;
    
    $flags['S'] = ($ans & F_S) != 0;
    $flags['3'] = ($ans & F_3) != 0;
    $flags['5'] = ($ans & F_5) != 0;
    $flags['Z'] = ($ans == 0);
    $flags['PV'] = $Parity[$ans];
    $flags['H'] = False;
    $flags['N'] = False;
    $flags['C'] = $c;

    return $ans;
}

function sra($ans)
{
global $flags,$Parity;
    $c = ($ans & 0x1) != 0;
    $ans = (int)($ans / 2) | ($ans & 0x80);

    $flags['S'] = ($ans & F_S) != 0;
    $flags['3'] = ($ans & F_3) != 0;
    $flags['5'] = ($ans & F_5) != 0;
    $flags['Z'] = ($ans == 0);
    $flags['PV'] = $Parity[$ans];
    $flags['H'] = False;
    $flags['N'] = False;
    $flags['C'] = $c;

    return $ans;
}

function srl($ans)
{
global $flags,$Parity;
    $c = ($ans & 0x1) != 0;
    $ans = (int)($ans / 2);

    $flags['S'] = ($ans & F_S) != 0;
    $flags['3'] = ($ans & F_3) != 0;
    $flags['5'] = ($ans & F_5) != 0;
    $flags['Z'] = ($ans == 0);
    $flags['PV'] = $Parity[$ans];
    $flags['H'] = False;
    $flags['N'] = False;
    $flags['C'] = $c;

    return $ans;
}

function or_a($b)
{
global $regA;
global $flags,$Parity;
    $regA = ($regA | $b);

    $flags['S'] = ($regA & F_S) != 0;
    $flags['3'] = ($regA & F_3) != 0;
    $flags['5'] = ($regA & F_5) != 0;
    $flags['H'] = False;
    $flags['PV'] = $Parity[$regA];
    $flags['Z'] = ($regA == 0);
    $flags['N'] = False;
    $flags['C'] = False;
}

function xor_a($b)
{
global $regA;
global $flags,$Parity;
    $regA = ($regA ^ $b) & 0xFF;

    $flags['S'] = ($regA & F_S) != 0;
    $flags['3'] = ($regA & F_3) != 0;
    $flags['5'] = ($regA & F_5) != 0;
    $flags['H'] = False;
    $flags['PV'] = $Parity[$regA];
    $flags['Z'] = ($regA == 0);
    $flags['N'] = False;
    $flags['C'] = False;
}

function exx()
{
global $regHL,$regDE,$regHL_,$regBC_,$regDE_;

    $t = $regHL;
    $regHL = $regHL_;
    $regHL_ = $t;

    $t = $regDE;
    $regDE = $regDE_;
    $regDE_ = $t;

    $t = getBC();
    setBC($regBC_);
    $regBC_ = $t;
}

function id_d()
{
global $regID;

    $d = nxtpcb();
    if (($d & 128) == 128) 
		$d = -(256 - $d);
    return (($regID + $d) & 0xFFFF);
}

function ld_a_i()
{
global $regA;
global $flags,$intIFF2,$intI;
    $flags['S'] = ($intI & F_S) != 0;
    $flags['3'] = ($intI & F_3) != 0;
    $flags['5'] = ($intI & F_5) != 0;
    $flags['Z'] = ($intI == 0);
    $flags['PV'] = $intIFF2;
    $flags['H'] = False;
    $flags['N'] = False;
    $regA = $intI;
}

function ld_a_r()
{
global $regA;
global $flags,$intIFF2,$intRT,$intR;
    $intRT = $intRT & 0x7F;
    $regA = ($intR & 0x80) | $intRT;
    $flags['S'] = ($regA & F_S) != 0;
    $flags['3'] = ($regA & F_3) != 0;
    $flags['5'] = ($regA & F_5) != 0;
    $flags['Z'] = ($regA == 0);
    $flags['PV'] = $intIFF2;
    $flags['H'] = False;
    $flags['N'] = False;
}

function neg_a()
{
global $regA;
    $t = $regA;
    $regA = 0;
    sub_a($t);
}

function rld_a()
{
global $regA,$regHL;
global $flags,$intIFF2,$Parity;
    $ans = $regA;
    $t = peekb($regHL);
    $q = $t;

    $t = ($t * 16) | ($ans & 0xF);
    $ans = ($ans & 0xF0) | (int)($q / 16);
    pokeb($regHL, ($t & 0xFF));

    $flags['S'] = ($ans & F_S) != 0;
    $flags['3'] = ($ans & F_3) != 0;
    $flags['5'] = ($ans & F_5) != 0;
    $flags['Z'] = ($ans == 0);
//    $flags['PV'] = $intIFF2;
	$flags['PV'] = $Parity[$ans];
    $flags['H'] = False;
    $flags['N'] = False;

    $regA = $ans;
}

function setIDH($byteval)
{
global $regID;

    $regID = (($byteval * 256) & 0xFF00) | ($regID & 0xFF);
}

function setIDL($byteval)
{
global $regID;

    $regID = ($regID & 0xFF00) | ($byteval & 0xFF);
}

function in_bc()
{
global $flags,$Parity,$ports;
    $keyarry=array(0xfefe,0xfdfe,0xfbfe,0xf7fe,0xeffe,0xdffe,0xbffe,0x7ffe);
    $tmpBC=getBC();
    $ans = $ports[$tmpBC];
    //echo "port ".getBC().":$ans\r\n";
    if($ans!=0xff && in_array($tmpBC,$keyarry)) $ports[$tmpBC]=0xff;
    $flags['Z'] = ($ans == 0);
    $flags['S'] = ($ans & F_S) != 0;
    $flags['3'] = ($ans & F_3) != 0;
    $flags['5'] = ($ans & F_5) != 0;
    $flags['PV'] = $Parity[$ans];
    $flags['N'] = False;
    $flags['H'] = False;

    return $ans;
}

function inc8($ans)
{
global $flags;
    $flags['PV'] = ($ans == 0x7F);
    $flags['H'] = ((($ans & 0xF) + 1) & F_H) != 0;

    $ans = ($ans + 1) & 0xFF;

    $flags['S'] = ($ans & F_S) != 0;
    $flags['3'] = ($ans & F_3) != 0;
    $flags['5'] = ($ans & F_5) != 0;
    $flags['Z'] = ($ans == 0);
    $flags['N'] = False;

    return $ans;
}

function dec8($ans)
{
global $flags;
    $flags['PV'] = ($ans == 0x80);
    $flags['H'] = ((($ans & 0xF) - 1) & F_H) != 0;

    $ans = ($ans - 1) & 0xFF;

    $flags['S'] = ($ans & F_S) != 0;
    $flags['3'] = ($ans & F_3) != 0;
    $flags['5'] = ($ans & F_5) != 0;
    $flags['Z'] = ($ans == 0);

    $flags['N'] = True;

    return $ans;
}

function qdec8($a)
{
    return (($a - 1) & 0xFF);
}

function peekb($addr)
{
global $gRAM;
	return $gRAM[$addr];
}

function peekw($addr)
{
global $gRAM;
    return ($gRAM[$addr] | ($gRAM[($addr + 1)] * 256));
//    return (peekb($addr) | (peekb($addr+1) * 256));
}

function pokeb($addr, $newByte)
{
global $gRAM,$ScrnNeedRepaint;
//    If ($addr < 16384) return; // ROM
	$gRAM[$addr]=$newByte;
    //If ($addr < 23296) plot($addr);
    If ($addr < 23296) $ScrnNeedRepaint=true;
}

function pokew($addr, $word)
{
//    global $gRAM;
//    $gRAM[$addr]=$word & 0xFF;
//    $gRAM[$addr+1]=($word & 0xFF00) >> 8;
    pokeb($addr, ($word & 0xFF));
    pokeb(($addr + 1), (int)(($word & 0xFF00) / 256));
}

function nxtpcb()
{
global $regPC,$gRAM;
	return $gRAM[$regPC++];
//    $val = peekb($regPC);
//	$val=$gRAM[$regPC];
//    if(USE_DEBUGGING) ReportDebug('nxtpcb',$val, false);
//    $regPC++;
//	echo $val.":".$regPC."\r\n";
//    return $val;
}

function nxtpcw()
{
global $regPC,$gRAM;
    $val = $gRAM[$regPC] + ($gRAM[$regPC + 1] * 256);
//	if(USE_DEBUGGING) ReportDebug('nxtpcw', $val, false);
    $regPC += 2;
	return $val;
}

function popw()
{
global $regSP;
	$pop = peekb($regSP) | (peekb($regSP + 1) * 256);
    $regSP = ($regSP + 2 & 0xFFFF);
//  $regSP = ($regSP + 2) & 0xFFFF;
    return $pop;
}

function poppc()
{
global $regPC,$regSP;
//    $regPC = popw();
    $regPC = (peekb($regSP) | (peekb($regSP + 1) * 256));
    $regSP = ($regSP + 2 & 0xFFFF);
}

function pushw($word)
{
global $regSP;
    $regSP = ($regSP - 2) & 0xFFFF;
    pokew($regSP, $word);
}

function pushpc()
{
global $regSP,$regPC;
//    pushw($regPC);
    $regSP = ($regSP - 2) & 0xFFFF;
    pokew($regSP, $regPC);
}

/*
function REFRESH($t)
{
global $intRT;
    $intRT += $t;
}

function Z80Reset()
{
global $intR,$intRT,$intI,$intIM,$intIFF1,$intIFF2,$regs,$flags;
    $regPC = 0;
    $regSP = 0;
    $regA = 0;
    setF(0);
    setBC(0);
    $regDE = 0;
    $regHL = 0;

    exx();
    ex_af_af();

    $regA = 0;
    setF(0);
    setBC(0);
    $regDE = 0;
    $regHL = 0;

    $regIX = 0;
    $regIY = 0;
    $intR = 0; //128;
    $intRT = 0;

    $intI = 0;
    $intIFF1 = False;
    $intIFF2 = False;
    $intIM = 0;
}
*/
?>
