<?php
// phspectrum - (c) Andrei Besleaga
// zx spectrum initialisation and functions

// Flag bit positions
define('F_C',1); //carry
define('F_N',2); //addition
define('F_PV',4); //parity/overflow
define('F_3',8); //undoc copy of bit 3
define('F_H',16); //halfcarry
define('F_5',32);  //undoc copy of bit 5
define('F_Z',64); //zero
define('F_S',128); //sign

// ports and RAM
$ports=array_fill(0,65536,0xFF);
$gRAM=array_fill(0,16384,0);
for($r=16384;$r<65536;$r++)
    $gRAM[$r]=rand(0,255);

// Z80 Flags
$flags=array('S'=>false,'Z'=>false,'5'=>false,'H'=>false,'3'=>false,'PV'=>false,'N'=>false,'C'=>false);

// screen lines
$ScrnLines=array_fill(0,192,array_fill(0,32,false));
$ScrnNeedRepaint=false;
$bFlashInverse=false;


function videoRAM()
{
    global $gRAM;
    $vram='';
    for($i=16384;$i<16384+6912;$i++)
        $vram.=chr($gRAM[$i]);
    return $vram;
}

function getmicrotime() 
{ 
    list($usec, $sec) = explode(' ', microtime());
    return ((float)$usec + (float)$sec); 
} 


$ReportDebugCallCtr=0;	
function ReportDebug($Desc , $NextPc, $forceOutput)
{
global $DebugFile,$ReportDebugCallCtr,$gRAM;
global $intI,$intR,$intRT,$intIM,$intIFF1,$intIFF2,$flags;
global $regA,$regB,$regC,$regHL,$regDE,$regID,$regIX,$regIY,$regHL_,$regAF_,$regBC_,$regDE_,$regSP,$regPC;

    if (($ReportDebugCallCtr >= 0) and ($ReportDebugCallCtr <= 1000000000))
    {
      if ((($ReportDebugCallCtr % 10000) == 0) or $forceOutput==True)
      {
        $dbgoutput='';
        $dbgoutput.= "--------------------------------------------------\r\n";
        $dbgoutput.= "DebugCall: ".$ReportDebugCallCtr." - ".$Desc.", nextPC: ".$NextPc."\r\n\r\n";

        $dbgoutput.= "Registers start\r\n";
        $dbgoutput.="  fC:{$flags['C']} fN:{$flags['N']} fPV:{$flags['PV']} f3:{$flags['3']} fH:{$flags['H']} f5:{$flags['5']} fZ:{$flags['Z']} fS:{$flags['S']} \r\n";
        $dbgoutput.="  A:{$regA} B:{$regB} C:{$regC} HL:{$regHL} DE:{$regDE} ID:{$regID} IX:{$regIX} IY:{$regIY} \r\n";
        $dbgoutput.="  HL_:{$regHL_} AF_:{$regAF_} BC_:{$regBC_} DE_:{$regDE_} \r\n";
        $dbgoutput.="  SP:{$regSP} PC:{$regPC} I:{$intI} R:{$intR} IFF1:{$intIFF1} IFF2:{$intIFF2} IM:{$intIM}\r\n";
        $dbgoutput.= "Registers end\r\n\r\n";

        $dbgoutput.= "   ROM CRC (00000-16383) : ".ramSUM(0,16384)."\r\n";
        $dbgoutput.= "SCREEN CRC (16384-23295) : ".ramSUM(16384,6912)."\r\n";
        $dbgoutput.= "   RAM CRC (23296-65535) : ".ramSUM(23296,42240)."\r\n";
        $dbgoutput.= " TOTAL CRC (00000-65535) : ".ramSUM(0,65536)."\r\n";
        echo $dbgoutput;
/*
        $dbgoutput.= 'RAM contents start'."\r\n";
        for ($ii=0;$ii<=11;$ii++)
        {
		if($Crcs[$ii]!=0) {
          $dbgoutput.= '  RAM Bank: '.$ii;
          for ($jj=0;$jj<=16383;$jj++)
          {
            if (($jj % 32) == 0)
              $dbgoutput.="\r\n";
            $dbgoutput.=$gRAM[$ii][$jj];
          }
		 }
        }
        $dbgoutput.= "\r\nRAM contents end\r\n\r\n";
*/
      //fwrite($DebugFile,$dbgoutput);
        }
    }
    $ReportDebugCallCtr++;
}

function ramSUM($offset=0,$length=65536)
{
global $gRAM;
	return array_sum(array_slice($gRAM,$offset,$length));
}

function ForceRepaint()
{
global $ScrnLines,$ScrnNeedRepaint;
    $ScrnNeedRepaint = True;
    For ($i = 0; $i<192;$i++) {
        $ScrnLines[$i][32] = True;
        For ($X = 0;$X<32;$X++)
            $ScrnLines[$i][$X] = True;
    }
}

function screenSave()
{
// Save current screen into a png
global $gRAM;
    
    $color_pal = array( 000, 000, 000, 000, 000, 192, 192, 000, 000, 192, 000, 192, 000, 192, 000, 000, 192, 192, 192, 192, 000, 192, 192, 192,
                        000, 000, 000, 000, 000, 255, 255, 000, 000, 255, 000, 255, 000, 255, 000, 000, 255, 255, 255, 255, 000, 255, 255, 255 );
    $octet_binar = $attri_binar = array(0, 0, 0, 0, 0, 0, 0, 0);
    
    $im = @imagecreate(256, 192) or die("Cannot Initialize new GD image stream");
    imagecolorallocate($im, $color_pal[21], $color_pal[22], $color_pal[23]);
    
    for($k=0;$k<3;$k++) {
            for($d=0;$d<8;$d++) {
            for($i=0;$i<8;$i++) {
                $imtmp = @imagecreate(256, 1) or die("Cannot Initialize new GD image stream");
                for($octetnr=($d*32);$octetnr<(($d*32)+32);$octetnr++) {
                $octet_val = decbin($gRAM[$octetnr+(256*$i)+($k*2048)+16384]);
                $attr_nr = decbin($gRAM[$octetnr+(256*$k)+22528]); 
                $pix=((8*$octetnr)-(256*$d));
                    $piy=($i+(8*$d)+($k*64));
                    if(strlen($octet_val) < 8) {
                        $pos = 7;
                        for($a=strlen($octet_val)-1;$a>-1;$a--) {
                            $octet_binar[$pos]=$octet_val[$a];
                            $pos--;
                        }
                    } else {
                        for($a=0;$a<8;$a++) {
                            $octet_binar[$a]=$octet_val[$a];
                        }
                    }
                    if(strlen($attr_nr) < 8) {
                        $pos = 7;
                        for($a=strlen($attr_nr)-1;$a>-1;$a--) {
                            $attri_binar[$pos]=$attr_nr[$a];
                            $pos--;
                        }
                    } else {
                        for($a=0;$a<8;$a++) {
                            $attri_binar[$a]=$attr_nr[$a];
                        }
                    }
                    $ink = $attri_binar[7]+2*$attri_binar[6]+4*$attri_binar[5];
                    $paper = $attri_binar[4]+2*$attri_binar[3]+4*$attri_binar[2];
                    $bright = $attri_binar[1];
                    if($bright) {
                        $ink=$ink+8;
                        $paper=$paper+8;
                    }
                    for($a=0;$a<8;$a++) {
                        if($octet_binar[$a]) {
                            $color = imagecolorallocate($imtmp, $color_pal[0+3*$ink], $color_pal[1+3*$ink], $color_pal[2+3*$ink]);
                        } else {
                            $color = imagecolorallocate($imtmp, $color_pal[0+3*$paper], $color_pal[1+3*$paper], $color_pal[2+3*$paper]);
                        }
                        imagesetpixel($imtmp, $pix, 0, $color);
                        $pix++;
                    }
                    for($a=0;$a<8;$a++) {
                        $octet_binar[$a]=0;
                        $attri_binar[$a]=0;
                    }
                }
                imagecopy ($im, $imtmp, 0, $piy, 0, 0, 256, 1);
                imagedestroy($imtmp);
            }
        }
    }
    imagepng($im,'screens/'.date('Ymd His ').rand(1000,2000).'.png');
    imagedestroy($im);
}


function LoadROM($sROMFile= 'spectrum.rom')
{
global $gRAM;

  if (!file_exists($sROMFile)) {
	    echo 'ROM not found!';
		return false;
	}
    // Read the ROM image into sROM

	$handle = fopen($sROMFile, "rb");
	$sROM = fread($handle, filesize($sROMFile));
	fclose($handle);
//	if(strlen($sROM)!=16384) {
//	 echo 'Error loading ROM file!';
//	 return false;
//	}

 if(USE_DEBUGGING) ReportDebug('LoadROM Start ', 0, True);
      // Copy the ROM into the appropriate memory page
    for ($lCounter = 0; $lCounter<16384; $lCounter++) {
        if(isset($sROM[$lCounter]))
            $gRAM[$lCounter] = ord($sROM[$lCounter]);
        else
            $gRAM[$lCounter]=0;
    }
 if(USE_DEBUGGING) ReportDebug('LoadROM End ', 0, True);
	return true;
}


function LoadSNASnap($sFilename)
{
global $gRAM,$borderColor,$flags,$intI,$intR,$intRT,$intIM,$intIFF1,$intIFF2;
global $regA,$regB,$regC,$regHL,$regDE,$regID,$regIX,$regIY,$regHL_,$regAF_,$regBC_,$regDE_,$regSP,$regPC;
	$hFile = fopen($sFilename, "rb");
	$sData = fread($hFile, filesize($sFilename));
	fclose($hFile);
	for($fi=0;$fi<strlen($sData);$fi++)
		$fbyte[$fi]=ord($sData[$fi]);

	$intI=$fbyte[0];
	$regHL_=$fbyte[1]+$fbyte[2]*256;
	$regDE_=$fbyte[3]+$fbyte[4]*256;
	$regBC_=$fbyte[5]+$fbyte[6]*256;
	$regAF_=$fbyte[7]+$fbyte[8]*256;
	$regHL=$fbyte[9]+$fbyte[10]*256;
	$regDE=$fbyte[11]+$fbyte[12]*256;
	setBC($fbyte[13]+$fbyte[14]*256);
	$regIY=$fbyte[15]+$fbyte[16]*256;
	$regIX=$fbyte[17]+$fbyte[18]*256;
	
    if (($fbyte[19] & 4) == 4) {
      $intIFF1 = true;
      $intIFF2 = true;
    } else {
      $intIFF1 = false;
      $intIFF2 = false;
	}
	
	$intR=$fbyte[20];
	$intRT=$intR;
	setAF($fbyte[21]+$fbyte[22]*256);
	$regSP=$fbyte[23]+$fbyte[24]*256;	
	$intIM=$fbyte[25];//& 0x03;
	$glNewBorder=$fbyte[26]& 0x07;
	
//if(USE_DEBUGGING) ReportDebug('LoadSNA_0', 0, True);

     for ($iCounter=0;$iCounter<49179-27;$iCounter++)
         $gRAM[$iCounter+16384] = $fbyte[$iCounter + 27];

//if(USE_DEBUGGING) ReportDebug('LoadSNA_1', 0, True);

        ForceRepaint();

        // Set the initial border color
        $borderColor = $glNewBorder;

//if(USE_DEBUGGING) ReportDebug('LoadSNA_2', 0, True);

        screenPaint();
        poppc();
}

function plot($addr)
{
global $ScrnLines,$ScrnNeedRepaint;
   if ($addr < 22528) {
        // Alter a pixel
        $lne = (($addr >> 8) & 0x7) | (($addr >> 2) & 0x38) | (($addr >> 5) & 0xC0);
        $ScrnLines[$lne][32] = true;
        $ScrnLines[$lne][$addr & 31] = true;
   } else {
        // Alter an attribute
        $lne = (($addr - 22528) >> 5);
        $lne = $lne << 3;
        $X = $addr % 32;
        for ($i = $lne;$i<=($lne + 7);$i++) {
            $ScrnLines[$i][32] = true;
            $ScrnLines[$i][$X] = true;
        }
   }
   $ScrnNeedRepaint = true;
}



function outb($port, $outbyte)
{
global $borderColor,$ports;
    $ports[$port]=$outbyte;
    if (!($port & 0x1))
	    if ($borderColor != ($outbyte & 0x7))
            $borderColor = ($outbyte & 0x7);
}

function refreshFlashChars()
{
global $bFlashInverse,$gRAM,$ScrnLines,$ScrnNeedRepaint;
    $bFlashInverse = ! $bFlashInverse;

    For ($addr = 6144+16384;$addr<6912+16384;$addr++)
    {
        If (($gRAM[$addr] & 128) == 128)
        { /*
            $lne = (($addr - 6144) >> 5);
            $lne = $lne << 3;
            For ($i = $lne;$i<=($lne + 7);$i++)
            {
                $ScrnLines[$i][32] = True;
                $ScrnLines[$i][$addr & 31] = True;
            }*/
            $ScrnNeedRepaint = true;
        }
    }
}

function screenPaint()
{
global $ScrnNeedRepaint;
  If (!$ScrnNeedRepaint) return;
	//screenSave();
  $ScrnNeedRepaint = false;
}

function computer_init()
{
// Initialize the spectrum machine CPU registers, etc.;
// Main Z80 registers A,B,C,HL,DE // Alternate registers AF_,HL_,BC_,DE_ // Index IX,IY,ID temp // SP StackPointer PC ProgramCounter
// Interrupt registers and flip-flops, and refresh registers

global $intR,$intI,$intIM,$intIFF1,$intIFF2,$intRT,$Parity;
global $regA,$regB,$regC,$regHL,$regDE,$regID,$regIX,$regIY,$regHL_,$regAF_,$regBC_,$regDE_,$regSP,$regPC;
	
// initParity()
   for ($lC=0;$lC<256;$lC++) {
       $p = true;
       for($j=0;$j<8;$j++)
		if (($lC & pow(2,$j)) != 0) 
			$p = ! $p;
       $Parity[$lC] = $p;
   }

// Z80Reset();
    $regPC = $regSP = $regA = $regDE = $regHL = 0;
    $regAF_=$regHL_=$regBC_=$regDE_=$regID=0;
    setF(0); setBC(0);
    exx(); ex_af_af();
    $regA = 0;
    setF(0); setBC(0);
    $regDE = $regHL = $regIX = $regIY = 0;
    $intR = $intRT = $intI = $intIM = 0;
    $intIFF1 = $intIFF2 = false;

}

?>
