<?php
// phspectrum - (c) Andrei Besleaga
// gtk, display

if (!extension_loaded('gtk')) {
	dl( 'php_gtk.' . PHP_SHLIB_SUFFIX);
}

// map gdk keys to spectrum keys addresses
$keys=array(
		      GDK_KEY_1=> array( 0xf7fe, 0x01),
		      GDK_KEY_2=> array( 0xf7fe, 0x02),
		      GDK_KEY_3=> array( 0xf7fe, 0x04),
		      GDK_KEY_4=> array( 0xf7fe, 0x08),
		      GDK_KEY_5=> array( 0xf7fe, 0x10),
              
		      GDK_KEY_6=> array( 0xeffe, 0x10),
		      GDK_KEY_7=> array( 0xeffe, 0x08),
		      GDK_KEY_8=> array( 0xeffe, 0x04),
		      GDK_KEY_9=> array( 0xeffe, 0x02),
		      GDK_KEY_0=> array( 0xeffe, 0x01),
              
		      GDK_KEY__q=> array( 0xfbfe, 0x01),
		      GDK_KEY__w=> array( 0xfbfe, 0x02),
		      GDK_KEY__e=> array( 0xfbfe, 0x04),
		      GDK_KEY__r=> array( 0xfbfe, 0x08),
		      GDK_KEY__t=> array( 0xfbfe, 0x10),
              
		      GDK_KEY__y=> array( 0xdffe, 0x10),
		      GDK_KEY__u=> array( 0xdffe, 0x08),
		      GDK_KEY__i=> array( 0xdffe, 0x04),
		      GDK_KEY__o=> array( 0xdffe, 0x02),
		      GDK_KEY__p=> array( 0xdffe, 0x01),

		      GDK_KEY__a=> array( 0xfdfe, 0x01),
		      GDK_KEY__s=> array( 0xfdfe, 0x02),
		      GDK_KEY__d=> array( 0xfdfe, 0x04),
		      GDK_KEY__f=> array( 0xfdfe, 0x08),
		      GDK_KEY__g=> array( 0xfdfe, 0x10),
              
		      GDK_KEY__h=> array( 0xbffe, 0x10),
		      GDK_KEY__j=> array( 0xbffe, 0x08),
		      GDK_KEY__k=> array( 0xbffe, 0x04),
		      GDK_KEY__l=> array( 0xbffe, 0x02),
		      GDK_KEY_Return=> array(0xbffe, 0x01),
		      
          GDK_KEY_Shift_L=> array(0xfefe, 0x01),
		      GDK_KEY__z=> array( 0xfefe, 0x02),
		      GDK_KEY__x=> array( 0xfefe, 0x04),
		      GDK_KEY__c=> array( 0xfefe, 0x08),
		      GDK_KEY__v=> array( 0xfefe, 0x10),
              
		      GDK_KEY__b=> array( 0x7ffe, 0x10),
		      GDK_KEY__n=> array( 0x7ffe, 0x08),
		      GDK_KEY__m=> array( 0x7ffe, 0x04),
          GDK_KEY_Shift_R=> array(0x7ffe, 0x02),
		      GDK_KEY_space=> array( 0x7ffe, 0x01)
);
 

function key_pressed($widget,$event)
{
  global $keys,$ports,$keyvalue;
  $keyvalue=$event->keyval;
  if(array_key_exists($keyvalue,$keys))
  {
      $ports[$keys[$keyvalue][0]] = (~$keys[$keyvalue][1]) & 0xff;
  }
  //echo 'press:'.$value;
  return false;
}

function expose_event($area,$event)
{
  global $pixmap;
  gdk::draw_pixmap($event->window,$area->style->fg_gc[$area->state],$pixmap,$event->area->x, $event->area->y,$event->area->x, $event->area->y,$event->area->width, $event->area->height);
  return 0;
} 

function quit_routine() 
{
    print("Shutting down phSpectrum ...\r\n");
    gtk::main_quit();
    exit;
}



// Initiation of GTK window and drawable area - screen for videoram

$window = &new GtkWindow(GTK_WINDOW_DIALOG);
$window->set_title("phspectrum");
$window->set_position(GTK_WIN_POS_CENTER);
$window->connect('destroy', 'quit_routine');
//$window->set_events(GDK_KEY_PRESS_MASK | GDK_KEY_RELEASE_MASK); 
$window->connect('key_press_event','key_pressed');
//$window->connect_object('delete-event', array('gtk', 'false'));
$da = &new GtkDrawingArea();
$da->size(320, 256);
$window->add($da);
$da->realize();
$window->realize();

$pixmap = &new GdkPixmap($da->window, 320, 256, 24);
$da->connect('expose_event','expose_event');
//$da->connect('key_press_event','key_pressed');
//$window->show();
//$gdkwindow=$window->window;
$gc = $pixmap->new_gc();
$colormap=gdk::colormap_get_system();
// allocate zx spectrum color palette
$colours[0]=$colormap->alloc('#000000'); $colours[1]=$colormap->alloc('#0000C0'); $colours[2]=$colormap->alloc('#C00000'); $colours[3]=$colormap->alloc('#C000C0'); $colours[4]=$colormap->alloc('#00C000'); $colours[5]=$colormap->alloc('#00C0C0');
$colours[6]=$colormap->alloc('#C0C000'); $colours[7]=$colormap->alloc('#C0C0C0'); $colours[8]=$colormap->alloc('#000000'); $colours[9]=$colormap->alloc('#0000FF'); $colours[10]=$colormap->alloc('#FF0000'); $colours[11]=$colormap->alloc('#FF00FF');
$colours[12]=$colormap->alloc('#00FF00'); $colours[13]=$colormap->alloc('#00FFFF'); $colours[14]=$colormap->alloc('#FFFF00'); $colours[15]=$colormap->alloc('#FFFFFF'); 

$gc->foreground=$colours[7];
gdk::draw_rectangle ($pixmap,$gc, 1, 0, 0, 320 , 256 );
$gc->foreground=$colours[7];
gdk::draw_rectangle ($pixmap,$gc, 1, 32, 32, 256, 192);
gdk::draw_pixmap($da->window,$gc,$pixmap,0,0,0,0,320,256);

$window->show_all();

?>
