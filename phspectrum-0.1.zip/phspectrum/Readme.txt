phspectrum 0.1 | zx spectrum emulator
http://phspectrum.sourceforge.net
(c) Andrei Besleaga


what is ZX Spectrum - ZX Spectrum was the most popular computer of the 80s and 90s around Europe and one of the firsts computers available for the masses, usually had a Z80 CPU @ 3.5 Mhz and 48K RAM, 16K ROM. Also was the first computer I ever programmed around 1994. More information on wikipedia zx spectrum and real emulators/games/documentation/etc. at the most notable zx spectrum website World of Spectrum. 


what is an emulator - an emulator is an implementation of the hardware, therefore simulating the actual structure and not only the behavior, thus being capable of running actual original code from the emulated device.


what is PHP - "PHP is a widely-used general-purpose scripting language that is especially suited for Web development and can be embedded into HTML." Also is a language used for developing shell scripts, servers, gtk programs, games and lots of other unusual things.


what is phspectrum - phspectrum is a proof of concept implementation of a computer in PHP, developed by studying the spectrum documentation and java,basic,c++ sources from other opensource emulators when only php4 and phpgtk1 existed and I decided to make it opensource as well. The program is alpha quality and it's speed is much lower than a real machine because of it's interpretation in another VM (PHP's) therefore not being a real full featured emulator used to play games and stuff, altough code quality and good development practices had been sacrificed for performance and speed. As I didnt had any free time to work on it, the firsts ports to php5 and gtk2 had not been very succesfull altough I hoped in an improvement of speed. The machine has been tested, for accurate opcode operation, against the fuse tests by Philip Kendall and all opcodes operations had been succesful except a few ones involving ports. phspectrum does not support sound because of the lack of a proper php sound extension and outlines the need for a port of libsdl or other similar libraries to php, for applications which need sound and graphics to be developed easily in php.


why a zx spectrum computer emulated in a web scripting language - because it can be done, therefore showing the versatility of the language and to be used for PHP engine benchmarking tests in different configurations and versions. Currently the speed benchmarked faster on FreeBSD, then Linux, then Windows. (all fuse tests opcodes without gtk). 


Howto 
1. download php-gtk-1.0.2 Windows and PHP Binaries from php-gtk and install/unzip to c:\php4 ; 
2. download and unzip phspectrum and unzip to a folder of choice; 
3. run phspectrum.bat (which calls php.exe phspectrum.php and runs the emulator with the original ROM); 
4. visit world of spectrum if you need to download different ROMs and games/apps; 
5. phspectrum supports loading z80 snapshots to memory (therefore you can either download .z80 or .sna files or you can convert them in another emulator) by specifying as a command line parameter e.g.: phspectrum snaps/miner.sna






This program is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation; either version 2 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License along
with this program; if not, write to the Free Software Foundation, Inc.,
51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.


The ZX Spectrum ROM is copyright Amstrad PLC. Amstrad have kindly given their permission for the redistribution of their copyrighted material but retain that copyright. 
